function hy(e, t) {
  for (var n = 0; n < t.length; n++) {
    const r = t[n];
    if (typeof r != "string" && !Array.isArray(r)) {
      for (const i in r)
        if (i !== "default" && !(i in e)) {
          const s = Object.getOwnPropertyDescriptor(r, i);
          s &&
            Object.defineProperty(
              e,
              i,
              s.get ? s : { enumerable: !0, get: () => r[i] },
            );
        }
    }
  }
  return Object.freeze(
    Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }),
  );
}
(function () {
  const t = document.createElement("link").relList;
  if (t && t.supports && t.supports("modulepreload")) return;
  for (const i of document.querySelectorAll('link[rel="modulepreload"]')) r(i);
  new MutationObserver((i) => {
    for (const s of i)
      if (s.type === "childList")
        for (const o of s.addedNodes)
          o.tagName === "LINK" && o.rel === "modulepreload" && r(o);
  }).observe(document, { childList: !0, subtree: !0 });
  function n(i) {
    const s = {};
    return (
      i.integrity && (s.integrity = i.integrity),
      i.referrerPolicy && (s.referrerPolicy = i.referrerPolicy),
      i.crossOrigin === "use-credentials"
        ? (s.credentials = "include")
        : i.crossOrigin === "anonymous"
          ? (s.credentials = "omit")
          : (s.credentials = "same-origin"),
      s
    );
  }
  function r(i) {
    if (i.ep) return;
    i.ep = !0;
    const s = n(i);
    fetch(i.href, s);
  }
})();
function py(e) {
  return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default")
    ? e.default
    : e;
}
var qf = { exports: {} },
  oo = {},
  Jf = { exports: {} },
  B = {};
/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var ji = Symbol.for("react.element"),
  my = Symbol.for("react.portal"),
  gy = Symbol.for("react.fragment"),
  yy = Symbol.for("react.strict_mode"),
  vy = Symbol.for("react.profiler"),
  xy = Symbol.for("react.provider"),
  wy = Symbol.for("react.context"),
  ky = Symbol.for("react.forward_ref"),
  jy = Symbol.for("react.suspense"),
  Sy = Symbol.for("react.memo"),
  by = Symbol.for("react.lazy"),
  cc = Symbol.iterator;
function Cy(e) {
  return e === null || typeof e != "object"
    ? null
    : ((e = (cc && e[cc]) || e["@@iterator"]),
      typeof e == "function" ? e : null);
}
var eh = {
    isMounted: function () {
      return !1;
    },
    enqueueForceUpdate: function () {},
    enqueueReplaceState: function () {},
    enqueueSetState: function () {},
  },
  th = Object.assign,
  nh = {};
function yr(e, t, n) {
  ((this.props = e),
    (this.context = t),
    (this.refs = nh),
    (this.updater = n || eh));
}
yr.prototype.isReactComponent = {};
yr.prototype.setState = function (e, t) {
  if (typeof e != "object" && typeof e != "function" && e != null)
    throw Error(
      "setState(...): takes an object of state variables to update or a function which returns an object of state variables.",
    );
  this.updater.enqueueSetState(this, e, t, "setState");
};
yr.prototype.forceUpdate = function (e) {
  this.updater.enqueueForceUpdate(this, e, "forceUpdate");
};
function rh() {}
rh.prototype = yr.prototype;
function Wl(e, t, n) {
  ((this.props = e),
    (this.context = t),
    (this.refs = nh),
    (this.updater = n || eh));
}
var Ul = (Wl.prototype = new rh());
Ul.constructor = Wl;
th(Ul, yr.prototype);
Ul.isPureReactComponent = !0;
var dc = Array.isArray,
  ih = Object.prototype.hasOwnProperty,
  Hl = { current: null },
  sh = { key: !0, ref: !0, __self: !0, __source: !0 };
function oh(e, t, n) {
  var r,
    i = {},
    s = null,
    o = null;
  if (t != null)
    for (r in (t.ref !== void 0 && (o = t.ref),
    t.key !== void 0 && (s = "" + t.key),
    t))
      ih.call(t, r) && !sh.hasOwnProperty(r) && (i[r] = t[r]);
  var l = arguments.length - 2;
  if (l === 1) i.children = n;
  else if (1 < l) {
    for (var u = Array(l), c = 0; c < l; c++) u[c] = arguments[c + 2];
    i.children = u;
  }
  if (e && e.defaultProps)
    for (r in ((l = e.defaultProps), l)) i[r] === void 0 && (i[r] = l[r]);
  return {
    $$typeof: ji,
    type: e,
    key: s,
    ref: o,
    props: i,
    _owner: Hl.current,
  };
}
function Ty(e, t) {
  return {
    $$typeof: ji,
    type: e.type,
    key: t,
    ref: e.ref,
    props: e.props,
    _owner: e._owner,
  };
}
function $l(e) {
  return typeof e == "object" && e !== null && e.$$typeof === ji;
}
function Py(e) {
  var t = { "=": "=0", ":": "=2" };
  return (
    "$" +
    e.replace(/[=:]/g, function (n) {
      return t[n];
    })
  );
}
var fc = /\/+/g;
function Ao(e, t) {
  return typeof e == "object" && e !== null && e.key != null
    ? Py("" + e.key)
    : t.toString(36);
}
function rs(e, t, n, r, i) {
  var s = typeof e;
  (s === "undefined" || s === "boolean") && (e = null);
  var o = !1;
  if (e === null) o = !0;
  else
    switch (s) {
      case "string":
      case "number":
        o = !0;
        break;
      case "object":
        switch (e.$$typeof) {
          case ji:
          case my:
            o = !0;
        }
    }
  if (o)
    return (
      (o = e),
      (i = i(o)),
      (e = r === "" ? "." + Ao(o, 0) : r),
      dc(i)
        ? ((n = ""),
          e != null && (n = e.replace(fc, "$&/") + "/"),
          rs(i, t, n, "", function (c) {
            return c;
          }))
        : i != null &&
          ($l(i) &&
            (i = Ty(
              i,
              n +
                (!i.key || (o && o.key === i.key)
                  ? ""
                  : ("" + i.key).replace(fc, "$&/") + "/") +
                e,
            )),
          t.push(i)),
      1
    );
  if (((o = 0), (r = r === "" ? "." : r + ":"), dc(e)))
    for (var l = 0; l < e.length; l++) {
      s = e[l];
      var u = r + Ao(s, l);
      o += rs(s, t, n, u, i);
    }
  else if (((u = Cy(e)), typeof u == "function"))
    for (e = u.call(e), l = 0; !(s = e.next()).done;)
      ((s = s.value), (u = r + Ao(s, l++)), (o += rs(s, t, n, u, i)));
  else if (s === "object")
    throw (
      (t = String(e)),
      Error(
        "Objects are not valid as a React child (found: " +
          (t === "[object Object]"
            ? "object with keys {" + Object.keys(e).join(", ") + "}"
            : t) +
          "). If you meant to render a collection of children, use an array instead.",
      )
    );
  return o;
}
function Ii(e, t, n) {
  if (e == null) return e;
  var r = [],
    i = 0;
  return (
    rs(e, r, "", "", function (s) {
      return t.call(n, s, i++);
    }),
    r
  );
}
function Ny(e) {
  if (e._status === -1) {
    var t = e._result;
    ((t = t()),
      t.then(
        function (n) {
          (e._status === 0 || e._status === -1) &&
            ((e._status = 1), (e._result = n));
        },
        function (n) {
          (e._status === 0 || e._status === -1) &&
            ((e._status = 2), (e._result = n));
        },
      ),
      e._status === -1 && ((e._status = 0), (e._result = t)));
  }
  if (e._status === 1) return e._result.default;
  throw e._result;
}
var Ne = { current: null },
  is = { transition: null },
  Ey = {
    ReactCurrentDispatcher: Ne,
    ReactCurrentBatchConfig: is,
    ReactCurrentOwner: Hl,
  };
function ah() {
  throw Error("act(...) is not supported in production builds of React.");
}
B.Children = {
  map: Ii,
  forEach: function (e, t, n) {
    Ii(
      e,
      function () {
        t.apply(this, arguments);
      },
      n,
    );
  },
  count: function (e) {
    var t = 0;
    return (
      Ii(e, function () {
        t++;
      }),
      t
    );
  },
  toArray: function (e) {
    return (
      Ii(e, function (t) {
        return t;
      }) || []
    );
  },
  only: function (e) {
    if (!$l(e))
      throw Error(
        "React.Children.only expected to receive a single React element child.",
      );
    return e;
  },
};
B.Component = yr;
B.Fragment = gy;
B.Profiler = vy;
B.PureComponent = Wl;
B.StrictMode = yy;
B.Suspense = jy;
B.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = Ey;
B.act = ah;
B.cloneElement = function (e, t, n) {
  if (e == null)
    throw Error(
      "React.cloneElement(...): The argument must be a React element, but you passed " +
        e +
        ".",
    );
  var r = th({}, e.props),
    i = e.key,
    s = e.ref,
    o = e._owner;
  if (t != null) {
    if (
      (t.ref !== void 0 && ((s = t.ref), (o = Hl.current)),
      t.key !== void 0 && (i = "" + t.key),
      e.type && e.type.defaultProps)
    )
      var l = e.type.defaultProps;
    for (u in t)
      ih.call(t, u) &&
        !sh.hasOwnProperty(u) &&
        (r[u] = t[u] === void 0 && l !== void 0 ? l[u] : t[u]);
  }
  var u = arguments.length - 2;
  if (u === 1) r.children = n;
  else if (1 < u) {
    l = Array(u);
    for (var c = 0; c < u; c++) l[c] = arguments[c + 2];
    r.children = l;
  }
  return { $$typeof: ji, type: e.type, key: i, ref: s, props: r, _owner: o };
};
B.createContext = function (e) {
  return (
    (e = {
      $$typeof: wy,
      _currentValue: e,
      _currentValue2: e,
      _threadCount: 0,
      Provider: null,
      Consumer: null,
      _defaultValue: null,
      _globalName: null,
    }),
    (e.Provider = { $$typeof: xy, _context: e }),
    (e.Consumer = e)
  );
};
B.createElement = oh;
B.createFactory = function (e) {
  var t = oh.bind(null, e);
  return ((t.type = e), t);
};
B.createRef = function () {
  return { current: null };
};
B.forwardRef = function (e) {
  return { $$typeof: ky, render: e };
};
B.isValidElement = $l;
B.lazy = function (e) {
  return { $$typeof: by, _payload: { _status: -1, _result: e }, _init: Ny };
};
B.memo = function (e, t) {
  return { $$typeof: Sy, type: e, compare: t === void 0 ? null : t };
};
B.startTransition = function (e) {
  var t = is.transition;
  is.transition = {};
  try {
    e();
  } finally {
    is.transition = t;
  }
};
B.unstable_act = ah;
B.useCallback = function (e, t) {
  return Ne.current.useCallback(e, t);
};
B.useContext = function (e) {
  return Ne.current.useContext(e);
};
B.useDebugValue = function () {};
B.useDeferredValue = function (e) {
  return Ne.current.useDeferredValue(e);
};
B.useEffect = function (e, t) {
  return Ne.current.useEffect(e, t);
};
B.useId = function () {
  return Ne.current.useId();
};
B.useImperativeHandle = function (e, t, n) {
  return Ne.current.useImperativeHandle(e, t, n);
};
B.useInsertionEffect = function (e, t) {
  return Ne.current.useInsertionEffect(e, t);
};
B.useLayoutEffect = function (e, t) {
  return Ne.current.useLayoutEffect(e, t);
};
B.useMemo = function (e, t) {
  return Ne.current.useMemo(e, t);
};
B.useReducer = function (e, t, n) {
  return Ne.current.useReducer(e, t, n);
};
B.useRef = function (e) {
  return Ne.current.useRef(e);
};
B.useState = function (e) {
  return Ne.current.useState(e);
};
B.useSyncExternalStore = function (e, t, n) {
  return Ne.current.useSyncExternalStore(e, t, n);
};
B.useTransition = function () {
  return Ne.current.useTransition();
};
B.version = "18.3.1";
Jf.exports = B;
var j = Jf.exports;
const Et = py(j),
  My = hy({ __proto__: null, default: Et }, [j]);
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var Ay = j,
  Ly = Symbol.for("react.element"),
  Ry = Symbol.for("react.fragment"),
  Dy = Object.prototype.hasOwnProperty,
  Iy = Ay.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,
  Vy = { key: !0, ref: !0, __self: !0, __source: !0 };
function lh(e, t, n) {
  var r,
    i = {},
    s = null,
    o = null;
  (n !== void 0 && (s = "" + n),
    t.key !== void 0 && (s = "" + t.key),
    t.ref !== void 0 && (o = t.ref));
  for (r in t) Dy.call(t, r) && !Vy.hasOwnProperty(r) && (i[r] = t[r]);
  if (e && e.defaultProps)
    for (r in ((t = e.defaultProps), t)) i[r] === void 0 && (i[r] = t[r]);
  return {
    $$typeof: Ly,
    type: e,
    key: s,
    ref: o,
    props: i,
    _owner: Iy.current,
  };
}
oo.Fragment = Ry;
oo.jsx = lh;
oo.jsxs = lh;
qf.exports = oo;
var a = qf.exports,
  wa = {},
  uh = { exports: {} },
  $e = {},
  ch = { exports: {} },
  dh = {};
/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ (function (e) {
  function t(E, L) {
    var D = E.length;
    E.push(L);
    e: for (; 0 < D;) {
      var _ = (D - 1) >>> 1,
        re = E[_];
      if (0 < i(re, L)) ((E[_] = L), (E[D] = re), (D = _));
      else break e;
    }
  }
  function n(E) {
    return E.length === 0 ? null : E[0];
  }
  function r(E) {
    if (E.length === 0) return null;
    var L = E[0],
      D = E.pop();
    if (D !== L) {
      E[0] = D;
      e: for (var _ = 0, re = E.length, Ri = re >>> 1; _ < Ri;) {
        var pn = 2 * (_ + 1) - 1,
          Mo = E[pn],
          mn = pn + 1,
          Di = E[mn];
        if (0 > i(Mo, D))
          mn < re && 0 > i(Di, Mo)
            ? ((E[_] = Di), (E[mn] = D), (_ = mn))
            : ((E[_] = Mo), (E[pn] = D), (_ = pn));
        else if (mn < re && 0 > i(Di, D)) ((E[_] = Di), (E[mn] = D), (_ = mn));
        else break e;
      }
    }
    return L;
  }
  function i(E, L) {
    var D = E.sortIndex - L.sortIndex;
    return D !== 0 ? D : E.id - L.id;
  }
  if (typeof performance == "object" && typeof performance.now == "function") {
    var s = performance;
    e.unstable_now = function () {
      return s.now();
    };
  } else {
    var o = Date,
      l = o.now();
    e.unstable_now = function () {
      return o.now() - l;
    };
  }
  var u = [],
    c = [],
    d = 1,
    f = null,
    h = 3,
    m = !1,
    v = !1,
    x = !1,
    k = typeof setTimeout == "function" ? setTimeout : null,
    g = typeof clearTimeout == "function" ? clearTimeout : null,
    p = typeof setImmediate < "u" ? setImmediate : null;
  typeof navigator < "u" &&
    navigator.scheduling !== void 0 &&
    navigator.scheduling.isInputPending !== void 0 &&
    navigator.scheduling.isInputPending.bind(navigator.scheduling);
  function y(E) {
    for (var L = n(c); L !== null;) {
      if (L.callback === null) r(c);
      else if (L.startTime <= E)
        (r(c), (L.sortIndex = L.expirationTime), t(u, L));
      else break;
      L = n(c);
    }
  }
  function w(E) {
    if (((x = !1), y(E), !v))
      if (n(u) !== null) ((v = !0), Me(S));
      else {
        var L = n(c);
        L !== null && Li(w, L.startTime - E);
      }
  }
  function S(E, L) {
    ((v = !1), x && ((x = !1), g(T), (T = -1)), (m = !0));
    var D = h;
    try {
      for (
        y(L), f = n(u);
        f !== null && (!(f.expirationTime > L) || (E && !O()));
      ) {
        var _ = f.callback;
        if (typeof _ == "function") {
          ((f.callback = null), (h = f.priorityLevel));
          var re = _(f.expirationTime <= L);
          ((L = e.unstable_now()),
            typeof re == "function" ? (f.callback = re) : f === n(u) && r(u),
            y(L));
        } else r(u);
        f = n(u);
      }
      if (f !== null) var Ri = !0;
      else {
        var pn = n(c);
        (pn !== null && Li(w, pn.startTime - L), (Ri = !1));
      }
      return Ri;
    } finally {
      ((f = null), (h = D), (m = !1));
    }
  }
  var b = !1,
    P = null,
    T = -1,
    V = 5,
    N = -1;
  function O() {
    return !(e.unstable_now() - N < V);
  }
  function ne() {
    if (P !== null) {
      var E = e.unstable_now();
      N = E;
      var L = !0;
      try {
        L = P(!0, E);
      } finally {
        L ? Be() : ((b = !1), (P = null));
      }
    } else b = !1;
  }
  var Be;
  if (typeof p == "function")
    Be = function () {
      p(ne);
    };
  else if (typeof MessageChannel < "u") {
    var Oe = new MessageChannel(),
      it = Oe.port2;
    ((Oe.port1.onmessage = ne),
      (Be = function () {
        it.postMessage(null);
      }));
  } else
    Be = function () {
      k(ne, 0);
    };
  function Me(E) {
    ((P = E), b || ((b = !0), Be()));
  }
  function Li(E, L) {
    T = k(function () {
      E(e.unstable_now());
    }, L);
  }
  ((e.unstable_IdlePriority = 5),
    (e.unstable_ImmediatePriority = 1),
    (e.unstable_LowPriority = 4),
    (e.unstable_NormalPriority = 3),
    (e.unstable_Profiling = null),
    (e.unstable_UserBlockingPriority = 2),
    (e.unstable_cancelCallback = function (E) {
      E.callback = null;
    }),
    (e.unstable_continueExecution = function () {
      v || m || ((v = !0), Me(S));
    }),
    (e.unstable_forceFrameRate = function (E) {
      0 > E || 125 < E
        ? console.error(
            "forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported",
          )
        : (V = 0 < E ? Math.floor(1e3 / E) : 5);
    }),
    (e.unstable_getCurrentPriorityLevel = function () {
      return h;
    }),
    (e.unstable_getFirstCallbackNode = function () {
      return n(u);
    }),
    (e.unstable_next = function (E) {
      switch (h) {
        case 1:
        case 2:
        case 3:
          var L = 3;
          break;
        default:
          L = h;
      }
      var D = h;
      h = L;
      try {
        return E();
      } finally {
        h = D;
      }
    }),
    (e.unstable_pauseExecution = function () {}),
    (e.unstable_requestPaint = function () {}),
    (e.unstable_runWithPriority = function (E, L) {
      switch (E) {
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
          break;
        default:
          E = 3;
      }
      var D = h;
      h = E;
      try {
        return L();
      } finally {
        h = D;
      }
    }),
    (e.unstable_scheduleCallback = function (E, L, D) {
      var _ = e.unstable_now();
      switch (
        (typeof D == "object" && D !== null
          ? ((D = D.delay), (D = typeof D == "number" && 0 < D ? _ + D : _))
          : (D = _),
        E)
      ) {
        case 1:
          var re = -1;
          break;
        case 2:
          re = 250;
          break;
        case 5:
          re = 1073741823;
          break;
        case 4:
          re = 1e4;
          break;
        default:
          re = 5e3;
      }
      return (
        (re = D + re),
        (E = {
          id: d++,
          callback: L,
          priorityLevel: E,
          startTime: D,
          expirationTime: re,
          sortIndex: -1,
        }),
        D > _
          ? ((E.sortIndex = D),
            t(c, E),
            n(u) === null &&
              E === n(c) &&
              (x ? (g(T), (T = -1)) : (x = !0), Li(w, D - _)))
          : ((E.sortIndex = re), t(u, E), v || m || ((v = !0), Me(S))),
        E
      );
    }),
    (e.unstable_shouldYield = O),
    (e.unstable_wrapCallback = function (E) {
      var L = h;
      return function () {
        var D = h;
        h = L;
        try {
          return E.apply(this, arguments);
        } finally {
          h = D;
        }
      };
    }));
})(dh);
ch.exports = dh;
var By = ch.exports;
/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var Oy = j,
  He = By;
function C(e) {
  for (
    var t = "https://reactjs.org/docs/error-decoder.html?invariant=" + e, n = 1;
    n < arguments.length;
    n++
  )
    t += "&args[]=" + encodeURIComponent(arguments[n]);
  return (
    "Minified React error #" +
    e +
    "; visit " +
    t +
    " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
  );
}
var fh = new Set(),
  Jr = {};
function Dn(e, t) {
  (ar(e, t), ar(e + "Capture", t));
}
function ar(e, t) {
  for (Jr[e] = t, e = 0; e < t.length; e++) fh.add(t[e]);
}
var At = !(
    typeof window > "u" ||
    typeof window.document > "u" ||
    typeof window.document.createElement > "u"
  ),
  ka = Object.prototype.hasOwnProperty,
  Fy =
    /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,
  hc = {},
  pc = {};
function zy(e) {
  return ka.call(pc, e)
    ? !0
    : ka.call(hc, e)
      ? !1
      : Fy.test(e)
        ? (pc[e] = !0)
        : ((hc[e] = !0), !1);
}
function _y(e, t, n, r) {
  if (n !== null && n.type === 0) return !1;
  switch (typeof t) {
    case "function":
    case "symbol":
      return !0;
    case "boolean":
      return r
        ? !1
        : n !== null
          ? !n.acceptsBooleans
          : ((e = e.toLowerCase().slice(0, 5)), e !== "data-" && e !== "aria-");
    default:
      return !1;
  }
}
function Wy(e, t, n, r) {
  if (t === null || typeof t > "u" || _y(e, t, n, r)) return !0;
  if (r) return !1;
  if (n !== null)
    switch (n.type) {
      case 3:
        return !t;
      case 4:
        return t === !1;
      case 5:
        return isNaN(t);
      case 6:
        return isNaN(t) || 1 > t;
    }
  return !1;
}
function Ee(e, t, n, r, i, s, o) {
  ((this.acceptsBooleans = t === 2 || t === 3 || t === 4),
    (this.attributeName = r),
    (this.attributeNamespace = i),
    (this.mustUseProperty = n),
    (this.propertyName = e),
    (this.type = t),
    (this.sanitizeURL = s),
    (this.removeEmptyString = o));
}
var ve = {};
"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style"
  .split(" ")
  .forEach(function (e) {
    ve[e] = new Ee(e, 0, !1, e, null, !1, !1);
  });
[
  ["acceptCharset", "accept-charset"],
  ["className", "class"],
  ["htmlFor", "for"],
  ["httpEquiv", "http-equiv"],
].forEach(function (e) {
  var t = e[0];
  ve[t] = new Ee(t, 1, !1, e[1], null, !1, !1);
});
["contentEditable", "draggable", "spellCheck", "value"].forEach(function (e) {
  ve[e] = new Ee(e, 2, !1, e.toLowerCase(), null, !1, !1);
});
[
  "autoReverse",
  "externalResourcesRequired",
  "focusable",
  "preserveAlpha",
].forEach(function (e) {
  ve[e] = new Ee(e, 2, !1, e, null, !1, !1);
});
"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope"
  .split(" ")
  .forEach(function (e) {
    ve[e] = new Ee(e, 3, !1, e.toLowerCase(), null, !1, !1);
  });
["checked", "multiple", "muted", "selected"].forEach(function (e) {
  ve[e] = new Ee(e, 3, !0, e, null, !1, !1);
});
["capture", "download"].forEach(function (e) {
  ve[e] = new Ee(e, 4, !1, e, null, !1, !1);
});
["cols", "rows", "size", "span"].forEach(function (e) {
  ve[e] = new Ee(e, 6, !1, e, null, !1, !1);
});
["rowSpan", "start"].forEach(function (e) {
  ve[e] = new Ee(e, 5, !1, e.toLowerCase(), null, !1, !1);
});
var Kl = /[\-:]([a-z])/g;
function Gl(e) {
  return e[1].toUpperCase();
}
"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height"
  .split(" ")
  .forEach(function (e) {
    var t = e.replace(Kl, Gl);
    ve[t] = new Ee(t, 1, !1, e, null, !1, !1);
  });
"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type"
  .split(" ")
  .forEach(function (e) {
    var t = e.replace(Kl, Gl);
    ve[t] = new Ee(t, 1, !1, e, "http://www.w3.org/1999/xlink", !1, !1);
  });
["xml:base", "xml:lang", "xml:space"].forEach(function (e) {
  var t = e.replace(Kl, Gl);
  ve[t] = new Ee(t, 1, !1, e, "http://www.w3.org/XML/1998/namespace", !1, !1);
});
["tabIndex", "crossOrigin"].forEach(function (e) {
  ve[e] = new Ee(e, 1, !1, e.toLowerCase(), null, !1, !1);
});
ve.xlinkHref = new Ee(
  "xlinkHref",
  1,
  !1,
  "xlink:href",
  "http://www.w3.org/1999/xlink",
  !0,
  !1,
);
["src", "href", "action", "formAction"].forEach(function (e) {
  ve[e] = new Ee(e, 1, !1, e.toLowerCase(), null, !0, !0);
});
function Yl(e, t, n, r) {
  var i = ve.hasOwnProperty(t) ? ve[t] : null;
  (i !== null
    ? i.type !== 0
    : r ||
      !(2 < t.length) ||
      (t[0] !== "o" && t[0] !== "O") ||
      (t[1] !== "n" && t[1] !== "N")) &&
    (Wy(t, n, i, r) && (n = null),
    r || i === null
      ? zy(t) && (n === null ? e.removeAttribute(t) : e.setAttribute(t, "" + n))
      : i.mustUseProperty
        ? (e[i.propertyName] = n === null ? (i.type === 3 ? !1 : "") : n)
        : ((t = i.attributeName),
          (r = i.attributeNamespace),
          n === null
            ? e.removeAttribute(t)
            : ((i = i.type),
              (n = i === 3 || (i === 4 && n === !0) ? "" : "" + n),
              r ? e.setAttributeNS(r, t, n) : e.setAttribute(t, n))));
}
var It = Oy.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,
  Vi = Symbol.for("react.element"),
  zn = Symbol.for("react.portal"),
  _n = Symbol.for("react.fragment"),
  Xl = Symbol.for("react.strict_mode"),
  ja = Symbol.for("react.profiler"),
  hh = Symbol.for("react.provider"),
  ph = Symbol.for("react.context"),
  Ql = Symbol.for("react.forward_ref"),
  Sa = Symbol.for("react.suspense"),
  ba = Symbol.for("react.suspense_list"),
  Zl = Symbol.for("react.memo"),
  _t = Symbol.for("react.lazy"),
  mh = Symbol.for("react.offscreen"),
  mc = Symbol.iterator;
function br(e) {
  return e === null || typeof e != "object"
    ? null
    : ((e = (mc && e[mc]) || e["@@iterator"]),
      typeof e == "function" ? e : null);
}
var Z = Object.assign,
  Lo;
function Dr(e) {
  if (Lo === void 0)
    try {
      throw Error();
    } catch (n) {
      var t = n.stack.trim().match(/\n( *(at )?)/);
      Lo = (t && t[1]) || "";
    }
  return (
    `
` +
    Lo +
    e
  );
}
var Ro = !1;
function Do(e, t) {
  if (!e || Ro) return "";
  Ro = !0;
  var n = Error.prepareStackTrace;
  Error.prepareStackTrace = void 0;
  try {
    if (t)
      if (
        ((t = function () {
          throw Error();
        }),
        Object.defineProperty(t.prototype, "props", {
          set: function () {
            throw Error();
          },
        }),
        typeof Reflect == "object" && Reflect.construct)
      ) {
        try {
          Reflect.construct(t, []);
        } catch (c) {
          var r = c;
        }
        Reflect.construct(e, [], t);
      } else {
        try {
          t.call();
        } catch (c) {
          r = c;
        }
        e.call(t.prototype);
      }
    else {
      try {
        throw Error();
      } catch (c) {
        r = c;
      }
      e();
    }
  } catch (c) {
    if (c && r && typeof c.stack == "string") {
      for (
        var i = c.stack.split(`
`),
          s = r.stack.split(`
`),
          o = i.length - 1,
          l = s.length - 1;
        1 <= o && 0 <= l && i[o] !== s[l];
      )
        l--;
      for (; 1 <= o && 0 <= l; o--, l--)
        if (i[o] !== s[l]) {
          if (o !== 1 || l !== 1)
            do
              if ((o--, l--, 0 > l || i[o] !== s[l])) {
                var u =
                  `
` + i[o].replace(" at new ", " at ");
                return (
                  e.displayName &&
                    u.includes("<anonymous>") &&
                    (u = u.replace("<anonymous>", e.displayName)),
                  u
                );
              }
            while (1 <= o && 0 <= l);
          break;
        }
    }
  } finally {
    ((Ro = !1), (Error.prepareStackTrace = n));
  }
  return (e = e ? e.displayName || e.name : "") ? Dr(e) : "";
}
function Uy(e) {
  switch (e.tag) {
    case 5:
      return Dr(e.type);
    case 16:
      return Dr("Lazy");
    case 13:
      return Dr("Suspense");
    case 19:
      return Dr("SuspenseList");
    case 0:
    case 2:
    case 15:
      return ((e = Do(e.type, !1)), e);
    case 11:
      return ((e = Do(e.type.render, !1)), e);
    case 1:
      return ((e = Do(e.type, !0)), e);
    default:
      return "";
  }
}
function Ca(e) {
  if (e == null) return null;
  if (typeof e == "function") return e.displayName || e.name || null;
  if (typeof e == "string") return e;
  switch (e) {
    case _n:
      return "Fragment";
    case zn:
      return "Portal";
    case ja:
      return "Profiler";
    case Xl:
      return "StrictMode";
    case Sa:
      return "Suspense";
    case ba:
      return "SuspenseList";
  }
  if (typeof e == "object")
    switch (e.$$typeof) {
      case ph:
        return (e.displayName || "Context") + ".Consumer";
      case hh:
        return (e._context.displayName || "Context") + ".Provider";
      case Ql:
        var t = e.render;
        return (
          (e = e.displayName),
          e ||
            ((e = t.displayName || t.name || ""),
            (e = e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef")),
          e
        );
      case Zl:
        return (
          (t = e.displayName || null),
          t !== null ? t : Ca(e.type) || "Memo"
        );
      case _t:
        ((t = e._payload), (e = e._init));
        try {
          return Ca(e(t));
        } catch {}
    }
  return null;
}
function Hy(e) {
  var t = e.type;
  switch (e.tag) {
    case 24:
      return "Cache";
    case 9:
      return (t.displayName || "Context") + ".Consumer";
    case 10:
      return (t._context.displayName || "Context") + ".Provider";
    case 18:
      return "DehydratedFragment";
    case 11:
      return (
        (e = t.render),
        (e = e.displayName || e.name || ""),
        t.displayName || (e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef")
      );
    case 7:
      return "Fragment";
    case 5:
      return t;
    case 4:
      return "Portal";
    case 3:
      return "Root";
    case 6:
      return "Text";
    case 16:
      return Ca(t);
    case 8:
      return t === Xl ? "StrictMode" : "Mode";
    case 22:
      return "Offscreen";
    case 12:
      return "Profiler";
    case 21:
      return "Scope";
    case 13:
      return "Suspense";
    case 19:
      return "SuspenseList";
    case 25:
      return "TracingMarker";
    case 1:
    case 0:
    case 17:
    case 2:
    case 14:
    case 15:
      if (typeof t == "function") return t.displayName || t.name || null;
      if (typeof t == "string") return t;
  }
  return null;
}
function sn(e) {
  switch (typeof e) {
    case "boolean":
    case "number":
    case "string":
    case "undefined":
      return e;
    case "object":
      return e;
    default:
      return "";
  }
}
function gh(e) {
  var t = e.type;
  return (
    (e = e.nodeName) &&
    e.toLowerCase() === "input" &&
    (t === "checkbox" || t === "radio")
  );
}
function $y(e) {
  var t = gh(e) ? "checked" : "value",
    n = Object.getOwnPropertyDescriptor(e.constructor.prototype, t),
    r = "" + e[t];
  if (
    !e.hasOwnProperty(t) &&
    typeof n < "u" &&
    typeof n.get == "function" &&
    typeof n.set == "function"
  ) {
    var i = n.get,
      s = n.set;
    return (
      Object.defineProperty(e, t, {
        configurable: !0,
        get: function () {
          return i.call(this);
        },
        set: function (o) {
          ((r = "" + o), s.call(this, o));
        },
      }),
      Object.defineProperty(e, t, { enumerable: n.enumerable }),
      {
        getValue: function () {
          return r;
        },
        setValue: function (o) {
          r = "" + o;
        },
        stopTracking: function () {
          ((e._valueTracker = null), delete e[t]);
        },
      }
    );
  }
}
function Bi(e) {
  e._valueTracker || (e._valueTracker = $y(e));
}
function yh(e) {
  if (!e) return !1;
  var t = e._valueTracker;
  if (!t) return !0;
  var n = t.getValue(),
    r = "";
  return (
    e && (r = gh(e) ? (e.checked ? "true" : "false") : e.value),
    (e = r),
    e !== n ? (t.setValue(e), !0) : !1
  );
}
function js(e) {
  if (((e = e || (typeof document < "u" ? document : void 0)), typeof e > "u"))
    return null;
  try {
    return e.activeElement || e.body;
  } catch {
    return e.body;
  }
}
function Ta(e, t) {
  var n = t.checked;
  return Z({}, t, {
    defaultChecked: void 0,
    defaultValue: void 0,
    value: void 0,
    checked: n ?? e._wrapperState.initialChecked,
  });
}
function gc(e, t) {
  var n = t.defaultValue == null ? "" : t.defaultValue,
    r = t.checked != null ? t.checked : t.defaultChecked;
  ((n = sn(t.value != null ? t.value : n)),
    (e._wrapperState = {
      initialChecked: r,
      initialValue: n,
      controlled:
        t.type === "checkbox" || t.type === "radio"
          ? t.checked != null
          : t.value != null,
    }));
}
function vh(e, t) {
  ((t = t.checked), t != null && Yl(e, "checked", t, !1));
}
function Pa(e, t) {
  vh(e, t);
  var n = sn(t.value),
    r = t.type;
  if (n != null)
    r === "number"
      ? ((n === 0 && e.value === "") || e.value != n) && (e.value = "" + n)
      : e.value !== "" + n && (e.value = "" + n);
  else if (r === "submit" || r === "reset") {
    e.removeAttribute("value");
    return;
  }
  (t.hasOwnProperty("value")
    ? Na(e, t.type, n)
    : t.hasOwnProperty("defaultValue") && Na(e, t.type, sn(t.defaultValue)),
    t.checked == null &&
      t.defaultChecked != null &&
      (e.defaultChecked = !!t.defaultChecked));
}
function yc(e, t, n) {
  if (t.hasOwnProperty("value") || t.hasOwnProperty("defaultValue")) {
    var r = t.type;
    if (!(
      (r !== "submit" && r !== "reset") ||
      (t.value !== void 0 && t.value !== null)
    ))
      return;
    ((t = "" + e._wrapperState.initialValue),
      n || t === e.value || (e.value = t),
      (e.defaultValue = t));
  }
  ((n = e.name),
    n !== "" && (e.name = ""),
    (e.defaultChecked = !!e._wrapperState.initialChecked),
    n !== "" && (e.name = n));
}
function Na(e, t, n) {
  (t !== "number" || js(e.ownerDocument) !== e) &&
    (n == null
      ? (e.defaultValue = "" + e._wrapperState.initialValue)
      : e.defaultValue !== "" + n && (e.defaultValue = "" + n));
}
var Ir = Array.isArray;
function tr(e, t, n, r) {
  if (((e = e.options), t)) {
    t = {};
    for (var i = 0; i < n.length; i++) t["$" + n[i]] = !0;
    for (n = 0; n < e.length; n++)
      ((i = t.hasOwnProperty("$" + e[n].value)),
        e[n].selected !== i && (e[n].selected = i),
        i && r && (e[n].defaultSelected = !0));
  } else {
    for (n = "" + sn(n), t = null, i = 0; i < e.length; i++) {
      if (e[i].value === n) {
        ((e[i].selected = !0), r && (e[i].defaultSelected = !0));
        return;
      }
      t !== null || e[i].disabled || (t = e[i]);
    }
    t !== null && (t.selected = !0);
  }
}
function Ea(e, t) {
  if (t.dangerouslySetInnerHTML != null) throw Error(C(91));
  return Z({}, t, {
    value: void 0,
    defaultValue: void 0,
    children: "" + e._wrapperState.initialValue,
  });
}
function vc(e, t) {
  var n = t.value;
  if (n == null) {
    if (((n = t.children), (t = t.defaultValue), n != null)) {
      if (t != null) throw Error(C(92));
      if (Ir(n)) {
        if (1 < n.length) throw Error(C(93));
        n = n[0];
      }
      t = n;
    }
    (t == null && (t = ""), (n = t));
  }
  e._wrapperState = { initialValue: sn(n) };
}
function xh(e, t) {
  var n = sn(t.value),
    r = sn(t.defaultValue);
  (n != null &&
    ((n = "" + n),
    n !== e.value && (e.value = n),
    t.defaultValue == null && e.defaultValue !== n && (e.defaultValue = n)),
    r != null && (e.defaultValue = "" + r));
}
function xc(e) {
  var t = e.textContent;
  t === e._wrapperState.initialValue && t !== "" && t !== null && (e.value = t);
}
function wh(e) {
  switch (e) {
    case "svg":
      return "http://www.w3.org/2000/svg";
    case "math":
      return "http://www.w3.org/1998/Math/MathML";
    default:
      return "http://www.w3.org/1999/xhtml";
  }
}
function Ma(e, t) {
  return e == null || e === "http://www.w3.org/1999/xhtml"
    ? wh(t)
    : e === "http://www.w3.org/2000/svg" && t === "foreignObject"
      ? "http://www.w3.org/1999/xhtml"
      : e;
}
var Oi,
  kh = (function (e) {
    return typeof MSApp < "u" && MSApp.execUnsafeLocalFunction
      ? function (t, n, r, i) {
          MSApp.execUnsafeLocalFunction(function () {
            return e(t, n, r, i);
          });
        }
      : e;
  })(function (e, t) {
    if (e.namespaceURI !== "http://www.w3.org/2000/svg" || "innerHTML" in e)
      e.innerHTML = t;
    else {
      for (
        Oi = Oi || document.createElement("div"),
          Oi.innerHTML = "<svg>" + t.valueOf().toString() + "</svg>",
          t = Oi.firstChild;
        e.firstChild;
      )
        e.removeChild(e.firstChild);
      for (; t.firstChild;) e.appendChild(t.firstChild);
    }
  });
function ei(e, t) {
  if (t) {
    var n = e.firstChild;
    if (n && n === e.lastChild && n.nodeType === 3) {
      n.nodeValue = t;
      return;
    }
  }
  e.textContent = t;
}
var Fr = {
    animationIterationCount: !0,
    aspectRatio: !0,
    borderImageOutset: !0,
    borderImageSlice: !0,
    borderImageWidth: !0,
    boxFlex: !0,
    boxFlexGroup: !0,
    boxOrdinalGroup: !0,
    columnCount: !0,
    columns: !0,
    flex: !0,
    flexGrow: !0,
    flexPositive: !0,
    flexShrink: !0,
    flexNegative: !0,
    flexOrder: !0,
    gridArea: !0,
    gridRow: !0,
    gridRowEnd: !0,
    gridRowSpan: !0,
    gridRowStart: !0,
    gridColumn: !0,
    gridColumnEnd: !0,
    gridColumnSpan: !0,
    gridColumnStart: !0,
    fontWeight: !0,
    lineClamp: !0,
    lineHeight: !0,
    opacity: !0,
    order: !0,
    orphans: !0,
    tabSize: !0,
    widows: !0,
    zIndex: !0,
    zoom: !0,
    fillOpacity: !0,
    floodOpacity: !0,
    stopOpacity: !0,
    strokeDasharray: !0,
    strokeDashoffset: !0,
    strokeMiterlimit: !0,
    strokeOpacity: !0,
    strokeWidth: !0,
  },
  Ky = ["Webkit", "ms", "Moz", "O"];
Object.keys(Fr).forEach(function (e) {
  Ky.forEach(function (t) {
    ((t = t + e.charAt(0).toUpperCase() + e.substring(1)), (Fr[t] = Fr[e]));
  });
});
function jh(e, t, n) {
  return t == null || typeof t == "boolean" || t === ""
    ? ""
    : n || typeof t != "number" || t === 0 || (Fr.hasOwnProperty(e) && Fr[e])
      ? ("" + t).trim()
      : t + "px";
}
function Sh(e, t) {
  e = e.style;
  for (var n in t)
    if (t.hasOwnProperty(n)) {
      var r = n.indexOf("--") === 0,
        i = jh(n, t[n], r);
      (n === "float" && (n = "cssFloat"), r ? e.setProperty(n, i) : (e[n] = i));
    }
}
var Gy = Z(
  { menuitem: !0 },
  {
    area: !0,
    base: !0,
    br: !0,
    col: !0,
    embed: !0,
    hr: !0,
    img: !0,
    input: !0,
    keygen: !0,
    link: !0,
    meta: !0,
    param: !0,
    source: !0,
    track: !0,
    wbr: !0,
  },
);
function Aa(e, t) {
  if (t) {
    if (Gy[e] && (t.children != null || t.dangerouslySetInnerHTML != null))
      throw Error(C(137, e));
    if (t.dangerouslySetInnerHTML != null) {
      if (t.children != null) throw Error(C(60));
      if (
        typeof t.dangerouslySetInnerHTML != "object" ||
        !("__html" in t.dangerouslySetInnerHTML)
      )
        throw Error(C(61));
    }
    if (t.style != null && typeof t.style != "object") throw Error(C(62));
  }
}
function La(e, t) {
  if (e.indexOf("-") === -1) return typeof t.is == "string";
  switch (e) {
    case "annotation-xml":
    case "color-profile":
    case "font-face":
    case "font-face-src":
    case "font-face-uri":
    case "font-face-format":
    case "font-face-name":
    case "missing-glyph":
      return !1;
    default:
      return !0;
  }
}
var Ra = null;
function ql(e) {
  return (
    (e = e.target || e.srcElement || window),
    e.correspondingUseElement && (e = e.correspondingUseElement),
    e.nodeType === 3 ? e.parentNode : e
  );
}
var Da = null,
  nr = null,
  rr = null;
function wc(e) {
  if ((e = Ci(e))) {
    if (typeof Da != "function") throw Error(C(280));
    var t = e.stateNode;
    t && ((t = fo(t)), Da(e.stateNode, e.type, t));
  }
}
function bh(e) {
  nr ? (rr ? rr.push(e) : (rr = [e])) : (nr = e);
}
function Ch() {
  if (nr) {
    var e = nr,
      t = rr;
    if (((rr = nr = null), wc(e), t)) for (e = 0; e < t.length; e++) wc(t[e]);
  }
}
function Th(e, t) {
  return e(t);
}
function Ph() {}
var Io = !1;
function Nh(e, t, n) {
  if (Io) return e(t, n);
  Io = !0;
  try {
    return Th(e, t, n);
  } finally {
    ((Io = !1), (nr !== null || rr !== null) && (Ph(), Ch()));
  }
}
function ti(e, t) {
  var n = e.stateNode;
  if (n === null) return null;
  var r = fo(n);
  if (r === null) return null;
  n = r[t];
  e: switch (t) {
    case "onClick":
    case "onClickCapture":
    case "onDoubleClick":
    case "onDoubleClickCapture":
    case "onMouseDown":
    case "onMouseDownCapture":
    case "onMouseMove":
    case "onMouseMoveCapture":
    case "onMouseUp":
    case "onMouseUpCapture":
    case "onMouseEnter":
      ((r = !r.disabled) ||
        ((e = e.type),
        (r = !(
          e === "button" ||
          e === "input" ||
          e === "select" ||
          e === "textarea"
        ))),
        (e = !r));
      break e;
    default:
      e = !1;
  }
  if (e) return null;
  if (n && typeof n != "function") throw Error(C(231, t, typeof n));
  return n;
}
var Ia = !1;
if (At)
  try {
    var Cr = {};
    (Object.defineProperty(Cr, "passive", {
      get: function () {
        Ia = !0;
      },
    }),
      window.addEventListener("test", Cr, Cr),
      window.removeEventListener("test", Cr, Cr));
  } catch {
    Ia = !1;
  }
function Yy(e, t, n, r, i, s, o, l, u) {
  var c = Array.prototype.slice.call(arguments, 3);
  try {
    t.apply(n, c);
  } catch (d) {
    this.onError(d);
  }
}
var zr = !1,
  Ss = null,
  bs = !1,
  Va = null,
  Xy = {
    onError: function (e) {
      ((zr = !0), (Ss = e));
    },
  };
function Qy(e, t, n, r, i, s, o, l, u) {
  ((zr = !1), (Ss = null), Yy.apply(Xy, arguments));
}
function Zy(e, t, n, r, i, s, o, l, u) {
  if ((Qy.apply(this, arguments), zr)) {
    if (zr) {
      var c = Ss;
      ((zr = !1), (Ss = null));
    } else throw Error(C(198));
    bs || ((bs = !0), (Va = c));
  }
}
function In(e) {
  var t = e,
    n = e;
  if (e.alternate) for (; t.return;) t = t.return;
  else {
    e = t;
    do ((t = e), t.flags & 4098 && (n = t.return), (e = t.return));
    while (e);
  }
  return t.tag === 3 ? n : null;
}
function Eh(e) {
  if (e.tag === 13) {
    var t = e.memoizedState;
    if (
      (t === null && ((e = e.alternate), e !== null && (t = e.memoizedState)),
      t !== null)
    )
      return t.dehydrated;
  }
  return null;
}
function kc(e) {
  if (In(e) !== e) throw Error(C(188));
}
function qy(e) {
  var t = e.alternate;
  if (!t) {
    if (((t = In(e)), t === null)) throw Error(C(188));
    return t !== e ? null : e;
  }
  for (var n = e, r = t; ;) {
    var i = n.return;
    if (i === null) break;
    var s = i.alternate;
    if (s === null) {
      if (((r = i.return), r !== null)) {
        n = r;
        continue;
      }
      break;
    }
    if (i.child === s.child) {
      for (s = i.child; s;) {
        if (s === n) return (kc(i), e);
        if (s === r) return (kc(i), t);
        s = s.sibling;
      }
      throw Error(C(188));
    }
    if (n.return !== r.return) ((n = i), (r = s));
    else {
      for (var o = !1, l = i.child; l;) {
        if (l === n) {
          ((o = !0), (n = i), (r = s));
          break;
        }
        if (l === r) {
          ((o = !0), (r = i), (n = s));
          break;
        }
        l = l.sibling;
      }
      if (!o) {
        for (l = s.child; l;) {
          if (l === n) {
            ((o = !0), (n = s), (r = i));
            break;
          }
          if (l === r) {
            ((o = !0), (r = s), (n = i));
            break;
          }
          l = l.sibling;
        }
        if (!o) throw Error(C(189));
      }
    }
    if (n.alternate !== r) throw Error(C(190));
  }
  if (n.tag !== 3) throw Error(C(188));
  return n.stateNode.current === n ? e : t;
}
function Mh(e) {
  return ((e = qy(e)), e !== null ? Ah(e) : null);
}
function Ah(e) {
  if (e.tag === 5 || e.tag === 6) return e;
  for (e = e.child; e !== null;) {
    var t = Ah(e);
    if (t !== null) return t;
    e = e.sibling;
  }
  return null;
}
var Lh = He.unstable_scheduleCallback,
  jc = He.unstable_cancelCallback,
  Jy = He.unstable_shouldYield,
  e0 = He.unstable_requestPaint,
  te = He.unstable_now,
  t0 = He.unstable_getCurrentPriorityLevel,
  Jl = He.unstable_ImmediatePriority,
  Rh = He.unstable_UserBlockingPriority,
  Cs = He.unstable_NormalPriority,
  n0 = He.unstable_LowPriority,
  Dh = He.unstable_IdlePriority,
  ao = null,
  kt = null;
function r0(e) {
  if (kt && typeof kt.onCommitFiberRoot == "function")
    try {
      kt.onCommitFiberRoot(ao, e, void 0, (e.current.flags & 128) === 128);
    } catch {}
}
var dt = Math.clz32 ? Math.clz32 : o0,
  i0 = Math.log,
  s0 = Math.LN2;
function o0(e) {
  return ((e >>>= 0), e === 0 ? 32 : (31 - ((i0(e) / s0) | 0)) | 0);
}
var Fi = 64,
  zi = 4194304;
function Vr(e) {
  switch (e & -e) {
    case 1:
      return 1;
    case 2:
      return 2;
    case 4:
      return 4;
    case 8:
      return 8;
    case 16:
      return 16;
    case 32:
      return 32;
    case 64:
    case 128:
    case 256:
    case 512:
    case 1024:
    case 2048:
    case 4096:
    case 8192:
    case 16384:
    case 32768:
    case 65536:
    case 131072:
    case 262144:
    case 524288:
    case 1048576:
    case 2097152:
      return e & 4194240;
    case 4194304:
    case 8388608:
    case 16777216:
    case 33554432:
    case 67108864:
      return e & 130023424;
    case 134217728:
      return 134217728;
    case 268435456:
      return 268435456;
    case 536870912:
      return 536870912;
    case 1073741824:
      return 1073741824;
    default:
      return e;
  }
}
function Ts(e, t) {
  var n = e.pendingLanes;
  if (n === 0) return 0;
  var r = 0,
    i = e.suspendedLanes,
    s = e.pingedLanes,
    o = n & 268435455;
  if (o !== 0) {
    var l = o & ~i;
    l !== 0 ? (r = Vr(l)) : ((s &= o), s !== 0 && (r = Vr(s)));
  } else ((o = n & ~i), o !== 0 ? (r = Vr(o)) : s !== 0 && (r = Vr(s)));
  if (r === 0) return 0;
  if (
    t !== 0 &&
    t !== r &&
    !(t & i) &&
    ((i = r & -r), (s = t & -t), i >= s || (i === 16 && (s & 4194240) !== 0))
  )
    return t;
  if ((r & 4 && (r |= n & 16), (t = e.entangledLanes), t !== 0))
    for (e = e.entanglements, t &= r; 0 < t;)
      ((n = 31 - dt(t)), (i = 1 << n), (r |= e[n]), (t &= ~i));
  return r;
}
function a0(e, t) {
  switch (e) {
    case 1:
    case 2:
    case 4:
      return t + 250;
    case 8:
    case 16:
    case 32:
    case 64:
    case 128:
    case 256:
    case 512:
    case 1024:
    case 2048:
    case 4096:
    case 8192:
    case 16384:
    case 32768:
    case 65536:
    case 131072:
    case 262144:
    case 524288:
    case 1048576:
    case 2097152:
      return t + 5e3;
    case 4194304:
    case 8388608:
    case 16777216:
    case 33554432:
    case 67108864:
      return -1;
    case 134217728:
    case 268435456:
    case 536870912:
    case 1073741824:
      return -1;
    default:
      return -1;
  }
}
function l0(e, t) {
  for (
    var n = e.suspendedLanes,
      r = e.pingedLanes,
      i = e.expirationTimes,
      s = e.pendingLanes;
    0 < s;
  ) {
    var o = 31 - dt(s),
      l = 1 << o,
      u = i[o];
    (u === -1
      ? (!(l & n) || l & r) && (i[o] = a0(l, t))
      : u <= t && (e.expiredLanes |= l),
      (s &= ~l));
  }
}
function Ba(e) {
  return (
    (e = e.pendingLanes & -1073741825),
    e !== 0 ? e : e & 1073741824 ? 1073741824 : 0
  );
}
function Ih() {
  var e = Fi;
  return ((Fi <<= 1), !(Fi & 4194240) && (Fi = 64), e);
}
function Vo(e) {
  for (var t = [], n = 0; 31 > n; n++) t.push(e);
  return t;
}
function Si(e, t, n) {
  ((e.pendingLanes |= t),
    t !== 536870912 && ((e.suspendedLanes = 0), (e.pingedLanes = 0)),
    (e = e.eventTimes),
    (t = 31 - dt(t)),
    (e[t] = n));
}
function u0(e, t) {
  var n = e.pendingLanes & ~t;
  ((e.pendingLanes = t),
    (e.suspendedLanes = 0),
    (e.pingedLanes = 0),
    (e.expiredLanes &= t),
    (e.mutableReadLanes &= t),
    (e.entangledLanes &= t),
    (t = e.entanglements));
  var r = e.eventTimes;
  for (e = e.expirationTimes; 0 < n;) {
    var i = 31 - dt(n),
      s = 1 << i;
    ((t[i] = 0), (r[i] = -1), (e[i] = -1), (n &= ~s));
  }
}
function eu(e, t) {
  var n = (e.entangledLanes |= t);
  for (e = e.entanglements; n;) {
    var r = 31 - dt(n),
      i = 1 << r;
    ((i & t) | (e[r] & t) && (e[r] |= t), (n &= ~i));
  }
}
var z = 0;
function Vh(e) {
  return (
    (e &= -e),
    1 < e ? (4 < e ? (e & 268435455 ? 16 : 536870912) : 4) : 1
  );
}
var Bh,
  tu,
  Oh,
  Fh,
  zh,
  Oa = !1,
  _i = [],
  Xt = null,
  Qt = null,
  Zt = null,
  ni = new Map(),
  ri = new Map(),
  Ut = [],
  c0 =
    "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(
      " ",
    );
function Sc(e, t) {
  switch (e) {
    case "focusin":
    case "focusout":
      Xt = null;
      break;
    case "dragenter":
    case "dragleave":
      Qt = null;
      break;
    case "mouseover":
    case "mouseout":
      Zt = null;
      break;
    case "pointerover":
    case "pointerout":
      ni.delete(t.pointerId);
      break;
    case "gotpointercapture":
    case "lostpointercapture":
      ri.delete(t.pointerId);
  }
}
function Tr(e, t, n, r, i, s) {
  return e === null || e.nativeEvent !== s
    ? ((e = {
        blockedOn: t,
        domEventName: n,
        eventSystemFlags: r,
        nativeEvent: s,
        targetContainers: [i],
      }),
      t !== null && ((t = Ci(t)), t !== null && tu(t)),
      e)
    : ((e.eventSystemFlags |= r),
      (t = e.targetContainers),
      i !== null && t.indexOf(i) === -1 && t.push(i),
      e);
}
function d0(e, t, n, r, i) {
  switch (t) {
    case "focusin":
      return ((Xt = Tr(Xt, e, t, n, r, i)), !0);
    case "dragenter":
      return ((Qt = Tr(Qt, e, t, n, r, i)), !0);
    case "mouseover":
      return ((Zt = Tr(Zt, e, t, n, r, i)), !0);
    case "pointerover":
      var s = i.pointerId;
      return (ni.set(s, Tr(ni.get(s) || null, e, t, n, r, i)), !0);
    case "gotpointercapture":
      return (
        (s = i.pointerId),
        ri.set(s, Tr(ri.get(s) || null, e, t, n, r, i)),
        !0
      );
  }
  return !1;
}
function _h(e) {
  var t = wn(e.target);
  if (t !== null) {
    var n = In(t);
    if (n !== null) {
      if (((t = n.tag), t === 13)) {
        if (((t = Eh(n)), t !== null)) {
          ((e.blockedOn = t),
            zh(e.priority, function () {
              Oh(n);
            }));
          return;
        }
      } else if (t === 3 && n.stateNode.current.memoizedState.isDehydrated) {
        e.blockedOn = n.tag === 3 ? n.stateNode.containerInfo : null;
        return;
      }
    }
  }
  e.blockedOn = null;
}
function ss(e) {
  if (e.blockedOn !== null) return !1;
  for (var t = e.targetContainers; 0 < t.length;) {
    var n = Fa(e.domEventName, e.eventSystemFlags, t[0], e.nativeEvent);
    if (n === null) {
      n = e.nativeEvent;
      var r = new n.constructor(n.type, n);
      ((Ra = r), n.target.dispatchEvent(r), (Ra = null));
    } else return ((t = Ci(n)), t !== null && tu(t), (e.blockedOn = n), !1);
    t.shift();
  }
  return !0;
}
function bc(e, t, n) {
  ss(e) && n.delete(t);
}
function f0() {
  ((Oa = !1),
    Xt !== null && ss(Xt) && (Xt = null),
    Qt !== null && ss(Qt) && (Qt = null),
    Zt !== null && ss(Zt) && (Zt = null),
    ni.forEach(bc),
    ri.forEach(bc));
}
function Pr(e, t) {
  e.blockedOn === t &&
    ((e.blockedOn = null),
    Oa ||
      ((Oa = !0),
      He.unstable_scheduleCallback(He.unstable_NormalPriority, f0)));
}
function ii(e) {
  function t(i) {
    return Pr(i, e);
  }
  if (0 < _i.length) {
    Pr(_i[0], e);
    for (var n = 1; n < _i.length; n++) {
      var r = _i[n];
      r.blockedOn === e && (r.blockedOn = null);
    }
  }
  for (
    Xt !== null && Pr(Xt, e),
      Qt !== null && Pr(Qt, e),
      Zt !== null && Pr(Zt, e),
      ni.forEach(t),
      ri.forEach(t),
      n = 0;
    n < Ut.length;
    n++
  )
    ((r = Ut[n]), r.blockedOn === e && (r.blockedOn = null));
  for (; 0 < Ut.length && ((n = Ut[0]), n.blockedOn === null);)
    (_h(n), n.blockedOn === null && Ut.shift());
}
var ir = It.ReactCurrentBatchConfig,
  Ps = !0;
function h0(e, t, n, r) {
  var i = z,
    s = ir.transition;
  ir.transition = null;
  try {
    ((z = 1), nu(e, t, n, r));
  } finally {
    ((z = i), (ir.transition = s));
  }
}
function p0(e, t, n, r) {
  var i = z,
    s = ir.transition;
  ir.transition = null;
  try {
    ((z = 4), nu(e, t, n, r));
  } finally {
    ((z = i), (ir.transition = s));
  }
}
function nu(e, t, n, r) {
  if (Ps) {
    var i = Fa(e, t, n, r);
    if (i === null) (Ko(e, t, r, Ns, n), Sc(e, r));
    else if (d0(i, e, t, n, r)) r.stopPropagation();
    else if ((Sc(e, r), t & 4 && -1 < c0.indexOf(e))) {
      for (; i !== null;) {
        var s = Ci(i);
        if (
          (s !== null && Bh(s),
          (s = Fa(e, t, n, r)),
          s === null && Ko(e, t, r, Ns, n),
          s === i)
        )
          break;
        i = s;
      }
      i !== null && r.stopPropagation();
    } else Ko(e, t, r, null, n);
  }
}
var Ns = null;
function Fa(e, t, n, r) {
  if (((Ns = null), (e = ql(r)), (e = wn(e)), e !== null))
    if (((t = In(e)), t === null)) e = null;
    else if (((n = t.tag), n === 13)) {
      if (((e = Eh(t)), e !== null)) return e;
      e = null;
    } else if (n === 3) {
      if (t.stateNode.current.memoizedState.isDehydrated)
        return t.tag === 3 ? t.stateNode.containerInfo : null;
      e = null;
    } else t !== e && (e = null);
  return ((Ns = e), null);
}
function Wh(e) {
  switch (e) {
    case "cancel":
    case "click":
    case "close":
    case "contextmenu":
    case "copy":
    case "cut":
    case "auxclick":
    case "dblclick":
    case "dragend":
    case "dragstart":
    case "drop":
    case "focusin":
    case "focusout":
    case "input":
    case "invalid":
    case "keydown":
    case "keypress":
    case "keyup":
    case "mousedown":
    case "mouseup":
    case "paste":
    case "pause":
    case "play":
    case "pointercancel":
    case "pointerdown":
    case "pointerup":
    case "ratechange":
    case "reset":
    case "resize":
    case "seeked":
    case "submit":
    case "touchcancel":
    case "touchend":
    case "touchstart":
    case "volumechange":
    case "change":
    case "selectionchange":
    case "textInput":
    case "compositionstart":
    case "compositionend":
    case "compositionupdate":
    case "beforeblur":
    case "afterblur":
    case "beforeinput":
    case "blur":
    case "fullscreenchange":
    case "focus":
    case "hashchange":
    case "popstate":
    case "select":
    case "selectstart":
      return 1;
    case "drag":
    case "dragenter":
    case "dragexit":
    case "dragleave":
    case "dragover":
    case "mousemove":
    case "mouseout":
    case "mouseover":
    case "pointermove":
    case "pointerout":
    case "pointerover":
    case "scroll":
    case "toggle":
    case "touchmove":
    case "wheel":
    case "mouseenter":
    case "mouseleave":
    case "pointerenter":
    case "pointerleave":
      return 4;
    case "message":
      switch (t0()) {
        case Jl:
          return 1;
        case Rh:
          return 4;
        case Cs:
        case n0:
          return 16;
        case Dh:
          return 536870912;
        default:
          return 16;
      }
    default:
      return 16;
  }
}
var $t = null,
  ru = null,
  os = null;
function Uh() {
  if (os) return os;
  var e,
    t = ru,
    n = t.length,
    r,
    i = "value" in $t ? $t.value : $t.textContent,
    s = i.length;
  for (e = 0; e < n && t[e] === i[e]; e++);
  var o = n - e;
  for (r = 1; r <= o && t[n - r] === i[s - r]; r++);
  return (os = i.slice(e, 1 < r ? 1 - r : void 0));
}
function as(e) {
  var t = e.keyCode;
  return (
    "charCode" in e
      ? ((e = e.charCode), e === 0 && t === 13 && (e = 13))
      : (e = t),
    e === 10 && (e = 13),
    32 <= e || e === 13 ? e : 0
  );
}
function Wi() {
  return !0;
}
function Cc() {
  return !1;
}
function Ke(e) {
  function t(n, r, i, s, o) {
    ((this._reactName = n),
      (this._targetInst = i),
      (this.type = r),
      (this.nativeEvent = s),
      (this.target = o),
      (this.currentTarget = null));
    for (var l in e)
      e.hasOwnProperty(l) && ((n = e[l]), (this[l] = n ? n(s) : s[l]));
    return (
      (this.isDefaultPrevented = (
        s.defaultPrevented != null ? s.defaultPrevented : s.returnValue === !1
      )
        ? Wi
        : Cc),
      (this.isPropagationStopped = Cc),
      this
    );
  }
  return (
    Z(t.prototype, {
      preventDefault: function () {
        this.defaultPrevented = !0;
        var n = this.nativeEvent;
        n &&
          (n.preventDefault
            ? n.preventDefault()
            : typeof n.returnValue != "unknown" && (n.returnValue = !1),
          (this.isDefaultPrevented = Wi));
      },
      stopPropagation: function () {
        var n = this.nativeEvent;
        n &&
          (n.stopPropagation
            ? n.stopPropagation()
            : typeof n.cancelBubble != "unknown" && (n.cancelBubble = !0),
          (this.isPropagationStopped = Wi));
      },
      persist: function () {},
      isPersistent: Wi,
    }),
    t
  );
}
var vr = {
    eventPhase: 0,
    bubbles: 0,
    cancelable: 0,
    timeStamp: function (e) {
      return e.timeStamp || Date.now();
    },
    defaultPrevented: 0,
    isTrusted: 0,
  },
  iu = Ke(vr),
  bi = Z({}, vr, { view: 0, detail: 0 }),
  m0 = Ke(bi),
  Bo,
  Oo,
  Nr,
  lo = Z({}, bi, {
    screenX: 0,
    screenY: 0,
    clientX: 0,
    clientY: 0,
    pageX: 0,
    pageY: 0,
    ctrlKey: 0,
    shiftKey: 0,
    altKey: 0,
    metaKey: 0,
    getModifierState: su,
    button: 0,
    buttons: 0,
    relatedTarget: function (e) {
      return e.relatedTarget === void 0
        ? e.fromElement === e.srcElement
          ? e.toElement
          : e.fromElement
        : e.relatedTarget;
    },
    movementX: function (e) {
      return "movementX" in e
        ? e.movementX
        : (e !== Nr &&
            (Nr && e.type === "mousemove"
              ? ((Bo = e.screenX - Nr.screenX), (Oo = e.screenY - Nr.screenY))
              : (Oo = Bo = 0),
            (Nr = e)),
          Bo);
    },
    movementY: function (e) {
      return "movementY" in e ? e.movementY : Oo;
    },
  }),
  Tc = Ke(lo),
  g0 = Z({}, lo, { dataTransfer: 0 }),
  y0 = Ke(g0),
  v0 = Z({}, bi, { relatedTarget: 0 }),
  Fo = Ke(v0),
  x0 = Z({}, vr, { animationName: 0, elapsedTime: 0, pseudoElement: 0 }),
  w0 = Ke(x0),
  k0 = Z({}, vr, {
    clipboardData: function (e) {
      return "clipboardData" in e ? e.clipboardData : window.clipboardData;
    },
  }),
  j0 = Ke(k0),
  S0 = Z({}, vr, { data: 0 }),
  Pc = Ke(S0),
  b0 = {
    Esc: "Escape",
    Spacebar: " ",
    Left: "ArrowLeft",
    Up: "ArrowUp",
    Right: "ArrowRight",
    Down: "ArrowDown",
    Del: "Delete",
    Win: "OS",
    Menu: "ContextMenu",
    Apps: "ContextMenu",
    Scroll: "ScrollLock",
    MozPrintableKey: "Unidentified",
  },
  C0 = {
    8: "Backspace",
    9: "Tab",
    12: "Clear",
    13: "Enter",
    16: "Shift",
    17: "Control",
    18: "Alt",
    19: "Pause",
    20: "CapsLock",
    27: "Escape",
    32: " ",
    33: "PageUp",
    34: "PageDown",
    35: "End",
    36: "Home",
    37: "ArrowLeft",
    38: "ArrowUp",
    39: "ArrowRight",
    40: "ArrowDown",
    45: "Insert",
    46: "Delete",
    112: "F1",
    113: "F2",
    114: "F3",
    115: "F4",
    116: "F5",
    117: "F6",
    118: "F7",
    119: "F8",
    120: "F9",
    121: "F10",
    122: "F11",
    123: "F12",
    144: "NumLock",
    145: "ScrollLock",
    224: "Meta",
  },
  T0 = {
    Alt: "altKey",
    Control: "ctrlKey",
    Meta: "metaKey",
    Shift: "shiftKey",
  };
function P0(e) {
  var t = this.nativeEvent;
  return t.getModifierState ? t.getModifierState(e) : (e = T0[e]) ? !!t[e] : !1;
}
function su() {
  return P0;
}
var N0 = Z({}, bi, {
    key: function (e) {
      if (e.key) {
        var t = b0[e.key] || e.key;
        if (t !== "Unidentified") return t;
      }
      return e.type === "keypress"
        ? ((e = as(e)), e === 13 ? "Enter" : String.fromCharCode(e))
        : e.type === "keydown" || e.type === "keyup"
          ? C0[e.keyCode] || "Unidentified"
          : "";
    },
    code: 0,
    location: 0,
    ctrlKey: 0,
    shiftKey: 0,
    altKey: 0,
    metaKey: 0,
    repeat: 0,
    locale: 0,
    getModifierState: su,
    charCode: function (e) {
      return e.type === "keypress" ? as(e) : 0;
    },
    keyCode: function (e) {
      return e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0;
    },
    which: function (e) {
      return e.type === "keypress"
        ? as(e)
        : e.type === "keydown" || e.type === "keyup"
          ? e.keyCode
          : 0;
    },
  }),
  E0 = Ke(N0),
  M0 = Z({}, lo, {
    pointerId: 0,
    width: 0,
    height: 0,
    pressure: 0,
    tangentialPressure: 0,
    tiltX: 0,
    tiltY: 0,
    twist: 0,
    pointerType: 0,
    isPrimary: 0,
  }),
  Nc = Ke(M0),
  A0 = Z({}, bi, {
    touches: 0,
    targetTouches: 0,
    changedTouches: 0,
    altKey: 0,
    metaKey: 0,
    ctrlKey: 0,
    shiftKey: 0,
    getModifierState: su,
  }),
  L0 = Ke(A0),
  R0 = Z({}, vr, { propertyName: 0, elapsedTime: 0, pseudoElement: 0 }),
  D0 = Ke(R0),
  I0 = Z({}, lo, {
    deltaX: function (e) {
      return "deltaX" in e ? e.deltaX : "wheelDeltaX" in e ? -e.wheelDeltaX : 0;
    },
    deltaY: function (e) {
      return "deltaY" in e
        ? e.deltaY
        : "wheelDeltaY" in e
          ? -e.wheelDeltaY
          : "wheelDelta" in e
            ? -e.wheelDelta
            : 0;
    },
    deltaZ: 0,
    deltaMode: 0,
  }),
  V0 = Ke(I0),
  B0 = [9, 13, 27, 32],
  ou = At && "CompositionEvent" in window,
  _r = null;
At && "documentMode" in document && (_r = document.documentMode);
var O0 = At && "TextEvent" in window && !_r,
  Hh = At && (!ou || (_r && 8 < _r && 11 >= _r)),
  Ec = " ",
  Mc = !1;
function $h(e, t) {
  switch (e) {
    case "keyup":
      return B0.indexOf(t.keyCode) !== -1;
    case "keydown":
      return t.keyCode !== 229;
    case "keypress":
    case "mousedown":
    case "focusout":
      return !0;
    default:
      return !1;
  }
}
function Kh(e) {
  return ((e = e.detail), typeof e == "object" && "data" in e ? e.data : null);
}
var Wn = !1;
function F0(e, t) {
  switch (e) {
    case "compositionend":
      return Kh(t);
    case "keypress":
      return t.which !== 32 ? null : ((Mc = !0), Ec);
    case "textInput":
      return ((e = t.data), e === Ec && Mc ? null : e);
    default:
      return null;
  }
}
function z0(e, t) {
  if (Wn)
    return e === "compositionend" || (!ou && $h(e, t))
      ? ((e = Uh()), (os = ru = $t = null), (Wn = !1), e)
      : null;
  switch (e) {
    case "paste":
      return null;
    case "keypress":
      if (!(t.ctrlKey || t.altKey || t.metaKey) || (t.ctrlKey && t.altKey)) {
        if (t.char && 1 < t.char.length) return t.char;
        if (t.which) return String.fromCharCode(t.which);
      }
      return null;
    case "compositionend":
      return Hh && t.locale !== "ko" ? null : t.data;
    default:
      return null;
  }
}
var _0 = {
  color: !0,
  date: !0,
  datetime: !0,
  "datetime-local": !0,
  email: !0,
  month: !0,
  number: !0,
  password: !0,
  range: !0,
  search: !0,
  tel: !0,
  text: !0,
  time: !0,
  url: !0,
  week: !0,
};
function Ac(e) {
  var t = e && e.nodeName && e.nodeName.toLowerCase();
  return t === "input" ? !!_0[e.type] : t === "textarea";
}
function Gh(e, t, n, r) {
  (bh(r),
    (t = Es(t, "onChange")),
    0 < t.length &&
      ((n = new iu("onChange", "change", null, n, r)),
      e.push({ event: n, listeners: t })));
}
var Wr = null,
  si = null;
function W0(e) {
  ip(e, 0);
}
function uo(e) {
  var t = $n(e);
  if (yh(t)) return e;
}
function U0(e, t) {
  if (e === "change") return t;
}
var Yh = !1;
if (At) {
  var zo;
  if (At) {
    var _o = "oninput" in document;
    if (!_o) {
      var Lc = document.createElement("div");
      (Lc.setAttribute("oninput", "return;"),
        (_o = typeof Lc.oninput == "function"));
    }
    zo = _o;
  } else zo = !1;
  Yh = zo && (!document.documentMode || 9 < document.documentMode);
}
function Rc() {
  Wr && (Wr.detachEvent("onpropertychange", Xh), (si = Wr = null));
}
function Xh(e) {
  if (e.propertyName === "value" && uo(si)) {
    var t = [];
    (Gh(t, si, e, ql(e)), Nh(W0, t));
  }
}
function H0(e, t, n) {
  e === "focusin"
    ? (Rc(), (Wr = t), (si = n), Wr.attachEvent("onpropertychange", Xh))
    : e === "focusout" && Rc();
}
function $0(e) {
  if (e === "selectionchange" || e === "keyup" || e === "keydown")
    return uo(si);
}
function K0(e, t) {
  if (e === "click") return uo(t);
}
function G0(e, t) {
  if (e === "input" || e === "change") return uo(t);
}
function Y0(e, t) {
  return (e === t && (e !== 0 || 1 / e === 1 / t)) || (e !== e && t !== t);
}
var pt = typeof Object.is == "function" ? Object.is : Y0;
function oi(e, t) {
  if (pt(e, t)) return !0;
  if (typeof e != "object" || e === null || typeof t != "object" || t === null)
    return !1;
  var n = Object.keys(e),
    r = Object.keys(t);
  if (n.length !== r.length) return !1;
  for (r = 0; r < n.length; r++) {
    var i = n[r];
    if (!ka.call(t, i) || !pt(e[i], t[i])) return !1;
  }
  return !0;
}
function Dc(e) {
  for (; e && e.firstChild;) e = e.firstChild;
  return e;
}
function Ic(e, t) {
  var n = Dc(e);
  e = 0;
  for (var r; n;) {
    if (n.nodeType === 3) {
      if (((r = e + n.textContent.length), e <= t && r >= t))
        return { node: n, offset: t - e };
      e = r;
    }
    e: {
      for (; n;) {
        if (n.nextSibling) {
          n = n.nextSibling;
          break e;
        }
        n = n.parentNode;
      }
      n = void 0;
    }
    n = Dc(n);
  }
}
function Qh(e, t) {
  return e && t
    ? e === t
      ? !0
      : e && e.nodeType === 3
        ? !1
        : t && t.nodeType === 3
          ? Qh(e, t.parentNode)
          : "contains" in e
            ? e.contains(t)
            : e.compareDocumentPosition
              ? !!(e.compareDocumentPosition(t) & 16)
              : !1
    : !1;
}
function Zh() {
  for (var e = window, t = js(); t instanceof e.HTMLIFrameElement;) {
    try {
      var n = typeof t.contentWindow.location.href == "string";
    } catch {
      n = !1;
    }
    if (n) e = t.contentWindow;
    else break;
    t = js(e.document);
  }
  return t;
}
function au(e) {
  var t = e && e.nodeName && e.nodeName.toLowerCase();
  return (
    t &&
    ((t === "input" &&
      (e.type === "text" ||
        e.type === "search" ||
        e.type === "tel" ||
        e.type === "url" ||
        e.type === "password")) ||
      t === "textarea" ||
      e.contentEditable === "true")
  );
}
function X0(e) {
  var t = Zh(),
    n = e.focusedElem,
    r = e.selectionRange;
  if (
    t !== n &&
    n &&
    n.ownerDocument &&
    Qh(n.ownerDocument.documentElement, n)
  ) {
    if (r !== null && au(n)) {
      if (
        ((t = r.start),
        (e = r.end),
        e === void 0 && (e = t),
        "selectionStart" in n)
      )
        ((n.selectionStart = t),
          (n.selectionEnd = Math.min(e, n.value.length)));
      else if (
        ((e = ((t = n.ownerDocument || document) && t.defaultView) || window),
        e.getSelection)
      ) {
        e = e.getSelection();
        var i = n.textContent.length,
          s = Math.min(r.start, i);
        ((r = r.end === void 0 ? s : Math.min(r.end, i)),
          !e.extend && s > r && ((i = r), (r = s), (s = i)),
          (i = Ic(n, s)));
        var o = Ic(n, r);
        i &&
          o &&
          (e.rangeCount !== 1 ||
            e.anchorNode !== i.node ||
            e.anchorOffset !== i.offset ||
            e.focusNode !== o.node ||
            e.focusOffset !== o.offset) &&
          ((t = t.createRange()),
          t.setStart(i.node, i.offset),
          e.removeAllRanges(),
          s > r
            ? (e.addRange(t), e.extend(o.node, o.offset))
            : (t.setEnd(o.node, o.offset), e.addRange(t)));
      }
    }
    for (t = [], e = n; (e = e.parentNode);)
      e.nodeType === 1 &&
        t.push({ element: e, left: e.scrollLeft, top: e.scrollTop });
    for (typeof n.focus == "function" && n.focus(), n = 0; n < t.length; n++)
      ((e = t[n]),
        (e.element.scrollLeft = e.left),
        (e.element.scrollTop = e.top));
  }
}
var Q0 = At && "documentMode" in document && 11 >= document.documentMode,
  Un = null,
  za = null,
  Ur = null,
  _a = !1;
function Vc(e, t, n) {
  var r = n.window === n ? n.document : n.nodeType === 9 ? n : n.ownerDocument;
  _a ||
    Un == null ||
    Un !== js(r) ||
    ((r = Un),
    "selectionStart" in r && au(r)
      ? (r = { start: r.selectionStart, end: r.selectionEnd })
      : ((r = (
          (r.ownerDocument && r.ownerDocument.defaultView) ||
          window
        ).getSelection()),
        (r = {
          anchorNode: r.anchorNode,
          anchorOffset: r.anchorOffset,
          focusNode: r.focusNode,
          focusOffset: r.focusOffset,
        })),
    (Ur && oi(Ur, r)) ||
      ((Ur = r),
      (r = Es(za, "onSelect")),
      0 < r.length &&
        ((t = new iu("onSelect", "select", null, t, n)),
        e.push({ event: t, listeners: r }),
        (t.target = Un))));
}
function Ui(e, t) {
  var n = {};
  return (
    (n[e.toLowerCase()] = t.toLowerCase()),
    (n["Webkit" + e] = "webkit" + t),
    (n["Moz" + e] = "moz" + t),
    n
  );
}
var Hn = {
    animationend: Ui("Animation", "AnimationEnd"),
    animationiteration: Ui("Animation", "AnimationIteration"),
    animationstart: Ui("Animation", "AnimationStart"),
    transitionend: Ui("Transition", "TransitionEnd"),
  },
  Wo = {},
  qh = {};
At &&
  ((qh = document.createElement("div").style),
  "AnimationEvent" in window ||
    (delete Hn.animationend.animation,
    delete Hn.animationiteration.animation,
    delete Hn.animationstart.animation),
  "TransitionEvent" in window || delete Hn.transitionend.transition);
function co(e) {
  if (Wo[e]) return Wo[e];
  if (!Hn[e]) return e;
  var t = Hn[e],
    n;
  for (n in t) if (t.hasOwnProperty(n) && n in qh) return (Wo[e] = t[n]);
  return e;
}
var Jh = co("animationend"),
  ep = co("animationiteration"),
  tp = co("animationstart"),
  np = co("transitionend"),
  rp = new Map(),
  Bc =
    "abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(
      " ",
    );
function un(e, t) {
  (rp.set(e, t), Dn(t, [e]));
}
for (var Uo = 0; Uo < Bc.length; Uo++) {
  var Ho = Bc[Uo],
    Z0 = Ho.toLowerCase(),
    q0 = Ho[0].toUpperCase() + Ho.slice(1);
  un(Z0, "on" + q0);
}
un(Jh, "onAnimationEnd");
un(ep, "onAnimationIteration");
un(tp, "onAnimationStart");
un("dblclick", "onDoubleClick");
un("focusin", "onFocus");
un("focusout", "onBlur");
un(np, "onTransitionEnd");
ar("onMouseEnter", ["mouseout", "mouseover"]);
ar("onMouseLeave", ["mouseout", "mouseover"]);
ar("onPointerEnter", ["pointerout", "pointerover"]);
ar("onPointerLeave", ["pointerout", "pointerover"]);
Dn(
  "onChange",
  "change click focusin focusout input keydown keyup selectionchange".split(
    " ",
  ),
);
Dn(
  "onSelect",
  "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(
    " ",
  ),
);
Dn("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]);
Dn(
  "onCompositionEnd",
  "compositionend focusout keydown keypress keyup mousedown".split(" "),
);
Dn(
  "onCompositionStart",
  "compositionstart focusout keydown keypress keyup mousedown".split(" "),
);
Dn(
  "onCompositionUpdate",
  "compositionupdate focusout keydown keypress keyup mousedown".split(" "),
);
var Br =
    "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(
      " ",
    ),
  J0 = new Set("cancel close invalid load scroll toggle".split(" ").concat(Br));
function Oc(e, t, n) {
  var r = e.type || "unknown-event";
  ((e.currentTarget = n), Zy(r, t, void 0, e), (e.currentTarget = null));
}
function ip(e, t) {
  t = (t & 4) !== 0;
  for (var n = 0; n < e.length; n++) {
    var r = e[n],
      i = r.event;
    r = r.listeners;
    e: {
      var s = void 0;
      if (t)
        for (var o = r.length - 1; 0 <= o; o--) {
          var l = r[o],
            u = l.instance,
            c = l.currentTarget;
          if (((l = l.listener), u !== s && i.isPropagationStopped())) break e;
          (Oc(i, l, c), (s = u));
        }
      else
        for (o = 0; o < r.length; o++) {
          if (
            ((l = r[o]),
            (u = l.instance),
            (c = l.currentTarget),
            (l = l.listener),
            u !== s && i.isPropagationStopped())
          )
            break e;
          (Oc(i, l, c), (s = u));
        }
    }
  }
  if (bs) throw ((e = Va), (bs = !1), (Va = null), e);
}
function $(e, t) {
  var n = t[Ka];
  n === void 0 && (n = t[Ka] = new Set());
  var r = e + "__bubble";
  n.has(r) || (sp(t, e, 2, !1), n.add(r));
}
function $o(e, t, n) {
  var r = 0;
  (t && (r |= 4), sp(n, e, r, t));
}
var Hi = "_reactListening" + Math.random().toString(36).slice(2);
function ai(e) {
  if (!e[Hi]) {
    ((e[Hi] = !0),
      fh.forEach(function (n) {
        n !== "selectionchange" && (J0.has(n) || $o(n, !1, e), $o(n, !0, e));
      }));
    var t = e.nodeType === 9 ? e : e.ownerDocument;
    t === null || t[Hi] || ((t[Hi] = !0), $o("selectionchange", !1, t));
  }
}
function sp(e, t, n, r) {
  switch (Wh(t)) {
    case 1:
      var i = h0;
      break;
    case 4:
      i = p0;
      break;
    default:
      i = nu;
  }
  ((n = i.bind(null, t, n, e)),
    (i = void 0),
    !Ia ||
      (t !== "touchstart" && t !== "touchmove" && t !== "wheel") ||
      (i = !0),
    r
      ? i !== void 0
        ? e.addEventListener(t, n, { capture: !0, passive: i })
        : e.addEventListener(t, n, !0)
      : i !== void 0
        ? e.addEventListener(t, n, { passive: i })
        : e.addEventListener(t, n, !1));
}
function Ko(e, t, n, r, i) {
  var s = r;
  if (!(t & 1) && !(t & 2) && r !== null)
    e: for (;;) {
      if (r === null) return;
      var o = r.tag;
      if (o === 3 || o === 4) {
        var l = r.stateNode.containerInfo;
        if (l === i || (l.nodeType === 8 && l.parentNode === i)) break;
        if (o === 4)
          for (o = r.return; o !== null;) {
            var u = o.tag;
            if (
              (u === 3 || u === 4) &&
              ((u = o.stateNode.containerInfo),
              u === i || (u.nodeType === 8 && u.parentNode === i))
            )
              return;
            o = o.return;
          }
        for (; l !== null;) {
          if (((o = wn(l)), o === null)) return;
          if (((u = o.tag), u === 5 || u === 6)) {
            r = s = o;
            continue e;
          }
          l = l.parentNode;
        }
      }
      r = r.return;
    }
  Nh(function () {
    var c = s,
      d = ql(n),
      f = [];
    e: {
      var h = rp.get(e);
      if (h !== void 0) {
        var m = iu,
          v = e;
        switch (e) {
          case "keypress":
            if (as(n) === 0) break e;
          case "keydown":
          case "keyup":
            m = E0;
            break;
          case "focusin":
            ((v = "focus"), (m = Fo));
            break;
          case "focusout":
            ((v = "blur"), (m = Fo));
            break;
          case "beforeblur":
          case "afterblur":
            m = Fo;
            break;
          case "click":
            if (n.button === 2) break e;
          case "auxclick":
          case "dblclick":
          case "mousedown":
          case "mousemove":
          case "mouseup":
          case "mouseout":
          case "mouseover":
          case "contextmenu":
            m = Tc;
            break;
          case "drag":
          case "dragend":
          case "dragenter":
          case "dragexit":
          case "dragleave":
          case "dragover":
          case "dragstart":
          case "drop":
            m = y0;
            break;
          case "touchcancel":
          case "touchend":
          case "touchmove":
          case "touchstart":
            m = L0;
            break;
          case Jh:
          case ep:
          case tp:
            m = w0;
            break;
          case np:
            m = D0;
            break;
          case "scroll":
            m = m0;
            break;
          case "wheel":
            m = V0;
            break;
          case "copy":
          case "cut":
          case "paste":
            m = j0;
            break;
          case "gotpointercapture":
          case "lostpointercapture":
          case "pointercancel":
          case "pointerdown":
          case "pointermove":
          case "pointerout":
          case "pointerover":
          case "pointerup":
            m = Nc;
        }
        var x = (t & 4) !== 0,
          k = !x && e === "scroll",
          g = x ? (h !== null ? h + "Capture" : null) : h;
        x = [];
        for (var p = c, y; p !== null;) {
          y = p;
          var w = y.stateNode;
          if (
            (y.tag === 5 &&
              w !== null &&
              ((y = w),
              g !== null && ((w = ti(p, g)), w != null && x.push(li(p, w, y)))),
            k)
          )
            break;
          p = p.return;
        }
        0 < x.length &&
          ((h = new m(h, v, null, n, d)), f.push({ event: h, listeners: x }));
      }
    }
    if (!(t & 7)) {
      e: {
        if (
          ((h = e === "mouseover" || e === "pointerover"),
          (m = e === "mouseout" || e === "pointerout"),
          h &&
            n !== Ra &&
            (v = n.relatedTarget || n.fromElement) &&
            (wn(v) || v[Lt]))
        )
          break e;
        if (
          (m || h) &&
          ((h =
            d.window === d
              ? d
              : (h = d.ownerDocument)
                ? h.defaultView || h.parentWindow
                : window),
          m
            ? ((v = n.relatedTarget || n.toElement),
              (m = c),
              (v = v ? wn(v) : null),
              v !== null &&
                ((k = In(v)), v !== k || (v.tag !== 5 && v.tag !== 6)) &&
                (v = null))
            : ((m = null), (v = c)),
          m !== v)
        ) {
          if (
            ((x = Tc),
            (w = "onMouseLeave"),
            (g = "onMouseEnter"),
            (p = "mouse"),
            (e === "pointerout" || e === "pointerover") &&
              ((x = Nc),
              (w = "onPointerLeave"),
              (g = "onPointerEnter"),
              (p = "pointer")),
            (k = m == null ? h : $n(m)),
            (y = v == null ? h : $n(v)),
            (h = new x(w, p + "leave", m, n, d)),
            (h.target = k),
            (h.relatedTarget = y),
            (w = null),
            wn(d) === c &&
              ((x = new x(g, p + "enter", v, n, d)),
              (x.target = y),
              (x.relatedTarget = k),
              (w = x)),
            (k = w),
            m && v)
          )
            t: {
              for (x = m, g = v, p = 0, y = x; y; y = On(y)) p++;
              for (y = 0, w = g; w; w = On(w)) y++;
              for (; 0 < p - y;) ((x = On(x)), p--);
              for (; 0 < y - p;) ((g = On(g)), y--);
              for (; p--;) {
                if (x === g || (g !== null && x === g.alternate)) break t;
                ((x = On(x)), (g = On(g)));
              }
              x = null;
            }
          else x = null;
          (m !== null && Fc(f, h, m, x, !1),
            v !== null && k !== null && Fc(f, k, v, x, !0));
        }
      }
      e: {
        if (
          ((h = c ? $n(c) : window),
          (m = h.nodeName && h.nodeName.toLowerCase()),
          m === "select" || (m === "input" && h.type === "file"))
        )
          var S = U0;
        else if (Ac(h))
          if (Yh) S = G0;
          else {
            S = $0;
            var b = H0;
          }
        else
          (m = h.nodeName) &&
            m.toLowerCase() === "input" &&
            (h.type === "checkbox" || h.type === "radio") &&
            (S = K0);
        if (S && (S = S(e, c))) {
          Gh(f, S, n, d);
          break e;
        }
        (b && b(e, h, c),
          e === "focusout" &&
            (b = h._wrapperState) &&
            b.controlled &&
            h.type === "number" &&
            Na(h, "number", h.value));
      }
      switch (((b = c ? $n(c) : window), e)) {
        case "focusin":
          (Ac(b) || b.contentEditable === "true") &&
            ((Un = b), (za = c), (Ur = null));
          break;
        case "focusout":
          Ur = za = Un = null;
          break;
        case "mousedown":
          _a = !0;
          break;
        case "contextmenu":
        case "mouseup":
        case "dragend":
          ((_a = !1), Vc(f, n, d));
          break;
        case "selectionchange":
          if (Q0) break;
        case "keydown":
        case "keyup":
          Vc(f, n, d);
      }
      var P;
      if (ou)
        e: {
          switch (e) {
            case "compositionstart":
              var T = "onCompositionStart";
              break e;
            case "compositionend":
              T = "onCompositionEnd";
              break e;
            case "compositionupdate":
              T = "onCompositionUpdate";
              break e;
          }
          T = void 0;
        }
      else
        Wn
          ? $h(e, n) && (T = "onCompositionEnd")
          : e === "keydown" && n.keyCode === 229 && (T = "onCompositionStart");
      (T &&
        (Hh &&
          n.locale !== "ko" &&
          (Wn || T !== "onCompositionStart"
            ? T === "onCompositionEnd" && Wn && (P = Uh())
            : (($t = d),
              (ru = "value" in $t ? $t.value : $t.textContent),
              (Wn = !0))),
        (b = Es(c, T)),
        0 < b.length &&
          ((T = new Pc(T, e, null, n, d)),
          f.push({ event: T, listeners: b }),
          P ? (T.data = P) : ((P = Kh(n)), P !== null && (T.data = P)))),
        (P = O0 ? F0(e, n) : z0(e, n)) &&
          ((c = Es(c, "onBeforeInput")),
          0 < c.length &&
            ((d = new Pc("onBeforeInput", "beforeinput", null, n, d)),
            f.push({ event: d, listeners: c }),
            (d.data = P))));
    }
    ip(f, t);
  });
}
function li(e, t, n) {
  return { instance: e, listener: t, currentTarget: n };
}
function Es(e, t) {
  for (var n = t + "Capture", r = []; e !== null;) {
    var i = e,
      s = i.stateNode;
    (i.tag === 5 &&
      s !== null &&
      ((i = s),
      (s = ti(e, n)),
      s != null && r.unshift(li(e, s, i)),
      (s = ti(e, t)),
      s != null && r.push(li(e, s, i))),
      (e = e.return));
  }
  return r;
}
function On(e) {
  if (e === null) return null;
  do e = e.return;
  while (e && e.tag !== 5);
  return e || null;
}
function Fc(e, t, n, r, i) {
  for (var s = t._reactName, o = []; n !== null && n !== r;) {
    var l = n,
      u = l.alternate,
      c = l.stateNode;
    if (u !== null && u === r) break;
    (l.tag === 5 &&
      c !== null &&
      ((l = c),
      i
        ? ((u = ti(n, s)), u != null && o.unshift(li(n, u, l)))
        : i || ((u = ti(n, s)), u != null && o.push(li(n, u, l)))),
      (n = n.return));
  }
  o.length !== 0 && e.push({ event: t, listeners: o });
}
var ev = /\r\n?/g,
  tv = /\u0000|\uFFFD/g;
function zc(e) {
  return (typeof e == "string" ? e : "" + e)
    .replace(
      ev,
      `
`,
    )
    .replace(tv, "");
}
function $i(e, t, n) {
  if (((t = zc(t)), zc(e) !== t && n)) throw Error(C(425));
}
function Ms() {}
var Wa = null,
  Ua = null;
function Ha(e, t) {
  return (
    e === "textarea" ||
    e === "noscript" ||
    typeof t.children == "string" ||
    typeof t.children == "number" ||
    (typeof t.dangerouslySetInnerHTML == "object" &&
      t.dangerouslySetInnerHTML !== null &&
      t.dangerouslySetInnerHTML.__html != null)
  );
}
var $a = typeof setTimeout == "function" ? setTimeout : void 0,
  nv = typeof clearTimeout == "function" ? clearTimeout : void 0,
  _c = typeof Promise == "function" ? Promise : void 0,
  rv =
    typeof queueMicrotask == "function"
      ? queueMicrotask
      : typeof _c < "u"
        ? function (e) {
            return _c.resolve(null).then(e).catch(iv);
          }
        : $a;
function iv(e) {
  setTimeout(function () {
    throw e;
  });
}
function Go(e, t) {
  var n = t,
    r = 0;
  do {
    var i = n.nextSibling;
    if ((e.removeChild(n), i && i.nodeType === 8))
      if (((n = i.data), n === "/$")) {
        if (r === 0) {
          (e.removeChild(i), ii(t));
          return;
        }
        r--;
      } else (n !== "$" && n !== "$?" && n !== "$!") || r++;
    n = i;
  } while (n);
  ii(t);
}
function qt(e) {
  for (; e != null; e = e.nextSibling) {
    var t = e.nodeType;
    if (t === 1 || t === 3) break;
    if (t === 8) {
      if (((t = e.data), t === "$" || t === "$!" || t === "$?")) break;
      if (t === "/$") return null;
    }
  }
  return e;
}
function Wc(e) {
  e = e.previousSibling;
  for (var t = 0; e;) {
    if (e.nodeType === 8) {
      var n = e.data;
      if (n === "$" || n === "$!" || n === "$?") {
        if (t === 0) return e;
        t--;
      } else n === "/$" && t++;
    }
    e = e.previousSibling;
  }
  return null;
}
var xr = Math.random().toString(36).slice(2),
  wt = "__reactFiber$" + xr,
  ui = "__reactProps$" + xr,
  Lt = "__reactContainer$" + xr,
  Ka = "__reactEvents$" + xr,
  sv = "__reactListeners$" + xr,
  ov = "__reactHandles$" + xr;
function wn(e) {
  var t = e[wt];
  if (t) return t;
  for (var n = e.parentNode; n;) {
    if ((t = n[Lt] || n[wt])) {
      if (
        ((n = t.alternate),
        t.child !== null || (n !== null && n.child !== null))
      )
        for (e = Wc(e); e !== null;) {
          if ((n = e[wt])) return n;
          e = Wc(e);
        }
      return t;
    }
    ((e = n), (n = e.parentNode));
  }
  return null;
}
function Ci(e) {
  return (
    (e = e[wt] || e[Lt]),
    !e || (e.tag !== 5 && e.tag !== 6 && e.tag !== 13 && e.tag !== 3) ? null : e
  );
}
function $n(e) {
  if (e.tag === 5 || e.tag === 6) return e.stateNode;
  throw Error(C(33));
}
function fo(e) {
  return e[ui] || null;
}
var Ga = [],
  Kn = -1;
function cn(e) {
  return { current: e };
}
function G(e) {
  0 > Kn || ((e.current = Ga[Kn]), (Ga[Kn] = null), Kn--);
}
function H(e, t) {
  (Kn++, (Ga[Kn] = e.current), (e.current = t));
}
var on = {},
  je = cn(on),
  De = cn(!1),
  En = on;
function lr(e, t) {
  var n = e.type.contextTypes;
  if (!n) return on;
  var r = e.stateNode;
  if (r && r.__reactInternalMemoizedUnmaskedChildContext === t)
    return r.__reactInternalMemoizedMaskedChildContext;
  var i = {},
    s;
  for (s in n) i[s] = t[s];
  return (
    r &&
      ((e = e.stateNode),
      (e.__reactInternalMemoizedUnmaskedChildContext = t),
      (e.__reactInternalMemoizedMaskedChildContext = i)),
    i
  );
}
function Ie(e) {
  return ((e = e.childContextTypes), e != null);
}
function As() {
  (G(De), G(je));
}
function Uc(e, t, n) {
  if (je.current !== on) throw Error(C(168));
  (H(je, t), H(De, n));
}
function op(e, t, n) {
  var r = e.stateNode;
  if (((t = t.childContextTypes), typeof r.getChildContext != "function"))
    return n;
  r = r.getChildContext();
  for (var i in r) if (!(i in t)) throw Error(C(108, Hy(e) || "Unknown", i));
  return Z({}, n, r);
}
function Ls(e) {
  return (
    (e =
      ((e = e.stateNode) && e.__reactInternalMemoizedMergedChildContext) || on),
    (En = je.current),
    H(je, e),
    H(De, De.current),
    !0
  );
}
function Hc(e, t, n) {
  var r = e.stateNode;
  if (!r) throw Error(C(169));
  (n
    ? ((e = op(e, t, En)),
      (r.__reactInternalMemoizedMergedChildContext = e),
      G(De),
      G(je),
      H(je, e))
    : G(De),
    H(De, n));
}
var Tt = null,
  ho = !1,
  Yo = !1;
function ap(e) {
  Tt === null ? (Tt = [e]) : Tt.push(e);
}
function av(e) {
  ((ho = !0), ap(e));
}
function dn() {
  if (!Yo && Tt !== null) {
    Yo = !0;
    var e = 0,
      t = z;
    try {
      var n = Tt;
      for (z = 1; e < n.length; e++) {
        var r = n[e];
        do r = r(!0);
        while (r !== null);
      }
      ((Tt = null), (ho = !1));
    } catch (i) {
      throw (Tt !== null && (Tt = Tt.slice(e + 1)), Lh(Jl, dn), i);
    } finally {
      ((z = t), (Yo = !1));
    }
  }
  return null;
}
var Gn = [],
  Yn = 0,
  Rs = null,
  Ds = 0,
  Xe = [],
  Qe = 0,
  Mn = null,
  Pt = 1,
  Nt = "";
function yn(e, t) {
  ((Gn[Yn++] = Ds), (Gn[Yn++] = Rs), (Rs = e), (Ds = t));
}
function lp(e, t, n) {
  ((Xe[Qe++] = Pt), (Xe[Qe++] = Nt), (Xe[Qe++] = Mn), (Mn = e));
  var r = Pt;
  e = Nt;
  var i = 32 - dt(r) - 1;
  ((r &= ~(1 << i)), (n += 1));
  var s = 32 - dt(t) + i;
  if (30 < s) {
    var o = i - (i % 5);
    ((s = (r & ((1 << o) - 1)).toString(32)),
      (r >>= o),
      (i -= o),
      (Pt = (1 << (32 - dt(t) + i)) | (n << i) | r),
      (Nt = s + e));
  } else ((Pt = (1 << s) | (n << i) | r), (Nt = e));
}
function lu(e) {
  e.return !== null && (yn(e, 1), lp(e, 1, 0));
}
function uu(e) {
  for (; e === Rs;)
    ((Rs = Gn[--Yn]), (Gn[Yn] = null), (Ds = Gn[--Yn]), (Gn[Yn] = null));
  for (; e === Mn;)
    ((Mn = Xe[--Qe]),
      (Xe[Qe] = null),
      (Nt = Xe[--Qe]),
      (Xe[Qe] = null),
      (Pt = Xe[--Qe]),
      (Xe[Qe] = null));
}
var We = null,
  _e = null,
  Y = !1,
  ct = null;
function up(e, t) {
  var n = Ze(5, null, null, 0);
  ((n.elementType = "DELETED"),
    (n.stateNode = t),
    (n.return = e),
    (t = e.deletions),
    t === null ? ((e.deletions = [n]), (e.flags |= 16)) : t.push(n));
}
function $c(e, t) {
  switch (e.tag) {
    case 5:
      var n = e.type;
      return (
        (t =
          t.nodeType !== 1 || n.toLowerCase() !== t.nodeName.toLowerCase()
            ? null
            : t),
        t !== null
          ? ((e.stateNode = t), (We = e), (_e = qt(t.firstChild)), !0)
          : !1
      );
    case 6:
      return (
        (t = e.pendingProps === "" || t.nodeType !== 3 ? null : t),
        t !== null ? ((e.stateNode = t), (We = e), (_e = null), !0) : !1
      );
    case 13:
      return (
        (t = t.nodeType !== 8 ? null : t),
        t !== null
          ? ((n = Mn !== null ? { id: Pt, overflow: Nt } : null),
            (e.memoizedState = {
              dehydrated: t,
              treeContext: n,
              retryLane: 1073741824,
            }),
            (n = Ze(18, null, null, 0)),
            (n.stateNode = t),
            (n.return = e),
            (e.child = n),
            (We = e),
            (_e = null),
            !0)
          : !1
      );
    default:
      return !1;
  }
}
function Ya(e) {
  return (e.mode & 1) !== 0 && (e.flags & 128) === 0;
}
function Xa(e) {
  if (Y) {
    var t = _e;
    if (t) {
      var n = t;
      if (!$c(e, t)) {
        if (Ya(e)) throw Error(C(418));
        t = qt(n.nextSibling);
        var r = We;
        t && $c(e, t)
          ? up(r, n)
          : ((e.flags = (e.flags & -4097) | 2), (Y = !1), (We = e));
      }
    } else {
      if (Ya(e)) throw Error(C(418));
      ((e.flags = (e.flags & -4097) | 2), (Y = !1), (We = e));
    }
  }
}
function Kc(e) {
  for (e = e.return; e !== null && e.tag !== 5 && e.tag !== 3 && e.tag !== 13;)
    e = e.return;
  We = e;
}
function Ki(e) {
  if (e !== We) return !1;
  if (!Y) return (Kc(e), (Y = !0), !1);
  var t;
  if (
    ((t = e.tag !== 3) &&
      !(t = e.tag !== 5) &&
      ((t = e.type),
      (t = t !== "head" && t !== "body" && !Ha(e.type, e.memoizedProps))),
    t && (t = _e))
  ) {
    if (Ya(e)) throw (cp(), Error(C(418)));
    for (; t;) (up(e, t), (t = qt(t.nextSibling)));
  }
  if ((Kc(e), e.tag === 13)) {
    if (((e = e.memoizedState), (e = e !== null ? e.dehydrated : null), !e))
      throw Error(C(317));
    e: {
      for (e = e.nextSibling, t = 0; e;) {
        if (e.nodeType === 8) {
          var n = e.data;
          if (n === "/$") {
            if (t === 0) {
              _e = qt(e.nextSibling);
              break e;
            }
            t--;
          } else (n !== "$" && n !== "$!" && n !== "$?") || t++;
        }
        e = e.nextSibling;
      }
      _e = null;
    }
  } else _e = We ? qt(e.stateNode.nextSibling) : null;
  return !0;
}
function cp() {
  for (var e = _e; e;) e = qt(e.nextSibling);
}
function ur() {
  ((_e = We = null), (Y = !1));
}
function cu(e) {
  ct === null ? (ct = [e]) : ct.push(e);
}
var lv = It.ReactCurrentBatchConfig;
function Er(e, t, n) {
  if (
    ((e = n.ref), e !== null && typeof e != "function" && typeof e != "object")
  ) {
    if (n._owner) {
      if (((n = n._owner), n)) {
        if (n.tag !== 1) throw Error(C(309));
        var r = n.stateNode;
      }
      if (!r) throw Error(C(147, e));
      var i = r,
        s = "" + e;
      return t !== null &&
        t.ref !== null &&
        typeof t.ref == "function" &&
        t.ref._stringRef === s
        ? t.ref
        : ((t = function (o) {
            var l = i.refs;
            o === null ? delete l[s] : (l[s] = o);
          }),
          (t._stringRef = s),
          t);
    }
    if (typeof e != "string") throw Error(C(284));
    if (!n._owner) throw Error(C(290, e));
  }
  return e;
}
function Gi(e, t) {
  throw (
    (e = Object.prototype.toString.call(t)),
    Error(
      C(
        31,
        e === "[object Object]"
          ? "object with keys {" + Object.keys(t).join(", ") + "}"
          : e,
      ),
    )
  );
}
function Gc(e) {
  var t = e._init;
  return t(e._payload);
}
function dp(e) {
  function t(g, p) {
    if (e) {
      var y = g.deletions;
      y === null ? ((g.deletions = [p]), (g.flags |= 16)) : y.push(p);
    }
  }
  function n(g, p) {
    if (!e) return null;
    for (; p !== null;) (t(g, p), (p = p.sibling));
    return null;
  }
  function r(g, p) {
    for (g = new Map(); p !== null;)
      (p.key !== null ? g.set(p.key, p) : g.set(p.index, p), (p = p.sibling));
    return g;
  }
  function i(g, p) {
    return ((g = nn(g, p)), (g.index = 0), (g.sibling = null), g);
  }
  function s(g, p, y) {
    return (
      (g.index = y),
      e
        ? ((y = g.alternate),
          y !== null
            ? ((y = y.index), y < p ? ((g.flags |= 2), p) : y)
            : ((g.flags |= 2), p))
        : ((g.flags |= 1048576), p)
    );
  }
  function o(g) {
    return (e && g.alternate === null && (g.flags |= 2), g);
  }
  function l(g, p, y, w) {
    return p === null || p.tag !== 6
      ? ((p = ta(y, g.mode, w)), (p.return = g), p)
      : ((p = i(p, y)), (p.return = g), p);
  }
  function u(g, p, y, w) {
    var S = y.type;
    return S === _n
      ? d(g, p, y.props.children, w, y.key)
      : p !== null &&
          (p.elementType === S ||
            (typeof S == "object" &&
              S !== null &&
              S.$$typeof === _t &&
              Gc(S) === p.type))
        ? ((w = i(p, y.props)), (w.ref = Er(g, p, y)), (w.return = g), w)
        : ((w = ps(y.type, y.key, y.props, null, g.mode, w)),
          (w.ref = Er(g, p, y)),
          (w.return = g),
          w);
  }
  function c(g, p, y, w) {
    return p === null ||
      p.tag !== 4 ||
      p.stateNode.containerInfo !== y.containerInfo ||
      p.stateNode.implementation !== y.implementation
      ? ((p = na(y, g.mode, w)), (p.return = g), p)
      : ((p = i(p, y.children || [])), (p.return = g), p);
  }
  function d(g, p, y, w, S) {
    return p === null || p.tag !== 7
      ? ((p = Tn(y, g.mode, w, S)), (p.return = g), p)
      : ((p = i(p, y)), (p.return = g), p);
  }
  function f(g, p, y) {
    if ((typeof p == "string" && p !== "") || typeof p == "number")
      return ((p = ta("" + p, g.mode, y)), (p.return = g), p);
    if (typeof p == "object" && p !== null) {
      switch (p.$$typeof) {
        case Vi:
          return (
            (y = ps(p.type, p.key, p.props, null, g.mode, y)),
            (y.ref = Er(g, null, p)),
            (y.return = g),
            y
          );
        case zn:
          return ((p = na(p, g.mode, y)), (p.return = g), p);
        case _t:
          var w = p._init;
          return f(g, w(p._payload), y);
      }
      if (Ir(p) || br(p))
        return ((p = Tn(p, g.mode, y, null)), (p.return = g), p);
      Gi(g, p);
    }
    return null;
  }
  function h(g, p, y, w) {
    var S = p !== null ? p.key : null;
    if ((typeof y == "string" && y !== "") || typeof y == "number")
      return S !== null ? null : l(g, p, "" + y, w);
    if (typeof y == "object" && y !== null) {
      switch (y.$$typeof) {
        case Vi:
          return y.key === S ? u(g, p, y, w) : null;
        case zn:
          return y.key === S ? c(g, p, y, w) : null;
        case _t:
          return ((S = y._init), h(g, p, S(y._payload), w));
      }
      if (Ir(y) || br(y)) return S !== null ? null : d(g, p, y, w, null);
      Gi(g, y);
    }
    return null;
  }
  function m(g, p, y, w, S) {
    if ((typeof w == "string" && w !== "") || typeof w == "number")
      return ((g = g.get(y) || null), l(p, g, "" + w, S));
    if (typeof w == "object" && w !== null) {
      switch (w.$$typeof) {
        case Vi:
          return (
            (g = g.get(w.key === null ? y : w.key) || null),
            u(p, g, w, S)
          );
        case zn:
          return (
            (g = g.get(w.key === null ? y : w.key) || null),
            c(p, g, w, S)
          );
        case _t:
          var b = w._init;
          return m(g, p, y, b(w._payload), S);
      }
      if (Ir(w) || br(w)) return ((g = g.get(y) || null), d(p, g, w, S, null));
      Gi(p, w);
    }
    return null;
  }
  function v(g, p, y, w) {
    for (
      var S = null, b = null, P = p, T = (p = 0), V = null;
      P !== null && T < y.length;
      T++
    ) {
      P.index > T ? ((V = P), (P = null)) : (V = P.sibling);
      var N = h(g, P, y[T], w);
      if (N === null) {
        P === null && (P = V);
        break;
      }
      (e && P && N.alternate === null && t(g, P),
        (p = s(N, p, T)),
        b === null ? (S = N) : (b.sibling = N),
        (b = N),
        (P = V));
    }
    if (T === y.length) return (n(g, P), Y && yn(g, T), S);
    if (P === null) {
      for (; T < y.length; T++)
        ((P = f(g, y[T], w)),
          P !== null &&
            ((p = s(P, p, T)),
            b === null ? (S = P) : (b.sibling = P),
            (b = P)));
      return (Y && yn(g, T), S);
    }
    for (P = r(g, P); T < y.length; T++)
      ((V = m(P, g, T, y[T], w)),
        V !== null &&
          (e && V.alternate !== null && P.delete(V.key === null ? T : V.key),
          (p = s(V, p, T)),
          b === null ? (S = V) : (b.sibling = V),
          (b = V)));
    return (
      e &&
        P.forEach(function (O) {
          return t(g, O);
        }),
      Y && yn(g, T),
      S
    );
  }
  function x(g, p, y, w) {
    var S = br(y);
    if (typeof S != "function") throw Error(C(150));
    if (((y = S.call(y)), y == null)) throw Error(C(151));
    for (
      var b = (S = null), P = p, T = (p = 0), V = null, N = y.next();
      P !== null && !N.done;
      T++, N = y.next()
    ) {
      P.index > T ? ((V = P), (P = null)) : (V = P.sibling);
      var O = h(g, P, N.value, w);
      if (O === null) {
        P === null && (P = V);
        break;
      }
      (e && P && O.alternate === null && t(g, P),
        (p = s(O, p, T)),
        b === null ? (S = O) : (b.sibling = O),
        (b = O),
        (P = V));
    }
    if (N.done) return (n(g, P), Y && yn(g, T), S);
    if (P === null) {
      for (; !N.done; T++, N = y.next())
        ((N = f(g, N.value, w)),
          N !== null &&
            ((p = s(N, p, T)),
            b === null ? (S = N) : (b.sibling = N),
            (b = N)));
      return (Y && yn(g, T), S);
    }
    for (P = r(g, P); !N.done; T++, N = y.next())
      ((N = m(P, g, T, N.value, w)),
        N !== null &&
          (e && N.alternate !== null && P.delete(N.key === null ? T : N.key),
          (p = s(N, p, T)),
          b === null ? (S = N) : (b.sibling = N),
          (b = N)));
    return (
      e &&
        P.forEach(function (ne) {
          return t(g, ne);
        }),
      Y && yn(g, T),
      S
    );
  }
  function k(g, p, y, w) {
    if (
      (typeof y == "object" &&
        y !== null &&
        y.type === _n &&
        y.key === null &&
        (y = y.props.children),
      typeof y == "object" && y !== null)
    ) {
      switch (y.$$typeof) {
        case Vi:
          e: {
            for (var S = y.key, b = p; b !== null;) {
              if (b.key === S) {
                if (((S = y.type), S === _n)) {
                  if (b.tag === 7) {
                    (n(g, b.sibling),
                      (p = i(b, y.props.children)),
                      (p.return = g),
                      (g = p));
                    break e;
                  }
                } else if (
                  b.elementType === S ||
                  (typeof S == "object" &&
                    S !== null &&
                    S.$$typeof === _t &&
                    Gc(S) === b.type)
                ) {
                  (n(g, b.sibling),
                    (p = i(b, y.props)),
                    (p.ref = Er(g, b, y)),
                    (p.return = g),
                    (g = p));
                  break e;
                }
                n(g, b);
                break;
              } else t(g, b);
              b = b.sibling;
            }
            y.type === _n
              ? ((p = Tn(y.props.children, g.mode, w, y.key)),
                (p.return = g),
                (g = p))
              : ((w = ps(y.type, y.key, y.props, null, g.mode, w)),
                (w.ref = Er(g, p, y)),
                (w.return = g),
                (g = w));
          }
          return o(g);
        case zn:
          e: {
            for (b = y.key; p !== null;) {
              if (p.key === b)
                if (
                  p.tag === 4 &&
                  p.stateNode.containerInfo === y.containerInfo &&
                  p.stateNode.implementation === y.implementation
                ) {
                  (n(g, p.sibling),
                    (p = i(p, y.children || [])),
                    (p.return = g),
                    (g = p));
                  break e;
                } else {
                  n(g, p);
                  break;
                }
              else t(g, p);
              p = p.sibling;
            }
            ((p = na(y, g.mode, w)), (p.return = g), (g = p));
          }
          return o(g);
        case _t:
          return ((b = y._init), k(g, p, b(y._payload), w));
      }
      if (Ir(y)) return v(g, p, y, w);
      if (br(y)) return x(g, p, y, w);
      Gi(g, y);
    }
    return (typeof y == "string" && y !== "") || typeof y == "number"
      ? ((y = "" + y),
        p !== null && p.tag === 6
          ? (n(g, p.sibling), (p = i(p, y)), (p.return = g), (g = p))
          : (n(g, p), (p = ta(y, g.mode, w)), (p.return = g), (g = p)),
        o(g))
      : n(g, p);
  }
  return k;
}
var cr = dp(!0),
  fp = dp(!1),
  Is = cn(null),
  Vs = null,
  Xn = null,
  du = null;
function fu() {
  du = Xn = Vs = null;
}
function hu(e) {
  var t = Is.current;
  (G(Is), (e._currentValue = t));
}
function Qa(e, t, n) {
  for (; e !== null;) {
    var r = e.alternate;
    if (
      ((e.childLanes & t) !== t
        ? ((e.childLanes |= t), r !== null && (r.childLanes |= t))
        : r !== null && (r.childLanes & t) !== t && (r.childLanes |= t),
      e === n)
    )
      break;
    e = e.return;
  }
}
function sr(e, t) {
  ((Vs = e),
    (du = Xn = null),
    (e = e.dependencies),
    e !== null &&
      e.firstContext !== null &&
      (e.lanes & t && (Re = !0), (e.firstContext = null)));
}
function nt(e) {
  var t = e._currentValue;
  if (du !== e)
    if (((e = { context: e, memoizedValue: t, next: null }), Xn === null)) {
      if (Vs === null) throw Error(C(308));
      ((Xn = e), (Vs.dependencies = { lanes: 0, firstContext: e }));
    } else Xn = Xn.next = e;
  return t;
}
var kn = null;
function pu(e) {
  kn === null ? (kn = [e]) : kn.push(e);
}
function hp(e, t, n, r) {
  var i = t.interleaved;
  return (
    i === null ? ((n.next = n), pu(t)) : ((n.next = i.next), (i.next = n)),
    (t.interleaved = n),
    Rt(e, r)
  );
}
function Rt(e, t) {
  e.lanes |= t;
  var n = e.alternate;
  for (n !== null && (n.lanes |= t), n = e, e = e.return; e !== null;)
    ((e.childLanes |= t),
      (n = e.alternate),
      n !== null && (n.childLanes |= t),
      (n = e),
      (e = e.return));
  return n.tag === 3 ? n.stateNode : null;
}
var Wt = !1;
function mu(e) {
  e.updateQueue = {
    baseState: e.memoizedState,
    firstBaseUpdate: null,
    lastBaseUpdate: null,
    shared: { pending: null, interleaved: null, lanes: 0 },
    effects: null,
  };
}
function pp(e, t) {
  ((e = e.updateQueue),
    t.updateQueue === e &&
      (t.updateQueue = {
        baseState: e.baseState,
        firstBaseUpdate: e.firstBaseUpdate,
        lastBaseUpdate: e.lastBaseUpdate,
        shared: e.shared,
        effects: e.effects,
      }));
}
function Mt(e, t) {
  return {
    eventTime: e,
    lane: t,
    tag: 0,
    payload: null,
    callback: null,
    next: null,
  };
}
function Jt(e, t, n) {
  var r = e.updateQueue;
  if (r === null) return null;
  if (((r = r.shared), F & 2)) {
    var i = r.pending;
    return (
      i === null ? (t.next = t) : ((t.next = i.next), (i.next = t)),
      (r.pending = t),
      Rt(e, n)
    );
  }
  return (
    (i = r.interleaved),
    i === null ? ((t.next = t), pu(r)) : ((t.next = i.next), (i.next = t)),
    (r.interleaved = t),
    Rt(e, n)
  );
}
function ls(e, t, n) {
  if (
    ((t = t.updateQueue), t !== null && ((t = t.shared), (n & 4194240) !== 0))
  ) {
    var r = t.lanes;
    ((r &= e.pendingLanes), (n |= r), (t.lanes = n), eu(e, n));
  }
}
function Yc(e, t) {
  var n = e.updateQueue,
    r = e.alternate;
  if (r !== null && ((r = r.updateQueue), n === r)) {
    var i = null,
      s = null;
    if (((n = n.firstBaseUpdate), n !== null)) {
      do {
        var o = {
          eventTime: n.eventTime,
          lane: n.lane,
          tag: n.tag,
          payload: n.payload,
          callback: n.callback,
          next: null,
        };
        (s === null ? (i = s = o) : (s = s.next = o), (n = n.next));
      } while (n !== null);
      s === null ? (i = s = t) : (s = s.next = t);
    } else i = s = t;
    ((n = {
      baseState: r.baseState,
      firstBaseUpdate: i,
      lastBaseUpdate: s,
      shared: r.shared,
      effects: r.effects,
    }),
      (e.updateQueue = n));
    return;
  }
  ((e = n.lastBaseUpdate),
    e === null ? (n.firstBaseUpdate = t) : (e.next = t),
    (n.lastBaseUpdate = t));
}
function Bs(e, t, n, r) {
  var i = e.updateQueue;
  Wt = !1;
  var s = i.firstBaseUpdate,
    o = i.lastBaseUpdate,
    l = i.shared.pending;
  if (l !== null) {
    i.shared.pending = null;
    var u = l,
      c = u.next;
    ((u.next = null), o === null ? (s = c) : (o.next = c), (o = u));
    var d = e.alternate;
    d !== null &&
      ((d = d.updateQueue),
      (l = d.lastBaseUpdate),
      l !== o &&
        (l === null ? (d.firstBaseUpdate = c) : (l.next = c),
        (d.lastBaseUpdate = u)));
  }
  if (s !== null) {
    var f = i.baseState;
    ((o = 0), (d = c = u = null), (l = s));
    do {
      var h = l.lane,
        m = l.eventTime;
      if ((r & h) === h) {
        d !== null &&
          (d = d.next =
            {
              eventTime: m,
              lane: 0,
              tag: l.tag,
              payload: l.payload,
              callback: l.callback,
              next: null,
            });
        e: {
          var v = e,
            x = l;
          switch (((h = t), (m = n), x.tag)) {
            case 1:
              if (((v = x.payload), typeof v == "function")) {
                f = v.call(m, f, h);
                break e;
              }
              f = v;
              break e;
            case 3:
              v.flags = (v.flags & -65537) | 128;
            case 0:
              if (
                ((v = x.payload),
                (h = typeof v == "function" ? v.call(m, f, h) : v),
                h == null)
              )
                break e;
              f = Z({}, f, h);
              break e;
            case 2:
              Wt = !0;
          }
        }
        l.callback !== null &&
          l.lane !== 0 &&
          ((e.flags |= 64),
          (h = i.effects),
          h === null ? (i.effects = [l]) : h.push(l));
      } else
        ((m = {
          eventTime: m,
          lane: h,
          tag: l.tag,
          payload: l.payload,
          callback: l.callback,
          next: null,
        }),
          d === null ? ((c = d = m), (u = f)) : (d = d.next = m),
          (o |= h));
      if (((l = l.next), l === null)) {
        if (((l = i.shared.pending), l === null)) break;
        ((h = l),
          (l = h.next),
          (h.next = null),
          (i.lastBaseUpdate = h),
          (i.shared.pending = null));
      }
    } while (!0);
    if (
      (d === null && (u = f),
      (i.baseState = u),
      (i.firstBaseUpdate = c),
      (i.lastBaseUpdate = d),
      (t = i.shared.interleaved),
      t !== null)
    ) {
      i = t;
      do ((o |= i.lane), (i = i.next));
      while (i !== t);
    } else s === null && (i.shared.lanes = 0);
    ((Ln |= o), (e.lanes = o), (e.memoizedState = f));
  }
}
function Xc(e, t, n) {
  if (((e = t.effects), (t.effects = null), e !== null))
    for (t = 0; t < e.length; t++) {
      var r = e[t],
        i = r.callback;
      if (i !== null) {
        if (((r.callback = null), (r = n), typeof i != "function"))
          throw Error(C(191, i));
        i.call(r);
      }
    }
}
var Ti = {},
  jt = cn(Ti),
  ci = cn(Ti),
  di = cn(Ti);
function jn(e) {
  if (e === Ti) throw Error(C(174));
  return e;
}
function gu(e, t) {
  switch ((H(di, t), H(ci, e), H(jt, Ti), (e = t.nodeType), e)) {
    case 9:
    case 11:
      t = (t = t.documentElement) ? t.namespaceURI : Ma(null, "");
      break;
    default:
      ((e = e === 8 ? t.parentNode : t),
        (t = e.namespaceURI || null),
        (e = e.tagName),
        (t = Ma(t, e)));
  }
  (G(jt), H(jt, t));
}
function dr() {
  (G(jt), G(ci), G(di));
}
function mp(e) {
  jn(di.current);
  var t = jn(jt.current),
    n = Ma(t, e.type);
  t !== n && (H(ci, e), H(jt, n));
}
function yu(e) {
  ci.current === e && (G(jt), G(ci));
}
var X = cn(0);
function Os(e) {
  for (var t = e; t !== null;) {
    if (t.tag === 13) {
      var n = t.memoizedState;
      if (
        n !== null &&
        ((n = n.dehydrated), n === null || n.data === "$?" || n.data === "$!")
      )
        return t;
    } else if (t.tag === 19 && t.memoizedProps.revealOrder !== void 0) {
      if (t.flags & 128) return t;
    } else if (t.child !== null) {
      ((t.child.return = t), (t = t.child));
      continue;
    }
    if (t === e) break;
    for (; t.sibling === null;) {
      if (t.return === null || t.return === e) return null;
      t = t.return;
    }
    ((t.sibling.return = t.return), (t = t.sibling));
  }
  return null;
}
var Xo = [];
function vu() {
  for (var e = 0; e < Xo.length; e++)
    Xo[e]._workInProgressVersionPrimary = null;
  Xo.length = 0;
}
var us = It.ReactCurrentDispatcher,
  Qo = It.ReactCurrentBatchConfig,
  An = 0,
  Q = null,
  ae = null,
  de = null,
  Fs = !1,
  Hr = !1,
  fi = 0,
  uv = 0;
function xe() {
  throw Error(C(321));
}
function xu(e, t) {
  if (t === null) return !1;
  for (var n = 0; n < t.length && n < e.length; n++)
    if (!pt(e[n], t[n])) return !1;
  return !0;
}
function wu(e, t, n, r, i, s) {
  if (
    ((An = s),
    (Q = t),
    (t.memoizedState = null),
    (t.updateQueue = null),
    (t.lanes = 0),
    (us.current = e === null || e.memoizedState === null ? hv : pv),
    (e = n(r, i)),
    Hr)
  ) {
    s = 0;
    do {
      if (((Hr = !1), (fi = 0), 25 <= s)) throw Error(C(301));
      ((s += 1),
        (de = ae = null),
        (t.updateQueue = null),
        (us.current = mv),
        (e = n(r, i)));
    } while (Hr);
  }
  if (
    ((us.current = zs),
    (t = ae !== null && ae.next !== null),
    (An = 0),
    (de = ae = Q = null),
    (Fs = !1),
    t)
  )
    throw Error(C(300));
  return e;
}
function ku() {
  var e = fi !== 0;
  return ((fi = 0), e);
}
function yt() {
  var e = {
    memoizedState: null,
    baseState: null,
    baseQueue: null,
    queue: null,
    next: null,
  };
  return (de === null ? (Q.memoizedState = de = e) : (de = de.next = e), de);
}
function rt() {
  if (ae === null) {
    var e = Q.alternate;
    e = e !== null ? e.memoizedState : null;
  } else e = ae.next;
  var t = de === null ? Q.memoizedState : de.next;
  if (t !== null) ((de = t), (ae = e));
  else {
    if (e === null) throw Error(C(310));
    ((ae = e),
      (e = {
        memoizedState: ae.memoizedState,
        baseState: ae.baseState,
        baseQueue: ae.baseQueue,
        queue: ae.queue,
        next: null,
      }),
      de === null ? (Q.memoizedState = de = e) : (de = de.next = e));
  }
  return de;
}
function hi(e, t) {
  return typeof t == "function" ? t(e) : t;
}
function Zo(e) {
  var t = rt(),
    n = t.queue;
  if (n === null) throw Error(C(311));
  n.lastRenderedReducer = e;
  var r = ae,
    i = r.baseQueue,
    s = n.pending;
  if (s !== null) {
    if (i !== null) {
      var o = i.next;
      ((i.next = s.next), (s.next = o));
    }
    ((r.baseQueue = i = s), (n.pending = null));
  }
  if (i !== null) {
    ((s = i.next), (r = r.baseState));
    var l = (o = null),
      u = null,
      c = s;
    do {
      var d = c.lane;
      if ((An & d) === d)
        (u !== null &&
          (u = u.next =
            {
              lane: 0,
              action: c.action,
              hasEagerState: c.hasEagerState,
              eagerState: c.eagerState,
              next: null,
            }),
          (r = c.hasEagerState ? c.eagerState : e(r, c.action)));
      else {
        var f = {
          lane: d,
          action: c.action,
          hasEagerState: c.hasEagerState,
          eagerState: c.eagerState,
          next: null,
        };
        (u === null ? ((l = u = f), (o = r)) : (u = u.next = f),
          (Q.lanes |= d),
          (Ln |= d));
      }
      c = c.next;
    } while (c !== null && c !== s);
    (u === null ? (o = r) : (u.next = l),
      pt(r, t.memoizedState) || (Re = !0),
      (t.memoizedState = r),
      (t.baseState = o),
      (t.baseQueue = u),
      (n.lastRenderedState = r));
  }
  if (((e = n.interleaved), e !== null)) {
    i = e;
    do ((s = i.lane), (Q.lanes |= s), (Ln |= s), (i = i.next));
    while (i !== e);
  } else i === null && (n.lanes = 0);
  return [t.memoizedState, n.dispatch];
}
function qo(e) {
  var t = rt(),
    n = t.queue;
  if (n === null) throw Error(C(311));
  n.lastRenderedReducer = e;
  var r = n.dispatch,
    i = n.pending,
    s = t.memoizedState;
  if (i !== null) {
    n.pending = null;
    var o = (i = i.next);
    do ((s = e(s, o.action)), (o = o.next));
    while (o !== i);
    (pt(s, t.memoizedState) || (Re = !0),
      (t.memoizedState = s),
      t.baseQueue === null && (t.baseState = s),
      (n.lastRenderedState = s));
  }
  return [s, r];
}
function gp() {}
function yp(e, t) {
  var n = Q,
    r = rt(),
    i = t(),
    s = !pt(r.memoizedState, i);
  if (
    (s && ((r.memoizedState = i), (Re = !0)),
    (r = r.queue),
    ju(wp.bind(null, n, r, e), [e]),
    r.getSnapshot !== t || s || (de !== null && de.memoizedState.tag & 1))
  ) {
    if (
      ((n.flags |= 2048),
      pi(9, xp.bind(null, n, r, i, t), void 0, null),
      fe === null)
    )
      throw Error(C(349));
    An & 30 || vp(n, t, i);
  }
  return i;
}
function vp(e, t, n) {
  ((e.flags |= 16384),
    (e = { getSnapshot: t, value: n }),
    (t = Q.updateQueue),
    t === null
      ? ((t = { lastEffect: null, stores: null }),
        (Q.updateQueue = t),
        (t.stores = [e]))
      : ((n = t.stores), n === null ? (t.stores = [e]) : n.push(e)));
}
function xp(e, t, n, r) {
  ((t.value = n), (t.getSnapshot = r), kp(t) && jp(e));
}
function wp(e, t, n) {
  return n(function () {
    kp(t) && jp(e);
  });
}
function kp(e) {
  var t = e.getSnapshot;
  e = e.value;
  try {
    var n = t();
    return !pt(e, n);
  } catch {
    return !0;
  }
}
function jp(e) {
  var t = Rt(e, 1);
  t !== null && ft(t, e, 1, -1);
}
function Qc(e) {
  var t = yt();
  return (
    typeof e == "function" && (e = e()),
    (t.memoizedState = t.baseState = e),
    (e = {
      pending: null,
      interleaved: null,
      lanes: 0,
      dispatch: null,
      lastRenderedReducer: hi,
      lastRenderedState: e,
    }),
    (t.queue = e),
    (e = e.dispatch = fv.bind(null, Q, e)),
    [t.memoizedState, e]
  );
}
function pi(e, t, n, r) {
  return (
    (e = { tag: e, create: t, destroy: n, deps: r, next: null }),
    (t = Q.updateQueue),
    t === null
      ? ((t = { lastEffect: null, stores: null }),
        (Q.updateQueue = t),
        (t.lastEffect = e.next = e))
      : ((n = t.lastEffect),
        n === null
          ? (t.lastEffect = e.next = e)
          : ((r = n.next), (n.next = e), (e.next = r), (t.lastEffect = e))),
    e
  );
}
function Sp() {
  return rt().memoizedState;
}
function cs(e, t, n, r) {
  var i = yt();
  ((Q.flags |= e),
    (i.memoizedState = pi(1 | t, n, void 0, r === void 0 ? null : r)));
}
function po(e, t, n, r) {
  var i = rt();
  r = r === void 0 ? null : r;
  var s = void 0;
  if (ae !== null) {
    var o = ae.memoizedState;
    if (((s = o.destroy), r !== null && xu(r, o.deps))) {
      i.memoizedState = pi(t, n, s, r);
      return;
    }
  }
  ((Q.flags |= e), (i.memoizedState = pi(1 | t, n, s, r)));
}
function Zc(e, t) {
  return cs(8390656, 8, e, t);
}
function ju(e, t) {
  return po(2048, 8, e, t);
}
function bp(e, t) {
  return po(4, 2, e, t);
}
function Cp(e, t) {
  return po(4, 4, e, t);
}
function Tp(e, t) {
  if (typeof t == "function")
    return (
      (e = e()),
      t(e),
      function () {
        t(null);
      }
    );
  if (t != null)
    return (
      (e = e()),
      (t.current = e),
      function () {
        t.current = null;
      }
    );
}
function Pp(e, t, n) {
  return (
    (n = n != null ? n.concat([e]) : null),
    po(4, 4, Tp.bind(null, t, e), n)
  );
}
function Su() {}
function Np(e, t) {
  var n = rt();
  t = t === void 0 ? null : t;
  var r = n.memoizedState;
  return r !== null && t !== null && xu(t, r[1])
    ? r[0]
    : ((n.memoizedState = [e, t]), e);
}
function Ep(e, t) {
  var n = rt();
  t = t === void 0 ? null : t;
  var r = n.memoizedState;
  return r !== null && t !== null && xu(t, r[1])
    ? r[0]
    : ((e = e()), (n.memoizedState = [e, t]), e);
}
function Mp(e, t, n) {
  return An & 21
    ? (pt(n, t) || ((n = Ih()), (Q.lanes |= n), (Ln |= n), (e.baseState = !0)),
      t)
    : (e.baseState && ((e.baseState = !1), (Re = !0)), (e.memoizedState = n));
}
function cv(e, t) {
  var n = z;
  ((z = n !== 0 && 4 > n ? n : 4), e(!0));
  var r = Qo.transition;
  Qo.transition = {};
  try {
    (e(!1), t());
  } finally {
    ((z = n), (Qo.transition = r));
  }
}
function Ap() {
  return rt().memoizedState;
}
function dv(e, t, n) {
  var r = tn(e);
  if (
    ((n = {
      lane: r,
      action: n,
      hasEagerState: !1,
      eagerState: null,
      next: null,
    }),
    Lp(e))
  )
    Rp(t, n);
  else if (((n = hp(e, t, n, r)), n !== null)) {
    var i = Pe();
    (ft(n, e, r, i), Dp(n, t, r));
  }
}
function fv(e, t, n) {
  var r = tn(e),
    i = { lane: r, action: n, hasEagerState: !1, eagerState: null, next: null };
  if (Lp(e)) Rp(t, i);
  else {
    var s = e.alternate;
    if (
      e.lanes === 0 &&
      (s === null || s.lanes === 0) &&
      ((s = t.lastRenderedReducer), s !== null)
    )
      try {
        var o = t.lastRenderedState,
          l = s(o, n);
        if (((i.hasEagerState = !0), (i.eagerState = l), pt(l, o))) {
          var u = t.interleaved;
          (u === null
            ? ((i.next = i), pu(t))
            : ((i.next = u.next), (u.next = i)),
            (t.interleaved = i));
          return;
        }
      } catch {
      } finally {
      }
    ((n = hp(e, t, i, r)),
      n !== null && ((i = Pe()), ft(n, e, r, i), Dp(n, t, r)));
  }
}
function Lp(e) {
  var t = e.alternate;
  return e === Q || (t !== null && t === Q);
}
function Rp(e, t) {
  Hr = Fs = !0;
  var n = e.pending;
  (n === null ? (t.next = t) : ((t.next = n.next), (n.next = t)),
    (e.pending = t));
}
function Dp(e, t, n) {
  if (n & 4194240) {
    var r = t.lanes;
    ((r &= e.pendingLanes), (n |= r), (t.lanes = n), eu(e, n));
  }
}
var zs = {
    readContext: nt,
    useCallback: xe,
    useContext: xe,
    useEffect: xe,
    useImperativeHandle: xe,
    useInsertionEffect: xe,
    useLayoutEffect: xe,
    useMemo: xe,
    useReducer: xe,
    useRef: xe,
    useState: xe,
    useDebugValue: xe,
    useDeferredValue: xe,
    useTransition: xe,
    useMutableSource: xe,
    useSyncExternalStore: xe,
    useId: xe,
    unstable_isNewReconciler: !1,
  },
  hv = {
    readContext: nt,
    useCallback: function (e, t) {
      return ((yt().memoizedState = [e, t === void 0 ? null : t]), e);
    },
    useContext: nt,
    useEffect: Zc,
    useImperativeHandle: function (e, t, n) {
      return (
        (n = n != null ? n.concat([e]) : null),
        cs(4194308, 4, Tp.bind(null, t, e), n)
      );
    },
    useLayoutEffect: function (e, t) {
      return cs(4194308, 4, e, t);
    },
    useInsertionEffect: function (e, t) {
      return cs(4, 2, e, t);
    },
    useMemo: function (e, t) {
      var n = yt();
      return (
        (t = t === void 0 ? null : t),
        (e = e()),
        (n.memoizedState = [e, t]),
        e
      );
    },
    useReducer: function (e, t, n) {
      var r = yt();
      return (
        (t = n !== void 0 ? n(t) : t),
        (r.memoizedState = r.baseState = t),
        (e = {
          pending: null,
          interleaved: null,
          lanes: 0,
          dispatch: null,
          lastRenderedReducer: e,
          lastRenderedState: t,
        }),
        (r.queue = e),
        (e = e.dispatch = dv.bind(null, Q, e)),
        [r.memoizedState, e]
      );
    },
    useRef: function (e) {
      var t = yt();
      return ((e = { current: e }), (t.memoizedState = e));
    },
    useState: Qc,
    useDebugValue: Su,
    useDeferredValue: function (e) {
      return (yt().memoizedState = e);
    },
    useTransition: function () {
      var e = Qc(!1),
        t = e[0];
      return ((e = cv.bind(null, e[1])), (yt().memoizedState = e), [t, e]);
    },
    useMutableSource: function () {},
    useSyncExternalStore: function (e, t, n) {
      var r = Q,
        i = yt();
      if (Y) {
        if (n === void 0) throw Error(C(407));
        n = n();
      } else {
        if (((n = t()), fe === null)) throw Error(C(349));
        An & 30 || vp(r, t, n);
      }
      i.memoizedState = n;
      var s = { value: n, getSnapshot: t };
      return (
        (i.queue = s),
        Zc(wp.bind(null, r, s, e), [e]),
        (r.flags |= 2048),
        pi(9, xp.bind(null, r, s, n, t), void 0, null),
        n
      );
    },
    useId: function () {
      var e = yt(),
        t = fe.identifierPrefix;
      if (Y) {
        var n = Nt,
          r = Pt;
        ((n = (r & ~(1 << (32 - dt(r) - 1))).toString(32) + n),
          (t = ":" + t + "R" + n),
          (n = fi++),
          0 < n && (t += "H" + n.toString(32)),
          (t += ":"));
      } else ((n = uv++), (t = ":" + t + "r" + n.toString(32) + ":"));
      return (e.memoizedState = t);
    },
    unstable_isNewReconciler: !1,
  },
  pv = {
    readContext: nt,
    useCallback: Np,
    useContext: nt,
    useEffect: ju,
    useImperativeHandle: Pp,
    useInsertionEffect: bp,
    useLayoutEffect: Cp,
    useMemo: Ep,
    useReducer: Zo,
    useRef: Sp,
    useState: function () {
      return Zo(hi);
    },
    useDebugValue: Su,
    useDeferredValue: function (e) {
      var t = rt();
      return Mp(t, ae.memoizedState, e);
    },
    useTransition: function () {
      var e = Zo(hi)[0],
        t = rt().memoizedState;
      return [e, t];
    },
    useMutableSource: gp,
    useSyncExternalStore: yp,
    useId: Ap,
    unstable_isNewReconciler: !1,
  },
  mv = {
    readContext: nt,
    useCallback: Np,
    useContext: nt,
    useEffect: ju,
    useImperativeHandle: Pp,
    useInsertionEffect: bp,
    useLayoutEffect: Cp,
    useMemo: Ep,
    useReducer: qo,
    useRef: Sp,
    useState: function () {
      return qo(hi);
    },
    useDebugValue: Su,
    useDeferredValue: function (e) {
      var t = rt();
      return ae === null ? (t.memoizedState = e) : Mp(t, ae.memoizedState, e);
    },
    useTransition: function () {
      var e = qo(hi)[0],
        t = rt().memoizedState;
      return [e, t];
    },
    useMutableSource: gp,
    useSyncExternalStore: yp,
    useId: Ap,
    unstable_isNewReconciler: !1,
  };
function lt(e, t) {
  if (e && e.defaultProps) {
    ((t = Z({}, t)), (e = e.defaultProps));
    for (var n in e) t[n] === void 0 && (t[n] = e[n]);
    return t;
  }
  return t;
}
function Za(e, t, n, r) {
  ((t = e.memoizedState),
    (n = n(r, t)),
    (n = n == null ? t : Z({}, t, n)),
    (e.memoizedState = n),
    e.lanes === 0 && (e.updateQueue.baseState = n));
}
var mo = {
  isMounted: function (e) {
    return (e = e._reactInternals) ? In(e) === e : !1;
  },
  enqueueSetState: function (e, t, n) {
    e = e._reactInternals;
    var r = Pe(),
      i = tn(e),
      s = Mt(r, i);
    ((s.payload = t),
      n != null && (s.callback = n),
      (t = Jt(e, s, i)),
      t !== null && (ft(t, e, i, r), ls(t, e, i)));
  },
  enqueueReplaceState: function (e, t, n) {
    e = e._reactInternals;
    var r = Pe(),
      i = tn(e),
      s = Mt(r, i);
    ((s.tag = 1),
      (s.payload = t),
      n != null && (s.callback = n),
      (t = Jt(e, s, i)),
      t !== null && (ft(t, e, i, r), ls(t, e, i)));
  },
  enqueueForceUpdate: function (e, t) {
    e = e._reactInternals;
    var n = Pe(),
      r = tn(e),
      i = Mt(n, r);
    ((i.tag = 2),
      t != null && (i.callback = t),
      (t = Jt(e, i, r)),
      t !== null && (ft(t, e, r, n), ls(t, e, r)));
  },
};
function qc(e, t, n, r, i, s, o) {
  return (
    (e = e.stateNode),
    typeof e.shouldComponentUpdate == "function"
      ? e.shouldComponentUpdate(r, s, o)
      : t.prototype && t.prototype.isPureReactComponent
        ? !oi(n, r) || !oi(i, s)
        : !0
  );
}
function Ip(e, t, n) {
  var r = !1,
    i = on,
    s = t.contextType;
  return (
    typeof s == "object" && s !== null
      ? (s = nt(s))
      : ((i = Ie(t) ? En : je.current),
        (r = t.contextTypes),
        (s = (r = r != null) ? lr(e, i) : on)),
    (t = new t(n, s)),
    (e.memoizedState = t.state !== null && t.state !== void 0 ? t.state : null),
    (t.updater = mo),
    (e.stateNode = t),
    (t._reactInternals = e),
    r &&
      ((e = e.stateNode),
      (e.__reactInternalMemoizedUnmaskedChildContext = i),
      (e.__reactInternalMemoizedMaskedChildContext = s)),
    t
  );
}
function Jc(e, t, n, r) {
  ((e = t.state),
    typeof t.componentWillReceiveProps == "function" &&
      t.componentWillReceiveProps(n, r),
    typeof t.UNSAFE_componentWillReceiveProps == "function" &&
      t.UNSAFE_componentWillReceiveProps(n, r),
    t.state !== e && mo.enqueueReplaceState(t, t.state, null));
}
function qa(e, t, n, r) {
  var i = e.stateNode;
  ((i.props = n), (i.state = e.memoizedState), (i.refs = {}), mu(e));
  var s = t.contextType;
  (typeof s == "object" && s !== null
    ? (i.context = nt(s))
    : ((s = Ie(t) ? En : je.current), (i.context = lr(e, s))),
    (i.state = e.memoizedState),
    (s = t.getDerivedStateFromProps),
    typeof s == "function" && (Za(e, t, s, n), (i.state = e.memoizedState)),
    typeof t.getDerivedStateFromProps == "function" ||
      typeof i.getSnapshotBeforeUpdate == "function" ||
      (typeof i.UNSAFE_componentWillMount != "function" &&
        typeof i.componentWillMount != "function") ||
      ((t = i.state),
      typeof i.componentWillMount == "function" && i.componentWillMount(),
      typeof i.UNSAFE_componentWillMount == "function" &&
        i.UNSAFE_componentWillMount(),
      t !== i.state && mo.enqueueReplaceState(i, i.state, null),
      Bs(e, n, i, r),
      (i.state = e.memoizedState)),
    typeof i.componentDidMount == "function" && (e.flags |= 4194308));
}
function fr(e, t) {
  try {
    var n = "",
      r = t;
    do ((n += Uy(r)), (r = r.return));
    while (r);
    var i = n;
  } catch (s) {
    i =
      `
Error generating stack: ` +
      s.message +
      `
` +
      s.stack;
  }
  return { value: e, source: t, stack: i, digest: null };
}
function Jo(e, t, n) {
  return { value: e, source: null, stack: n ?? null, digest: t ?? null };
}
function Ja(e, t) {
  try {
    console.error(t.value);
  } catch (n) {
    setTimeout(function () {
      throw n;
    });
  }
}
var gv = typeof WeakMap == "function" ? WeakMap : Map;
function Vp(e, t, n) {
  ((n = Mt(-1, n)), (n.tag = 3), (n.payload = { element: null }));
  var r = t.value;
  return (
    (n.callback = function () {
      (Ws || ((Ws = !0), (ul = r)), Ja(e, t));
    }),
    n
  );
}
function Bp(e, t, n) {
  ((n = Mt(-1, n)), (n.tag = 3));
  var r = e.type.getDerivedStateFromError;
  if (typeof r == "function") {
    var i = t.value;
    ((n.payload = function () {
      return r(i);
    }),
      (n.callback = function () {
        Ja(e, t);
      }));
  }
  var s = e.stateNode;
  return (
    s !== null &&
      typeof s.componentDidCatch == "function" &&
      (n.callback = function () {
        (Ja(e, t),
          typeof r != "function" &&
            (en === null ? (en = new Set([this])) : en.add(this)));
        var o = t.stack;
        this.componentDidCatch(t.value, {
          componentStack: o !== null ? o : "",
        });
      }),
    n
  );
}
function ed(e, t, n) {
  var r = e.pingCache;
  if (r === null) {
    r = e.pingCache = new gv();
    var i = new Set();
    r.set(t, i);
  } else ((i = r.get(t)), i === void 0 && ((i = new Set()), r.set(t, i)));
  i.has(n) || (i.add(n), (e = Mv.bind(null, e, t, n)), t.then(e, e));
}
function td(e) {
  do {
    var t;
    if (
      ((t = e.tag === 13) &&
        ((t = e.memoizedState), (t = t !== null ? t.dehydrated !== null : !0)),
      t)
    )
      return e;
    e = e.return;
  } while (e !== null);
  return null;
}
function nd(e, t, n, r, i) {
  return e.mode & 1
    ? ((e.flags |= 65536), (e.lanes = i), e)
    : (e === t
        ? (e.flags |= 65536)
        : ((e.flags |= 128),
          (n.flags |= 131072),
          (n.flags &= -52805),
          n.tag === 1 &&
            (n.alternate === null
              ? (n.tag = 17)
              : ((t = Mt(-1, 1)), (t.tag = 2), Jt(n, t, 1))),
          (n.lanes |= 1)),
      e);
}
var yv = It.ReactCurrentOwner,
  Re = !1;
function be(e, t, n, r) {
  t.child = e === null ? fp(t, null, n, r) : cr(t, e.child, n, r);
}
function rd(e, t, n, r, i) {
  n = n.render;
  var s = t.ref;
  return (
    sr(t, i),
    (r = wu(e, t, n, r, s, i)),
    (n = ku()),
    e !== null && !Re
      ? ((t.updateQueue = e.updateQueue),
        (t.flags &= -2053),
        (e.lanes &= ~i),
        Dt(e, t, i))
      : (Y && n && lu(t), (t.flags |= 1), be(e, t, r, i), t.child)
  );
}
function id(e, t, n, r, i) {
  if (e === null) {
    var s = n.type;
    return typeof s == "function" &&
      !Au(s) &&
      s.defaultProps === void 0 &&
      n.compare === null &&
      n.defaultProps === void 0
      ? ((t.tag = 15), (t.type = s), Op(e, t, s, r, i))
      : ((e = ps(n.type, null, r, t, t.mode, i)),
        (e.ref = t.ref),
        (e.return = t),
        (t.child = e));
  }
  if (((s = e.child), !(e.lanes & i))) {
    var o = s.memoizedProps;
    if (
      ((n = n.compare), (n = n !== null ? n : oi), n(o, r) && e.ref === t.ref)
    )
      return Dt(e, t, i);
  }
  return (
    (t.flags |= 1),
    (e = nn(s, r)),
    (e.ref = t.ref),
    (e.return = t),
    (t.child = e)
  );
}
function Op(e, t, n, r, i) {
  if (e !== null) {
    var s = e.memoizedProps;
    if (oi(s, r) && e.ref === t.ref)
      if (((Re = !1), (t.pendingProps = r = s), (e.lanes & i) !== 0))
        e.flags & 131072 && (Re = !0);
      else return ((t.lanes = e.lanes), Dt(e, t, i));
  }
  return el(e, t, n, r, i);
}
function Fp(e, t, n) {
  var r = t.pendingProps,
    i = r.children,
    s = e !== null ? e.memoizedState : null;
  if (r.mode === "hidden")
    if (!(t.mode & 1))
      ((t.memoizedState = { baseLanes: 0, cachePool: null, transitions: null }),
        H(Zn, ze),
        (ze |= n));
    else {
      if (!(n & 1073741824))
        return (
          (e = s !== null ? s.baseLanes | n : n),
          (t.lanes = t.childLanes = 1073741824),
          (t.memoizedState = {
            baseLanes: e,
            cachePool: null,
            transitions: null,
          }),
          (t.updateQueue = null),
          H(Zn, ze),
          (ze |= e),
          null
        );
      ((t.memoizedState = { baseLanes: 0, cachePool: null, transitions: null }),
        (r = s !== null ? s.baseLanes : n),
        H(Zn, ze),
        (ze |= r));
    }
  else
    (s !== null ? ((r = s.baseLanes | n), (t.memoizedState = null)) : (r = n),
      H(Zn, ze),
      (ze |= r));
  return (be(e, t, i, n), t.child);
}
function zp(e, t) {
  var n = t.ref;
  ((e === null && n !== null) || (e !== null && e.ref !== n)) &&
    ((t.flags |= 512), (t.flags |= 2097152));
}
function el(e, t, n, r, i) {
  var s = Ie(n) ? En : je.current;
  return (
    (s = lr(t, s)),
    sr(t, i),
    (n = wu(e, t, n, r, s, i)),
    (r = ku()),
    e !== null && !Re
      ? ((t.updateQueue = e.updateQueue),
        (t.flags &= -2053),
        (e.lanes &= ~i),
        Dt(e, t, i))
      : (Y && r && lu(t), (t.flags |= 1), be(e, t, n, i), t.child)
  );
}
function sd(e, t, n, r, i) {
  if (Ie(n)) {
    var s = !0;
    Ls(t);
  } else s = !1;
  if ((sr(t, i), t.stateNode === null))
    (ds(e, t), Ip(t, n, r), qa(t, n, r, i), (r = !0));
  else if (e === null) {
    var o = t.stateNode,
      l = t.memoizedProps;
    o.props = l;
    var u = o.context,
      c = n.contextType;
    typeof c == "object" && c !== null
      ? (c = nt(c))
      : ((c = Ie(n) ? En : je.current), (c = lr(t, c)));
    var d = n.getDerivedStateFromProps,
      f =
        typeof d == "function" ||
        typeof o.getSnapshotBeforeUpdate == "function";
    (f ||
      (typeof o.UNSAFE_componentWillReceiveProps != "function" &&
        typeof o.componentWillReceiveProps != "function") ||
      ((l !== r || u !== c) && Jc(t, o, r, c)),
      (Wt = !1));
    var h = t.memoizedState;
    ((o.state = h),
      Bs(t, r, o, i),
      (u = t.memoizedState),
      l !== r || h !== u || De.current || Wt
        ? (typeof d == "function" && (Za(t, n, d, r), (u = t.memoizedState)),
          (l = Wt || qc(t, n, l, r, h, u, c))
            ? (f ||
                (typeof o.UNSAFE_componentWillMount != "function" &&
                  typeof o.componentWillMount != "function") ||
                (typeof o.componentWillMount == "function" &&
                  o.componentWillMount(),
                typeof o.UNSAFE_componentWillMount == "function" &&
                  o.UNSAFE_componentWillMount()),
              typeof o.componentDidMount == "function" && (t.flags |= 4194308))
            : (typeof o.componentDidMount == "function" && (t.flags |= 4194308),
              (t.memoizedProps = r),
              (t.memoizedState = u)),
          (o.props = r),
          (o.state = u),
          (o.context = c),
          (r = l))
        : (typeof o.componentDidMount == "function" && (t.flags |= 4194308),
          (r = !1)));
  } else {
    ((o = t.stateNode),
      pp(e, t),
      (l = t.memoizedProps),
      (c = t.type === t.elementType ? l : lt(t.type, l)),
      (o.props = c),
      (f = t.pendingProps),
      (h = o.context),
      (u = n.contextType),
      typeof u == "object" && u !== null
        ? (u = nt(u))
        : ((u = Ie(n) ? En : je.current), (u = lr(t, u))));
    var m = n.getDerivedStateFromProps;
    ((d =
      typeof m == "function" ||
      typeof o.getSnapshotBeforeUpdate == "function") ||
      (typeof o.UNSAFE_componentWillReceiveProps != "function" &&
        typeof o.componentWillReceiveProps != "function") ||
      ((l !== f || h !== u) && Jc(t, o, r, u)),
      (Wt = !1),
      (h = t.memoizedState),
      (o.state = h),
      Bs(t, r, o, i));
    var v = t.memoizedState;
    l !== f || h !== v || De.current || Wt
      ? (typeof m == "function" && (Za(t, n, m, r), (v = t.memoizedState)),
        (c = Wt || qc(t, n, c, r, h, v, u) || !1)
          ? (d ||
              (typeof o.UNSAFE_componentWillUpdate != "function" &&
                typeof o.componentWillUpdate != "function") ||
              (typeof o.componentWillUpdate == "function" &&
                o.componentWillUpdate(r, v, u),
              typeof o.UNSAFE_componentWillUpdate == "function" &&
                o.UNSAFE_componentWillUpdate(r, v, u)),
            typeof o.componentDidUpdate == "function" && (t.flags |= 4),
            typeof o.getSnapshotBeforeUpdate == "function" && (t.flags |= 1024))
          : (typeof o.componentDidUpdate != "function" ||
              (l === e.memoizedProps && h === e.memoizedState) ||
              (t.flags |= 4),
            typeof o.getSnapshotBeforeUpdate != "function" ||
              (l === e.memoizedProps && h === e.memoizedState) ||
              (t.flags |= 1024),
            (t.memoizedProps = r),
            (t.memoizedState = v)),
        (o.props = r),
        (o.state = v),
        (o.context = u),
        (r = c))
      : (typeof o.componentDidUpdate != "function" ||
          (l === e.memoizedProps && h === e.memoizedState) ||
          (t.flags |= 4),
        typeof o.getSnapshotBeforeUpdate != "function" ||
          (l === e.memoizedProps && h === e.memoizedState) ||
          (t.flags |= 1024),
        (r = !1));
  }
  return tl(e, t, n, r, s, i);
}
function tl(e, t, n, r, i, s) {
  zp(e, t);
  var o = (t.flags & 128) !== 0;
  if (!r && !o) return (i && Hc(t, n, !1), Dt(e, t, s));
  ((r = t.stateNode), (yv.current = t));
  var l =
    o && typeof n.getDerivedStateFromError != "function" ? null : r.render();
  return (
    (t.flags |= 1),
    e !== null && o
      ? ((t.child = cr(t, e.child, null, s)), (t.child = cr(t, null, l, s)))
      : be(e, t, l, s),
    (t.memoizedState = r.state),
    i && Hc(t, n, !0),
    t.child
  );
}
function _p(e) {
  var t = e.stateNode;
  (t.pendingContext
    ? Uc(e, t.pendingContext, t.pendingContext !== t.context)
    : t.context && Uc(e, t.context, !1),
    gu(e, t.containerInfo));
}
function od(e, t, n, r, i) {
  return (ur(), cu(i), (t.flags |= 256), be(e, t, n, r), t.child);
}
var nl = { dehydrated: null, treeContext: null, retryLane: 0 };
function rl(e) {
  return { baseLanes: e, cachePool: null, transitions: null };
}
function Wp(e, t, n) {
  var r = t.pendingProps,
    i = X.current,
    s = !1,
    o = (t.flags & 128) !== 0,
    l;
  if (
    ((l = o) ||
      (l = e !== null && e.memoizedState === null ? !1 : (i & 2) !== 0),
    l
      ? ((s = !0), (t.flags &= -129))
      : (e === null || e.memoizedState !== null) && (i |= 1),
    H(X, i & 1),
    e === null)
  )
    return (
      Xa(t),
      (e = t.memoizedState),
      e !== null && ((e = e.dehydrated), e !== null)
        ? (t.mode & 1
            ? e.data === "$!"
              ? (t.lanes = 8)
              : (t.lanes = 1073741824)
            : (t.lanes = 1),
          null)
        : ((o = r.children),
          (e = r.fallback),
          s
            ? ((r = t.mode),
              (s = t.child),
              (o = { mode: "hidden", children: o }),
              !(r & 1) && s !== null
                ? ((s.childLanes = 0), (s.pendingProps = o))
                : (s = vo(o, r, 0, null)),
              (e = Tn(e, r, n, null)),
              (s.return = t),
              (e.return = t),
              (s.sibling = e),
              (t.child = s),
              (t.child.memoizedState = rl(n)),
              (t.memoizedState = nl),
              e)
            : bu(t, o))
    );
  if (((i = e.memoizedState), i !== null && ((l = i.dehydrated), l !== null)))
    return vv(e, t, o, r, l, i, n);
  if (s) {
    ((s = r.fallback), (o = t.mode), (i = e.child), (l = i.sibling));
    var u = { mode: "hidden", children: r.children };
    return (
      !(o & 1) && t.child !== i
        ? ((r = t.child),
          (r.childLanes = 0),
          (r.pendingProps = u),
          (t.deletions = null))
        : ((r = nn(i, u)), (r.subtreeFlags = i.subtreeFlags & 14680064)),
      l !== null ? (s = nn(l, s)) : ((s = Tn(s, o, n, null)), (s.flags |= 2)),
      (s.return = t),
      (r.return = t),
      (r.sibling = s),
      (t.child = r),
      (r = s),
      (s = t.child),
      (o = e.child.memoizedState),
      (o =
        o === null
          ? rl(n)
          : {
              baseLanes: o.baseLanes | n,
              cachePool: null,
              transitions: o.transitions,
            }),
      (s.memoizedState = o),
      (s.childLanes = e.childLanes & ~n),
      (t.memoizedState = nl),
      r
    );
  }
  return (
    (s = e.child),
    (e = s.sibling),
    (r = nn(s, { mode: "visible", children: r.children })),
    !(t.mode & 1) && (r.lanes = n),
    (r.return = t),
    (r.sibling = null),
    e !== null &&
      ((n = t.deletions),
      n === null ? ((t.deletions = [e]), (t.flags |= 16)) : n.push(e)),
    (t.child = r),
    (t.memoizedState = null),
    r
  );
}
function bu(e, t) {
  return (
    (t = vo({ mode: "visible", children: t }, e.mode, 0, null)),
    (t.return = e),
    (e.child = t)
  );
}
function Yi(e, t, n, r) {
  return (
    r !== null && cu(r),
    cr(t, e.child, null, n),
    (e = bu(t, t.pendingProps.children)),
    (e.flags |= 2),
    (t.memoizedState = null),
    e
  );
}
function vv(e, t, n, r, i, s, o) {
  if (n)
    return t.flags & 256
      ? ((t.flags &= -257), (r = Jo(Error(C(422)))), Yi(e, t, o, r))
      : t.memoizedState !== null
        ? ((t.child = e.child), (t.flags |= 128), null)
        : ((s = r.fallback),
          (i = t.mode),
          (r = vo({ mode: "visible", children: r.children }, i, 0, null)),
          (s = Tn(s, i, o, null)),
          (s.flags |= 2),
          (r.return = t),
          (s.return = t),
          (r.sibling = s),
          (t.child = r),
          t.mode & 1 && cr(t, e.child, null, o),
          (t.child.memoizedState = rl(o)),
          (t.memoizedState = nl),
          s);
  if (!(t.mode & 1)) return Yi(e, t, o, null);
  if (i.data === "$!") {
    if (((r = i.nextSibling && i.nextSibling.dataset), r)) var l = r.dgst;
    return (
      (r = l),
      (s = Error(C(419))),
      (r = Jo(s, r, void 0)),
      Yi(e, t, o, r)
    );
  }
  if (((l = (o & e.childLanes) !== 0), Re || l)) {
    if (((r = fe), r !== null)) {
      switch (o & -o) {
        case 4:
          i = 2;
          break;
        case 16:
          i = 8;
          break;
        case 64:
        case 128:
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
        case 67108864:
          i = 32;
          break;
        case 536870912:
          i = 268435456;
          break;
        default:
          i = 0;
      }
      ((i = i & (r.suspendedLanes | o) ? 0 : i),
        i !== 0 &&
          i !== s.retryLane &&
          ((s.retryLane = i), Rt(e, i), ft(r, e, i, -1)));
    }
    return (Mu(), (r = Jo(Error(C(421)))), Yi(e, t, o, r));
  }
  return i.data === "$?"
    ? ((t.flags |= 128),
      (t.child = e.child),
      (t = Av.bind(null, e)),
      (i._reactRetry = t),
      null)
    : ((e = s.treeContext),
      (_e = qt(i.nextSibling)),
      (We = t),
      (Y = !0),
      (ct = null),
      e !== null &&
        ((Xe[Qe++] = Pt),
        (Xe[Qe++] = Nt),
        (Xe[Qe++] = Mn),
        (Pt = e.id),
        (Nt = e.overflow),
        (Mn = t)),
      (t = bu(t, r.children)),
      (t.flags |= 4096),
      t);
}
function ad(e, t, n) {
  e.lanes |= t;
  var r = e.alternate;
  (r !== null && (r.lanes |= t), Qa(e.return, t, n));
}
function ea(e, t, n, r, i) {
  var s = e.memoizedState;
  s === null
    ? (e.memoizedState = {
        isBackwards: t,
        rendering: null,
        renderingStartTime: 0,
        last: r,
        tail: n,
        tailMode: i,
      })
    : ((s.isBackwards = t),
      (s.rendering = null),
      (s.renderingStartTime = 0),
      (s.last = r),
      (s.tail = n),
      (s.tailMode = i));
}
function Up(e, t, n) {
  var r = t.pendingProps,
    i = r.revealOrder,
    s = r.tail;
  if ((be(e, t, r.children, n), (r = X.current), r & 2))
    ((r = (r & 1) | 2), (t.flags |= 128));
  else {
    if (e !== null && e.flags & 128)
      e: for (e = t.child; e !== null;) {
        if (e.tag === 13) e.memoizedState !== null && ad(e, n, t);
        else if (e.tag === 19) ad(e, n, t);
        else if (e.child !== null) {
          ((e.child.return = e), (e = e.child));
          continue;
        }
        if (e === t) break e;
        for (; e.sibling === null;) {
          if (e.return === null || e.return === t) break e;
          e = e.return;
        }
        ((e.sibling.return = e.return), (e = e.sibling));
      }
    r &= 1;
  }
  if ((H(X, r), !(t.mode & 1))) t.memoizedState = null;
  else
    switch (i) {
      case "forwards":
        for (n = t.child, i = null; n !== null;)
          ((e = n.alternate),
            e !== null && Os(e) === null && (i = n),
            (n = n.sibling));
        ((n = i),
          n === null
            ? ((i = t.child), (t.child = null))
            : ((i = n.sibling), (n.sibling = null)),
          ea(t, !1, i, n, s));
        break;
      case "backwards":
        for (n = null, i = t.child, t.child = null; i !== null;) {
          if (((e = i.alternate), e !== null && Os(e) === null)) {
            t.child = i;
            break;
          }
          ((e = i.sibling), (i.sibling = n), (n = i), (i = e));
        }
        ea(t, !0, n, null, s);
        break;
      case "together":
        ea(t, !1, null, null, void 0);
        break;
      default:
        t.memoizedState = null;
    }
  return t.child;
}
function ds(e, t) {
  !(t.mode & 1) &&
    e !== null &&
    ((e.alternate = null), (t.alternate = null), (t.flags |= 2));
}
function Dt(e, t, n) {
  if (
    (e !== null && (t.dependencies = e.dependencies),
    (Ln |= t.lanes),
    !(n & t.childLanes))
  )
    return null;
  if (e !== null && t.child !== e.child) throw Error(C(153));
  if (t.child !== null) {
    for (
      e = t.child, n = nn(e, e.pendingProps), t.child = n, n.return = t;
      e.sibling !== null;
    )
      ((e = e.sibling),
        (n = n.sibling = nn(e, e.pendingProps)),
        (n.return = t));
    n.sibling = null;
  }
  return t.child;
}
function xv(e, t, n) {
  switch (t.tag) {
    case 3:
      (_p(t), ur());
      break;
    case 5:
      mp(t);
      break;
    case 1:
      Ie(t.type) && Ls(t);
      break;
    case 4:
      gu(t, t.stateNode.containerInfo);
      break;
    case 10:
      var r = t.type._context,
        i = t.memoizedProps.value;
      (H(Is, r._currentValue), (r._currentValue = i));
      break;
    case 13:
      if (((r = t.memoizedState), r !== null))
        return r.dehydrated !== null
          ? (H(X, X.current & 1), (t.flags |= 128), null)
          : n & t.child.childLanes
            ? Wp(e, t, n)
            : (H(X, X.current & 1),
              (e = Dt(e, t, n)),
              e !== null ? e.sibling : null);
      H(X, X.current & 1);
      break;
    case 19:
      if (((r = (n & t.childLanes) !== 0), e.flags & 128)) {
        if (r) return Up(e, t, n);
        t.flags |= 128;
      }
      if (
        ((i = t.memoizedState),
        i !== null &&
          ((i.rendering = null), (i.tail = null), (i.lastEffect = null)),
        H(X, X.current),
        r)
      )
        break;
      return null;
    case 22:
    case 23:
      return ((t.lanes = 0), Fp(e, t, n));
  }
  return Dt(e, t, n);
}
var Hp, il, $p, Kp;
Hp = function (e, t) {
  for (var n = t.child; n !== null;) {
    if (n.tag === 5 || n.tag === 6) e.appendChild(n.stateNode);
    else if (n.tag !== 4 && n.child !== null) {
      ((n.child.return = n), (n = n.child));
      continue;
    }
    if (n === t) break;
    for (; n.sibling === null;) {
      if (n.return === null || n.return === t) return;
      n = n.return;
    }
    ((n.sibling.return = n.return), (n = n.sibling));
  }
};
il = function () {};
$p = function (e, t, n, r) {
  var i = e.memoizedProps;
  if (i !== r) {
    ((e = t.stateNode), jn(jt.current));
    var s = null;
    switch (n) {
      case "input":
        ((i = Ta(e, i)), (r = Ta(e, r)), (s = []));
        break;
      case "select":
        ((i = Z({}, i, { value: void 0 })),
          (r = Z({}, r, { value: void 0 })),
          (s = []));
        break;
      case "textarea":
        ((i = Ea(e, i)), (r = Ea(e, r)), (s = []));
        break;
      default:
        typeof i.onClick != "function" &&
          typeof r.onClick == "function" &&
          (e.onclick = Ms);
    }
    Aa(n, r);
    var o;
    n = null;
    for (c in i)
      if (!r.hasOwnProperty(c) && i.hasOwnProperty(c) && i[c] != null)
        if (c === "style") {
          var l = i[c];
          for (o in l) l.hasOwnProperty(o) && (n || (n = {}), (n[o] = ""));
        } else
          c !== "dangerouslySetInnerHTML" &&
            c !== "children" &&
            c !== "suppressContentEditableWarning" &&
            c !== "suppressHydrationWarning" &&
            c !== "autoFocus" &&
            (Jr.hasOwnProperty(c)
              ? s || (s = [])
              : (s = s || []).push(c, null));
    for (c in r) {
      var u = r[c];
      if (
        ((l = i != null ? i[c] : void 0),
        r.hasOwnProperty(c) && u !== l && (u != null || l != null))
      )
        if (c === "style")
          if (l) {
            for (o in l)
              !l.hasOwnProperty(o) ||
                (u && u.hasOwnProperty(o)) ||
                (n || (n = {}), (n[o] = ""));
            for (o in u)
              u.hasOwnProperty(o) &&
                l[o] !== u[o] &&
                (n || (n = {}), (n[o] = u[o]));
          } else (n || (s || (s = []), s.push(c, n)), (n = u));
        else
          c === "dangerouslySetInnerHTML"
            ? ((u = u ? u.__html : void 0),
              (l = l ? l.__html : void 0),
              u != null && l !== u && (s = s || []).push(c, u))
            : c === "children"
              ? (typeof u != "string" && typeof u != "number") ||
                (s = s || []).push(c, "" + u)
              : c !== "suppressContentEditableWarning" &&
                c !== "suppressHydrationWarning" &&
                (Jr.hasOwnProperty(c)
                  ? (u != null && c === "onScroll" && $("scroll", e),
                    s || l === u || (s = []))
                  : (s = s || []).push(c, u));
    }
    n && (s = s || []).push("style", n);
    var c = s;
    (t.updateQueue = c) && (t.flags |= 4);
  }
};
Kp = function (e, t, n, r) {
  n !== r && (t.flags |= 4);
};
function Mr(e, t) {
  if (!Y)
    switch (e.tailMode) {
      case "hidden":
        t = e.tail;
        for (var n = null; t !== null;)
          (t.alternate !== null && (n = t), (t = t.sibling));
        n === null ? (e.tail = null) : (n.sibling = null);
        break;
      case "collapsed":
        n = e.tail;
        for (var r = null; n !== null;)
          (n.alternate !== null && (r = n), (n = n.sibling));
        r === null
          ? t || e.tail === null
            ? (e.tail = null)
            : (e.tail.sibling = null)
          : (r.sibling = null);
    }
}
function we(e) {
  var t = e.alternate !== null && e.alternate.child === e.child,
    n = 0,
    r = 0;
  if (t)
    for (var i = e.child; i !== null;)
      ((n |= i.lanes | i.childLanes),
        (r |= i.subtreeFlags & 14680064),
        (r |= i.flags & 14680064),
        (i.return = e),
        (i = i.sibling));
  else
    for (i = e.child; i !== null;)
      ((n |= i.lanes | i.childLanes),
        (r |= i.subtreeFlags),
        (r |= i.flags),
        (i.return = e),
        (i = i.sibling));
  return ((e.subtreeFlags |= r), (e.childLanes = n), t);
}
function wv(e, t, n) {
  var r = t.pendingProps;
  switch ((uu(t), t.tag)) {
    case 2:
    case 16:
    case 15:
    case 0:
    case 11:
    case 7:
    case 8:
    case 12:
    case 9:
    case 14:
      return (we(t), null);
    case 1:
      return (Ie(t.type) && As(), we(t), null);
    case 3:
      return (
        (r = t.stateNode),
        dr(),
        G(De),
        G(je),
        vu(),
        r.pendingContext &&
          ((r.context = r.pendingContext), (r.pendingContext = null)),
        (e === null || e.child === null) &&
          (Ki(t)
            ? (t.flags |= 4)
            : e === null ||
              (e.memoizedState.isDehydrated && !(t.flags & 256)) ||
              ((t.flags |= 1024), ct !== null && (fl(ct), (ct = null)))),
        il(e, t),
        we(t),
        null
      );
    case 5:
      yu(t);
      var i = jn(di.current);
      if (((n = t.type), e !== null && t.stateNode != null))
        ($p(e, t, n, r, i),
          e.ref !== t.ref && ((t.flags |= 512), (t.flags |= 2097152)));
      else {
        if (!r) {
          if (t.stateNode === null) throw Error(C(166));
          return (we(t), null);
        }
        if (((e = jn(jt.current)), Ki(t))) {
          ((r = t.stateNode), (n = t.type));
          var s = t.memoizedProps;
          switch (((r[wt] = t), (r[ui] = s), (e = (t.mode & 1) !== 0), n)) {
            case "dialog":
              ($("cancel", r), $("close", r));
              break;
            case "iframe":
            case "object":
            case "embed":
              $("load", r);
              break;
            case "video":
            case "audio":
              for (i = 0; i < Br.length; i++) $(Br[i], r);
              break;
            case "source":
              $("error", r);
              break;
            case "img":
            case "image":
            case "link":
              ($("error", r), $("load", r));
              break;
            case "details":
              $("toggle", r);
              break;
            case "input":
              (gc(r, s), $("invalid", r));
              break;
            case "select":
              ((r._wrapperState = { wasMultiple: !!s.multiple }),
                $("invalid", r));
              break;
            case "textarea":
              (vc(r, s), $("invalid", r));
          }
          (Aa(n, s), (i = null));
          for (var o in s)
            if (s.hasOwnProperty(o)) {
              var l = s[o];
              o === "children"
                ? typeof l == "string"
                  ? r.textContent !== l &&
                    (s.suppressHydrationWarning !== !0 &&
                      $i(r.textContent, l, e),
                    (i = ["children", l]))
                  : typeof l == "number" &&
                    r.textContent !== "" + l &&
                    (s.suppressHydrationWarning !== !0 &&
                      $i(r.textContent, l, e),
                    (i = ["children", "" + l]))
                : Jr.hasOwnProperty(o) &&
                  l != null &&
                  o === "onScroll" &&
                  $("scroll", r);
            }
          switch (n) {
            case "input":
              (Bi(r), yc(r, s, !0));
              break;
            case "textarea":
              (Bi(r), xc(r));
              break;
            case "select":
            case "option":
              break;
            default:
              typeof s.onClick == "function" && (r.onclick = Ms);
          }
          ((r = i), (t.updateQueue = r), r !== null && (t.flags |= 4));
        } else {
          ((o = i.nodeType === 9 ? i : i.ownerDocument),
            e === "http://www.w3.org/1999/xhtml" && (e = wh(n)),
            e === "http://www.w3.org/1999/xhtml"
              ? n === "script"
                ? ((e = o.createElement("div")),
                  (e.innerHTML = "<script><\/script>"),
                  (e = e.removeChild(e.firstChild)))
                : typeof r.is == "string"
                  ? (e = o.createElement(n, { is: r.is }))
                  : ((e = o.createElement(n)),
                    n === "select" &&
                      ((o = e),
                      r.multiple
                        ? (o.multiple = !0)
                        : r.size && (o.size = r.size)))
              : (e = o.createElementNS(e, n)),
            (e[wt] = t),
            (e[ui] = r),
            Hp(e, t, !1, !1),
            (t.stateNode = e));
          e: {
            switch (((o = La(n, r)), n)) {
              case "dialog":
                ($("cancel", e), $("close", e), (i = r));
                break;
              case "iframe":
              case "object":
              case "embed":
                ($("load", e), (i = r));
                break;
              case "video":
              case "audio":
                for (i = 0; i < Br.length; i++) $(Br[i], e);
                i = r;
                break;
              case "source":
                ($("error", e), (i = r));
                break;
              case "img":
              case "image":
              case "link":
                ($("error", e), $("load", e), (i = r));
                break;
              case "details":
                ($("toggle", e), (i = r));
                break;
              case "input":
                (gc(e, r), (i = Ta(e, r)), $("invalid", e));
                break;
              case "option":
                i = r;
                break;
              case "select":
                ((e._wrapperState = { wasMultiple: !!r.multiple }),
                  (i = Z({}, r, { value: void 0 })),
                  $("invalid", e));
                break;
              case "textarea":
                (vc(e, r), (i = Ea(e, r)), $("invalid", e));
                break;
              default:
                i = r;
            }
            (Aa(n, i), (l = i));
            for (s in l)
              if (l.hasOwnProperty(s)) {
                var u = l[s];
                s === "style"
                  ? Sh(e, u)
                  : s === "dangerouslySetInnerHTML"
                    ? ((u = u ? u.__html : void 0), u != null && kh(e, u))
                    : s === "children"
                      ? typeof u == "string"
                        ? (n !== "textarea" || u !== "") && ei(e, u)
                        : typeof u == "number" && ei(e, "" + u)
                      : s !== "suppressContentEditableWarning" &&
                        s !== "suppressHydrationWarning" &&
                        s !== "autoFocus" &&
                        (Jr.hasOwnProperty(s)
                          ? u != null && s === "onScroll" && $("scroll", e)
                          : u != null && Yl(e, s, u, o));
              }
            switch (n) {
              case "input":
                (Bi(e), yc(e, r, !1));
                break;
              case "textarea":
                (Bi(e), xc(e));
                break;
              case "option":
                r.value != null && e.setAttribute("value", "" + sn(r.value));
                break;
              case "select":
                ((e.multiple = !!r.multiple),
                  (s = r.value),
                  s != null
                    ? tr(e, !!r.multiple, s, !1)
                    : r.defaultValue != null &&
                      tr(e, !!r.multiple, r.defaultValue, !0));
                break;
              default:
                typeof i.onClick == "function" && (e.onclick = Ms);
            }
            switch (n) {
              case "button":
              case "input":
              case "select":
              case "textarea":
                r = !!r.autoFocus;
                break e;
              case "img":
                r = !0;
                break e;
              default:
                r = !1;
            }
          }
          r && (t.flags |= 4);
        }
        t.ref !== null && ((t.flags |= 512), (t.flags |= 2097152));
      }
      return (we(t), null);
    case 6:
      if (e && t.stateNode != null) Kp(e, t, e.memoizedProps, r);
      else {
        if (typeof r != "string" && t.stateNode === null) throw Error(C(166));
        if (((n = jn(di.current)), jn(jt.current), Ki(t))) {
          if (
            ((r = t.stateNode),
            (n = t.memoizedProps),
            (r[wt] = t),
            (s = r.nodeValue !== n) && ((e = We), e !== null))
          )
            switch (e.tag) {
              case 3:
                $i(r.nodeValue, n, (e.mode & 1) !== 0);
                break;
              case 5:
                e.memoizedProps.suppressHydrationWarning !== !0 &&
                  $i(r.nodeValue, n, (e.mode & 1) !== 0);
            }
          s && (t.flags |= 4);
        } else
          ((r = (n.nodeType === 9 ? n : n.ownerDocument).createTextNode(r)),
            (r[wt] = t),
            (t.stateNode = r));
      }
      return (we(t), null);
    case 13:
      if (
        (G(X),
        (r = t.memoizedState),
        e === null ||
          (e.memoizedState !== null && e.memoizedState.dehydrated !== null))
      ) {
        if (Y && _e !== null && t.mode & 1 && !(t.flags & 128))
          (cp(), ur(), (t.flags |= 98560), (s = !1));
        else if (((s = Ki(t)), r !== null && r.dehydrated !== null)) {
          if (e === null) {
            if (!s) throw Error(C(318));
            if (
              ((s = t.memoizedState),
              (s = s !== null ? s.dehydrated : null),
              !s)
            )
              throw Error(C(317));
            s[wt] = t;
          } else
            (ur(),
              !(t.flags & 128) && (t.memoizedState = null),
              (t.flags |= 4));
          (we(t), (s = !1));
        } else (ct !== null && (fl(ct), (ct = null)), (s = !0));
        if (!s) return t.flags & 65536 ? t : null;
      }
      return t.flags & 128
        ? ((t.lanes = n), t)
        : ((r = r !== null),
          r !== (e !== null && e.memoizedState !== null) &&
            r &&
            ((t.child.flags |= 8192),
            t.mode & 1 &&
              (e === null || X.current & 1 ? le === 0 && (le = 3) : Mu())),
          t.updateQueue !== null && (t.flags |= 4),
          we(t),
          null);
    case 4:
      return (
        dr(),
        il(e, t),
        e === null && ai(t.stateNode.containerInfo),
        we(t),
        null
      );
    case 10:
      return (hu(t.type._context), we(t), null);
    case 17:
      return (Ie(t.type) && As(), we(t), null);
    case 19:
      if ((G(X), (s = t.memoizedState), s === null)) return (we(t), null);
      if (((r = (t.flags & 128) !== 0), (o = s.rendering), o === null))
        if (r) Mr(s, !1);
        else {
          if (le !== 0 || (e !== null && e.flags & 128))
            for (e = t.child; e !== null;) {
              if (((o = Os(e)), o !== null)) {
                for (
                  t.flags |= 128,
                    Mr(s, !1),
                    r = o.updateQueue,
                    r !== null && ((t.updateQueue = r), (t.flags |= 4)),
                    t.subtreeFlags = 0,
                    r = n,
                    n = t.child;
                  n !== null;
                )
                  ((s = n),
                    (e = r),
                    (s.flags &= 14680066),
                    (o = s.alternate),
                    o === null
                      ? ((s.childLanes = 0),
                        (s.lanes = e),
                        (s.child = null),
                        (s.subtreeFlags = 0),
                        (s.memoizedProps = null),
                        (s.memoizedState = null),
                        (s.updateQueue = null),
                        (s.dependencies = null),
                        (s.stateNode = null))
                      : ((s.childLanes = o.childLanes),
                        (s.lanes = o.lanes),
                        (s.child = o.child),
                        (s.subtreeFlags = 0),
                        (s.deletions = null),
                        (s.memoizedProps = o.memoizedProps),
                        (s.memoizedState = o.memoizedState),
                        (s.updateQueue = o.updateQueue),
                        (s.type = o.type),
                        (e = o.dependencies),
                        (s.dependencies =
                          e === null
                            ? null
                            : {
                                lanes: e.lanes,
                                firstContext: e.firstContext,
                              })),
                    (n = n.sibling));
                return (H(X, (X.current & 1) | 2), t.child);
              }
              e = e.sibling;
            }
          s.tail !== null &&
            te() > hr &&
            ((t.flags |= 128), (r = !0), Mr(s, !1), (t.lanes = 4194304));
        }
      else {
        if (!r)
          if (((e = Os(o)), e !== null)) {
            if (
              ((t.flags |= 128),
              (r = !0),
              (n = e.updateQueue),
              n !== null && ((t.updateQueue = n), (t.flags |= 4)),
              Mr(s, !0),
              s.tail === null && s.tailMode === "hidden" && !o.alternate && !Y)
            )
              return (we(t), null);
          } else
            2 * te() - s.renderingStartTime > hr &&
              n !== 1073741824 &&
              ((t.flags |= 128), (r = !0), Mr(s, !1), (t.lanes = 4194304));
        s.isBackwards
          ? ((o.sibling = t.child), (t.child = o))
          : ((n = s.last),
            n !== null ? (n.sibling = o) : (t.child = o),
            (s.last = o));
      }
      return s.tail !== null
        ? ((t = s.tail),
          (s.rendering = t),
          (s.tail = t.sibling),
          (s.renderingStartTime = te()),
          (t.sibling = null),
          (n = X.current),
          H(X, r ? (n & 1) | 2 : n & 1),
          t)
        : (we(t), null);
    case 22:
    case 23:
      return (
        Eu(),
        (r = t.memoizedState !== null),
        e !== null && (e.memoizedState !== null) !== r && (t.flags |= 8192),
        r && t.mode & 1
          ? ze & 1073741824 && (we(t), t.subtreeFlags & 6 && (t.flags |= 8192))
          : we(t),
        null
      );
    case 24:
      return null;
    case 25:
      return null;
  }
  throw Error(C(156, t.tag));
}
function kv(e, t) {
  switch ((uu(t), t.tag)) {
    case 1:
      return (
        Ie(t.type) && As(),
        (e = t.flags),
        e & 65536 ? ((t.flags = (e & -65537) | 128), t) : null
      );
    case 3:
      return (
        dr(),
        G(De),
        G(je),
        vu(),
        (e = t.flags),
        e & 65536 && !(e & 128) ? ((t.flags = (e & -65537) | 128), t) : null
      );
    case 5:
      return (yu(t), null);
    case 13:
      if ((G(X), (e = t.memoizedState), e !== null && e.dehydrated !== null)) {
        if (t.alternate === null) throw Error(C(340));
        ur();
      }
      return (
        (e = t.flags),
        e & 65536 ? ((t.flags = (e & -65537) | 128), t) : null
      );
    case 19:
      return (G(X), null);
    case 4:
      return (dr(), null);
    case 10:
      return (hu(t.type._context), null);
    case 22:
    case 23:
      return (Eu(), null);
    case 24:
      return null;
    default:
      return null;
  }
}
var Xi = !1,
  ke = !1,
  jv = typeof WeakSet == "function" ? WeakSet : Set,
  M = null;
function Qn(e, t) {
  var n = e.ref;
  if (n !== null)
    if (typeof n == "function")
      try {
        n(null);
      } catch (r) {
        J(e, t, r);
      }
    else n.current = null;
}
function sl(e, t, n) {
  try {
    n();
  } catch (r) {
    J(e, t, r);
  }
}
var ld = !1;
function Sv(e, t) {
  if (((Wa = Ps), (e = Zh()), au(e))) {
    if ("selectionStart" in e)
      var n = { start: e.selectionStart, end: e.selectionEnd };
    else
      e: {
        n = ((n = e.ownerDocument) && n.defaultView) || window;
        var r = n.getSelection && n.getSelection();
        if (r && r.rangeCount !== 0) {
          n = r.anchorNode;
          var i = r.anchorOffset,
            s = r.focusNode;
          r = r.focusOffset;
          try {
            (n.nodeType, s.nodeType);
          } catch {
            n = null;
            break e;
          }
          var o = 0,
            l = -1,
            u = -1,
            c = 0,
            d = 0,
            f = e,
            h = null;
          t: for (;;) {
            for (
              var m;
              f !== n || (i !== 0 && f.nodeType !== 3) || (l = o + i),
                f !== s || (r !== 0 && f.nodeType !== 3) || (u = o + r),
                f.nodeType === 3 && (o += f.nodeValue.length),
                (m = f.firstChild) !== null;
            )
              ((h = f), (f = m));
            for (;;) {
              if (f === e) break t;
              if (
                (h === n && ++c === i && (l = o),
                h === s && ++d === r && (u = o),
                (m = f.nextSibling) !== null)
              )
                break;
              ((f = h), (h = f.parentNode));
            }
            f = m;
          }
          n = l === -1 || u === -1 ? null : { start: l, end: u };
        } else n = null;
      }
    n = n || { start: 0, end: 0 };
  } else n = null;
  for (Ua = { focusedElem: e, selectionRange: n }, Ps = !1, M = t; M !== null;)
    if (((t = M), (e = t.child), (t.subtreeFlags & 1028) !== 0 && e !== null))
      ((e.return = t), (M = e));
    else
      for (; M !== null;) {
        t = M;
        try {
          var v = t.alternate;
          if (t.flags & 1024)
            switch (t.tag) {
              case 0:
              case 11:
              case 15:
                break;
              case 1:
                if (v !== null) {
                  var x = v.memoizedProps,
                    k = v.memoizedState,
                    g = t.stateNode,
                    p = g.getSnapshotBeforeUpdate(
                      t.elementType === t.type ? x : lt(t.type, x),
                      k,
                    );
                  g.__reactInternalSnapshotBeforeUpdate = p;
                }
                break;
              case 3:
                var y = t.stateNode.containerInfo;
                y.nodeType === 1
                  ? (y.textContent = "")
                  : y.nodeType === 9 &&
                    y.documentElement &&
                    y.removeChild(y.documentElement);
                break;
              case 5:
              case 6:
              case 4:
              case 17:
                break;
              default:
                throw Error(C(163));
            }
        } catch (w) {
          J(t, t.return, w);
        }
        if (((e = t.sibling), e !== null)) {
          ((e.return = t.return), (M = e));
          break;
        }
        M = t.return;
      }
  return ((v = ld), (ld = !1), v);
}
function $r(e, t, n) {
  var r = t.updateQueue;
  if (((r = r !== null ? r.lastEffect : null), r !== null)) {
    var i = (r = r.next);
    do {
      if ((i.tag & e) === e) {
        var s = i.destroy;
        ((i.destroy = void 0), s !== void 0 && sl(t, n, s));
      }
      i = i.next;
    } while (i !== r);
  }
}
function go(e, t) {
  if (
    ((t = t.updateQueue), (t = t !== null ? t.lastEffect : null), t !== null)
  ) {
    var n = (t = t.next);
    do {
      if ((n.tag & e) === e) {
        var r = n.create;
        n.destroy = r();
      }
      n = n.next;
    } while (n !== t);
  }
}
function ol(e) {
  var t = e.ref;
  if (t !== null) {
    var n = e.stateNode;
    switch (e.tag) {
      case 5:
        e = n;
        break;
      default:
        e = n;
    }
    typeof t == "function" ? t(e) : (t.current = e);
  }
}
function Gp(e) {
  var t = e.alternate;
  (t !== null && ((e.alternate = null), Gp(t)),
    (e.child = null),
    (e.deletions = null),
    (e.sibling = null),
    e.tag === 5 &&
      ((t = e.stateNode),
      t !== null &&
        (delete t[wt], delete t[ui], delete t[Ka], delete t[sv], delete t[ov])),
    (e.stateNode = null),
    (e.return = null),
    (e.dependencies = null),
    (e.memoizedProps = null),
    (e.memoizedState = null),
    (e.pendingProps = null),
    (e.stateNode = null),
    (e.updateQueue = null));
}
function Yp(e) {
  return e.tag === 5 || e.tag === 3 || e.tag === 4;
}
function ud(e) {
  e: for (;;) {
    for (; e.sibling === null;) {
      if (e.return === null || Yp(e.return)) return null;
      e = e.return;
    }
    for (
      e.sibling.return = e.return, e = e.sibling;
      e.tag !== 5 && e.tag !== 6 && e.tag !== 18;
    ) {
      if (e.flags & 2 || e.child === null || e.tag === 4) continue e;
      ((e.child.return = e), (e = e.child));
    }
    if (!(e.flags & 2)) return e.stateNode;
  }
}
function al(e, t, n) {
  var r = e.tag;
  if (r === 5 || r === 6)
    ((e = e.stateNode),
      t
        ? n.nodeType === 8
          ? n.parentNode.insertBefore(e, t)
          : n.insertBefore(e, t)
        : (n.nodeType === 8
            ? ((t = n.parentNode), t.insertBefore(e, n))
            : ((t = n), t.appendChild(e)),
          (n = n._reactRootContainer),
          n != null || t.onclick !== null || (t.onclick = Ms)));
  else if (r !== 4 && ((e = e.child), e !== null))
    for (al(e, t, n), e = e.sibling; e !== null;)
      (al(e, t, n), (e = e.sibling));
}
function ll(e, t, n) {
  var r = e.tag;
  if (r === 5 || r === 6)
    ((e = e.stateNode), t ? n.insertBefore(e, t) : n.appendChild(e));
  else if (r !== 4 && ((e = e.child), e !== null))
    for (ll(e, t, n), e = e.sibling; e !== null;)
      (ll(e, t, n), (e = e.sibling));
}
var he = null,
  ut = !1;
function Vt(e, t, n) {
  for (n = n.child; n !== null;) (Xp(e, t, n), (n = n.sibling));
}
function Xp(e, t, n) {
  if (kt && typeof kt.onCommitFiberUnmount == "function")
    try {
      kt.onCommitFiberUnmount(ao, n);
    } catch {}
  switch (n.tag) {
    case 5:
      ke || Qn(n, t);
    case 6:
      var r = he,
        i = ut;
      ((he = null),
        Vt(e, t, n),
        (he = r),
        (ut = i),
        he !== null &&
          (ut
            ? ((e = he),
              (n = n.stateNode),
              e.nodeType === 8 ? e.parentNode.removeChild(n) : e.removeChild(n))
            : he.removeChild(n.stateNode)));
      break;
    case 18:
      he !== null &&
        (ut
          ? ((e = he),
            (n = n.stateNode),
            e.nodeType === 8
              ? Go(e.parentNode, n)
              : e.nodeType === 1 && Go(e, n),
            ii(e))
          : Go(he, n.stateNode));
      break;
    case 4:
      ((r = he),
        (i = ut),
        (he = n.stateNode.containerInfo),
        (ut = !0),
        Vt(e, t, n),
        (he = r),
        (ut = i));
      break;
    case 0:
    case 11:
    case 14:
    case 15:
      if (
        !ke &&
        ((r = n.updateQueue), r !== null && ((r = r.lastEffect), r !== null))
      ) {
        i = r = r.next;
        do {
          var s = i,
            o = s.destroy;
          ((s = s.tag),
            o !== void 0 && (s & 2 || s & 4) && sl(n, t, o),
            (i = i.next));
        } while (i !== r);
      }
      Vt(e, t, n);
      break;
    case 1:
      if (
        !ke &&
        (Qn(n, t),
        (r = n.stateNode),
        typeof r.componentWillUnmount == "function")
      )
        try {
          ((r.props = n.memoizedProps),
            (r.state = n.memoizedState),
            r.componentWillUnmount());
        } catch (l) {
          J(n, t, l);
        }
      Vt(e, t, n);
      break;
    case 21:
      Vt(e, t, n);
      break;
    case 22:
      n.mode & 1
        ? ((ke = (r = ke) || n.memoizedState !== null), Vt(e, t, n), (ke = r))
        : Vt(e, t, n);
      break;
    default:
      Vt(e, t, n);
  }
}
function cd(e) {
  var t = e.updateQueue;
  if (t !== null) {
    e.updateQueue = null;
    var n = e.stateNode;
    (n === null && (n = e.stateNode = new jv()),
      t.forEach(function (r) {
        var i = Lv.bind(null, e, r);
        n.has(r) || (n.add(r), r.then(i, i));
      }));
  }
}
function st(e, t) {
  var n = t.deletions;
  if (n !== null)
    for (var r = 0; r < n.length; r++) {
      var i = n[r];
      try {
        var s = e,
          o = t,
          l = o;
        e: for (; l !== null;) {
          switch (l.tag) {
            case 5:
              ((he = l.stateNode), (ut = !1));
              break e;
            case 3:
              ((he = l.stateNode.containerInfo), (ut = !0));
              break e;
            case 4:
              ((he = l.stateNode.containerInfo), (ut = !0));
              break e;
          }
          l = l.return;
        }
        if (he === null) throw Error(C(160));
        (Xp(s, o, i), (he = null), (ut = !1));
        var u = i.alternate;
        (u !== null && (u.return = null), (i.return = null));
      } catch (c) {
        J(i, t, c);
      }
    }
  if (t.subtreeFlags & 12854)
    for (t = t.child; t !== null;) (Qp(t, e), (t = t.sibling));
}
function Qp(e, t) {
  var n = e.alternate,
    r = e.flags;
  switch (e.tag) {
    case 0:
    case 11:
    case 14:
    case 15:
      if ((st(t, e), mt(e), r & 4)) {
        try {
          ($r(3, e, e.return), go(3, e));
        } catch (x) {
          J(e, e.return, x);
        }
        try {
          $r(5, e, e.return);
        } catch (x) {
          J(e, e.return, x);
        }
      }
      break;
    case 1:
      (st(t, e), mt(e), r & 512 && n !== null && Qn(n, n.return));
      break;
    case 5:
      if (
        (st(t, e),
        mt(e),
        r & 512 && n !== null && Qn(n, n.return),
        e.flags & 32)
      ) {
        var i = e.stateNode;
        try {
          ei(i, "");
        } catch (x) {
          J(e, e.return, x);
        }
      }
      if (r & 4 && ((i = e.stateNode), i != null)) {
        var s = e.memoizedProps,
          o = n !== null ? n.memoizedProps : s,
          l = e.type,
          u = e.updateQueue;
        if (((e.updateQueue = null), u !== null))
          try {
            (l === "input" && s.type === "radio" && s.name != null && vh(i, s),
              La(l, o));
            var c = La(l, s);
            for (o = 0; o < u.length; o += 2) {
              var d = u[o],
                f = u[o + 1];
              d === "style"
                ? Sh(i, f)
                : d === "dangerouslySetInnerHTML"
                  ? kh(i, f)
                  : d === "children"
                    ? ei(i, f)
                    : Yl(i, d, f, c);
            }
            switch (l) {
              case "input":
                Pa(i, s);
                break;
              case "textarea":
                xh(i, s);
                break;
              case "select":
                var h = i._wrapperState.wasMultiple;
                i._wrapperState.wasMultiple = !!s.multiple;
                var m = s.value;
                m != null
                  ? tr(i, !!s.multiple, m, !1)
                  : h !== !!s.multiple &&
                    (s.defaultValue != null
                      ? tr(i, !!s.multiple, s.defaultValue, !0)
                      : tr(i, !!s.multiple, s.multiple ? [] : "", !1));
            }
            i[ui] = s;
          } catch (x) {
            J(e, e.return, x);
          }
      }
      break;
    case 6:
      if ((st(t, e), mt(e), r & 4)) {
        if (e.stateNode === null) throw Error(C(162));
        ((i = e.stateNode), (s = e.memoizedProps));
        try {
          i.nodeValue = s;
        } catch (x) {
          J(e, e.return, x);
        }
      }
      break;
    case 3:
      if (
        (st(t, e), mt(e), r & 4 && n !== null && n.memoizedState.isDehydrated)
      )
        try {
          ii(t.containerInfo);
        } catch (x) {
          J(e, e.return, x);
        }
      break;
    case 4:
      (st(t, e), mt(e));
      break;
    case 13:
      (st(t, e),
        mt(e),
        (i = e.child),
        i.flags & 8192 &&
          ((s = i.memoizedState !== null),
          (i.stateNode.isHidden = s),
          !s ||
            (i.alternate !== null && i.alternate.memoizedState !== null) ||
            (Pu = te())),
        r & 4 && cd(e));
      break;
    case 22:
      if (
        ((d = n !== null && n.memoizedState !== null),
        e.mode & 1 ? ((ke = (c = ke) || d), st(t, e), (ke = c)) : st(t, e),
        mt(e),
        r & 8192)
      ) {
        if (
          ((c = e.memoizedState !== null),
          (e.stateNode.isHidden = c) && !d && e.mode & 1)
        )
          for (M = e, d = e.child; d !== null;) {
            for (f = M = d; M !== null;) {
              switch (((h = M), (m = h.child), h.tag)) {
                case 0:
                case 11:
                case 14:
                case 15:
                  $r(4, h, h.return);
                  break;
                case 1:
                  Qn(h, h.return);
                  var v = h.stateNode;
                  if (typeof v.componentWillUnmount == "function") {
                    ((r = h), (n = h.return));
                    try {
                      ((t = r),
                        (v.props = t.memoizedProps),
                        (v.state = t.memoizedState),
                        v.componentWillUnmount());
                    } catch (x) {
                      J(r, n, x);
                    }
                  }
                  break;
                case 5:
                  Qn(h, h.return);
                  break;
                case 22:
                  if (h.memoizedState !== null) {
                    fd(f);
                    continue;
                  }
              }
              m !== null ? ((m.return = h), (M = m)) : fd(f);
            }
            d = d.sibling;
          }
        e: for (d = null, f = e; ;) {
          if (f.tag === 5) {
            if (d === null) {
              d = f;
              try {
                ((i = f.stateNode),
                  c
                    ? ((s = i.style),
                      typeof s.setProperty == "function"
                        ? s.setProperty("display", "none", "important")
                        : (s.display = "none"))
                    : ((l = f.stateNode),
                      (u = f.memoizedProps.style),
                      (o =
                        u != null && u.hasOwnProperty("display")
                          ? u.display
                          : null),
                      (l.style.display = jh("display", o))));
              } catch (x) {
                J(e, e.return, x);
              }
            }
          } else if (f.tag === 6) {
            if (d === null)
              try {
                f.stateNode.nodeValue = c ? "" : f.memoizedProps;
              } catch (x) {
                J(e, e.return, x);
              }
          } else if (
            ((f.tag !== 22 && f.tag !== 23) ||
              f.memoizedState === null ||
              f === e) &&
            f.child !== null
          ) {
            ((f.child.return = f), (f = f.child));
            continue;
          }
          if (f === e) break e;
          for (; f.sibling === null;) {
            if (f.return === null || f.return === e) break e;
            (d === f && (d = null), (f = f.return));
          }
          (d === f && (d = null),
            (f.sibling.return = f.return),
            (f = f.sibling));
        }
      }
      break;
    case 19:
      (st(t, e), mt(e), r & 4 && cd(e));
      break;
    case 21:
      break;
    default:
      (st(t, e), mt(e));
  }
}
function mt(e) {
  var t = e.flags;
  if (t & 2) {
    try {
      e: {
        for (var n = e.return; n !== null;) {
          if (Yp(n)) {
            var r = n;
            break e;
          }
          n = n.return;
        }
        throw Error(C(160));
      }
      switch (r.tag) {
        case 5:
          var i = r.stateNode;
          r.flags & 32 && (ei(i, ""), (r.flags &= -33));
          var s = ud(e);
          ll(e, s, i);
          break;
        case 3:
        case 4:
          var o = r.stateNode.containerInfo,
            l = ud(e);
          al(e, l, o);
          break;
        default:
          throw Error(C(161));
      }
    } catch (u) {
      J(e, e.return, u);
    }
    e.flags &= -3;
  }
  t & 4096 && (e.flags &= -4097);
}
function bv(e, t, n) {
  ((M = e), Zp(e));
}
function Zp(e, t, n) {
  for (var r = (e.mode & 1) !== 0; M !== null;) {
    var i = M,
      s = i.child;
    if (i.tag === 22 && r) {
      var o = i.memoizedState !== null || Xi;
      if (!o) {
        var l = i.alternate,
          u = (l !== null && l.memoizedState !== null) || ke;
        l = Xi;
        var c = ke;
        if (((Xi = o), (ke = u) && !c))
          for (M = i; M !== null;)
            ((o = M),
              (u = o.child),
              o.tag === 22 && o.memoizedState !== null
                ? hd(i)
                : u !== null
                  ? ((u.return = o), (M = u))
                  : hd(i));
        for (; s !== null;) ((M = s), Zp(s), (s = s.sibling));
        ((M = i), (Xi = l), (ke = c));
      }
      dd(e);
    } else
      i.subtreeFlags & 8772 && s !== null ? ((s.return = i), (M = s)) : dd(e);
  }
}
function dd(e) {
  for (; M !== null;) {
    var t = M;
    if (t.flags & 8772) {
      var n = t.alternate;
      try {
        if (t.flags & 8772)
          switch (t.tag) {
            case 0:
            case 11:
            case 15:
              ke || go(5, t);
              break;
            case 1:
              var r = t.stateNode;
              if (t.flags & 4 && !ke)
                if (n === null) r.componentDidMount();
                else {
                  var i =
                    t.elementType === t.type
                      ? n.memoizedProps
                      : lt(t.type, n.memoizedProps);
                  r.componentDidUpdate(
                    i,
                    n.memoizedState,
                    r.__reactInternalSnapshotBeforeUpdate,
                  );
                }
              var s = t.updateQueue;
              s !== null && Xc(t, s, r);
              break;
            case 3:
              var o = t.updateQueue;
              if (o !== null) {
                if (((n = null), t.child !== null))
                  switch (t.child.tag) {
                    case 5:
                      n = t.child.stateNode;
                      break;
                    case 1:
                      n = t.child.stateNode;
                  }
                Xc(t, o, n);
              }
              break;
            case 5:
              var l = t.stateNode;
              if (n === null && t.flags & 4) {
                n = l;
                var u = t.memoizedProps;
                switch (t.type) {
                  case "button":
                  case "input":
                  case "select":
                  case "textarea":
                    u.autoFocus && n.focus();
                    break;
                  case "img":
                    u.src && (n.src = u.src);
                }
              }
              break;
            case 6:
              break;
            case 4:
              break;
            case 12:
              break;
            case 13:
              if (t.memoizedState === null) {
                var c = t.alternate;
                if (c !== null) {
                  var d = c.memoizedState;
                  if (d !== null) {
                    var f = d.dehydrated;
                    f !== null && ii(f);
                  }
                }
              }
              break;
            case 19:
            case 17:
            case 21:
            case 22:
            case 23:
            case 25:
              break;
            default:
              throw Error(C(163));
          }
        ke || (t.flags & 512 && ol(t));
      } catch (h) {
        J(t, t.return, h);
      }
    }
    if (t === e) {
      M = null;
      break;
    }
    if (((n = t.sibling), n !== null)) {
      ((n.return = t.return), (M = n));
      break;
    }
    M = t.return;
  }
}
function fd(e) {
  for (; M !== null;) {
    var t = M;
    if (t === e) {
      M = null;
      break;
    }
    var n = t.sibling;
    if (n !== null) {
      ((n.return = t.return), (M = n));
      break;
    }
    M = t.return;
  }
}
function hd(e) {
  for (; M !== null;) {
    var t = M;
    try {
      switch (t.tag) {
        case 0:
        case 11:
        case 15:
          var n = t.return;
          try {
            go(4, t);
          } catch (u) {
            J(t, n, u);
          }
          break;
        case 1:
          var r = t.stateNode;
          if (typeof r.componentDidMount == "function") {
            var i = t.return;
            try {
              r.componentDidMount();
            } catch (u) {
              J(t, i, u);
            }
          }
          var s = t.return;
          try {
            ol(t);
          } catch (u) {
            J(t, s, u);
          }
          break;
        case 5:
          var o = t.return;
          try {
            ol(t);
          } catch (u) {
            J(t, o, u);
          }
      }
    } catch (u) {
      J(t, t.return, u);
    }
    if (t === e) {
      M = null;
      break;
    }
    var l = t.sibling;
    if (l !== null) {
      ((l.return = t.return), (M = l));
      break;
    }
    M = t.return;
  }
}
var Cv = Math.ceil,
  _s = It.ReactCurrentDispatcher,
  Cu = It.ReactCurrentOwner,
  Je = It.ReactCurrentBatchConfig,
  F = 0,
  fe = null,
  se = null,
  ge = 0,
  ze = 0,
  Zn = cn(0),
  le = 0,
  mi = null,
  Ln = 0,
  yo = 0,
  Tu = 0,
  Kr = null,
  Le = null,
  Pu = 0,
  hr = 1 / 0,
  Ct = null,
  Ws = !1,
  ul = null,
  en = null,
  Qi = !1,
  Kt = null,
  Us = 0,
  Gr = 0,
  cl = null,
  fs = -1,
  hs = 0;
function Pe() {
  return F & 6 ? te() : fs !== -1 ? fs : (fs = te());
}
function tn(e) {
  return e.mode & 1
    ? F & 2 && ge !== 0
      ? ge & -ge
      : lv.transition !== null
        ? (hs === 0 && (hs = Ih()), hs)
        : ((e = z),
          e !== 0 || ((e = window.event), (e = e === void 0 ? 16 : Wh(e.type))),
          e)
    : 1;
}
function ft(e, t, n, r) {
  if (50 < Gr) throw ((Gr = 0), (cl = null), Error(C(185)));
  (Si(e, n, r),
    (!(F & 2) || e !== fe) &&
      (e === fe && (!(F & 2) && (yo |= n), le === 4 && Ht(e, ge)),
      Ve(e, r),
      n === 1 && F === 0 && !(t.mode & 1) && ((hr = te() + 500), ho && dn())));
}
function Ve(e, t) {
  var n = e.callbackNode;
  l0(e, t);
  var r = Ts(e, e === fe ? ge : 0);
  if (r === 0)
    (n !== null && jc(n), (e.callbackNode = null), (e.callbackPriority = 0));
  else if (((t = r & -r), e.callbackPriority !== t)) {
    if ((n != null && jc(n), t === 1))
      (e.tag === 0 ? av(pd.bind(null, e)) : ap(pd.bind(null, e)),
        rv(function () {
          !(F & 6) && dn();
        }),
        (n = null));
    else {
      switch (Vh(r)) {
        case 1:
          n = Jl;
          break;
        case 4:
          n = Rh;
          break;
        case 16:
          n = Cs;
          break;
        case 536870912:
          n = Dh;
          break;
        default:
          n = Cs;
      }
      n = sm(n, qp.bind(null, e));
    }
    ((e.callbackPriority = t), (e.callbackNode = n));
  }
}
function qp(e, t) {
  if (((fs = -1), (hs = 0), F & 6)) throw Error(C(327));
  var n = e.callbackNode;
  if (or() && e.callbackNode !== n) return null;
  var r = Ts(e, e === fe ? ge : 0);
  if (r === 0) return null;
  if (r & 30 || r & e.expiredLanes || t) t = Hs(e, r);
  else {
    t = r;
    var i = F;
    F |= 2;
    var s = em();
    (fe !== e || ge !== t) && ((Ct = null), (hr = te() + 500), Cn(e, t));
    do
      try {
        Nv();
        break;
      } catch (l) {
        Jp(e, l);
      }
    while (!0);
    (fu(),
      (_s.current = s),
      (F = i),
      se !== null ? (t = 0) : ((fe = null), (ge = 0), (t = le)));
  }
  if (t !== 0) {
    if (
      (t === 2 && ((i = Ba(e)), i !== 0 && ((r = i), (t = dl(e, i)))), t === 1)
    )
      throw ((n = mi), Cn(e, 0), Ht(e, r), Ve(e, te()), n);
    if (t === 6) Ht(e, r);
    else {
      if (
        ((i = e.current.alternate),
        !(r & 30) &&
          !Tv(i) &&
          ((t = Hs(e, r)),
          t === 2 && ((s = Ba(e)), s !== 0 && ((r = s), (t = dl(e, s)))),
          t === 1))
      )
        throw ((n = mi), Cn(e, 0), Ht(e, r), Ve(e, te()), n);
      switch (((e.finishedWork = i), (e.finishedLanes = r), t)) {
        case 0:
        case 1:
          throw Error(C(345));
        case 2:
          vn(e, Le, Ct);
          break;
        case 3:
          if (
            (Ht(e, r), (r & 130023424) === r && ((t = Pu + 500 - te()), 10 < t))
          ) {
            if (Ts(e, 0) !== 0) break;
            if (((i = e.suspendedLanes), (i & r) !== r)) {
              (Pe(), (e.pingedLanes |= e.suspendedLanes & i));
              break;
            }
            e.timeoutHandle = $a(vn.bind(null, e, Le, Ct), t);
            break;
          }
          vn(e, Le, Ct);
          break;
        case 4:
          if ((Ht(e, r), (r & 4194240) === r)) break;
          for (t = e.eventTimes, i = -1; 0 < r;) {
            var o = 31 - dt(r);
            ((s = 1 << o), (o = t[o]), o > i && (i = o), (r &= ~s));
          }
          if (
            ((r = i),
            (r = te() - r),
            (r =
              (120 > r
                ? 120
                : 480 > r
                  ? 480
                  : 1080 > r
                    ? 1080
                    : 1920 > r
                      ? 1920
                      : 3e3 > r
                        ? 3e3
                        : 4320 > r
                          ? 4320
                          : 1960 * Cv(r / 1960)) - r),
            10 < r)
          ) {
            e.timeoutHandle = $a(vn.bind(null, e, Le, Ct), r);
            break;
          }
          vn(e, Le, Ct);
          break;
        case 5:
          vn(e, Le, Ct);
          break;
        default:
          throw Error(C(329));
      }
    }
  }
  return (Ve(e, te()), e.callbackNode === n ? qp.bind(null, e) : null);
}
function dl(e, t) {
  var n = Kr;
  return (
    e.current.memoizedState.isDehydrated && (Cn(e, t).flags |= 256),
    (e = Hs(e, t)),
    e !== 2 && ((t = Le), (Le = n), t !== null && fl(t)),
    e
  );
}
function fl(e) {
  Le === null ? (Le = e) : Le.push.apply(Le, e);
}
function Tv(e) {
  for (var t = e; ;) {
    if (t.flags & 16384) {
      var n = t.updateQueue;
      if (n !== null && ((n = n.stores), n !== null))
        for (var r = 0; r < n.length; r++) {
          var i = n[r],
            s = i.getSnapshot;
          i = i.value;
          try {
            if (!pt(s(), i)) return !1;
          } catch {
            return !1;
          }
        }
    }
    if (((n = t.child), t.subtreeFlags & 16384 && n !== null))
      ((n.return = t), (t = n));
    else {
      if (t === e) break;
      for (; t.sibling === null;) {
        if (t.return === null || t.return === e) return !0;
        t = t.return;
      }
      ((t.sibling.return = t.return), (t = t.sibling));
    }
  }
  return !0;
}
function Ht(e, t) {
  for (
    t &= ~Tu,
      t &= ~yo,
      e.suspendedLanes |= t,
      e.pingedLanes &= ~t,
      e = e.expirationTimes;
    0 < t;
  ) {
    var n = 31 - dt(t),
      r = 1 << n;
    ((e[n] = -1), (t &= ~r));
  }
}
function pd(e) {
  if (F & 6) throw Error(C(327));
  or();
  var t = Ts(e, 0);
  if (!(t & 1)) return (Ve(e, te()), null);
  var n = Hs(e, t);
  if (e.tag !== 0 && n === 2) {
    var r = Ba(e);
    r !== 0 && ((t = r), (n = dl(e, r)));
  }
  if (n === 1) throw ((n = mi), Cn(e, 0), Ht(e, t), Ve(e, te()), n);
  if (n === 6) throw Error(C(345));
  return (
    (e.finishedWork = e.current.alternate),
    (e.finishedLanes = t),
    vn(e, Le, Ct),
    Ve(e, te()),
    null
  );
}
function Nu(e, t) {
  var n = F;
  F |= 1;
  try {
    return e(t);
  } finally {
    ((F = n), F === 0 && ((hr = te() + 500), ho && dn()));
  }
}
function Rn(e) {
  Kt !== null && Kt.tag === 0 && !(F & 6) && or();
  var t = F;
  F |= 1;
  var n = Je.transition,
    r = z;
  try {
    if (((Je.transition = null), (z = 1), e)) return e();
  } finally {
    ((z = r), (Je.transition = n), (F = t), !(F & 6) && dn());
  }
}
function Eu() {
  ((ze = Zn.current), G(Zn));
}
function Cn(e, t) {
  ((e.finishedWork = null), (e.finishedLanes = 0));
  var n = e.timeoutHandle;
  if ((n !== -1 && ((e.timeoutHandle = -1), nv(n)), se !== null))
    for (n = se.return; n !== null;) {
      var r = n;
      switch ((uu(r), r.tag)) {
        case 1:
          ((r = r.type.childContextTypes), r != null && As());
          break;
        case 3:
          (dr(), G(De), G(je), vu());
          break;
        case 5:
          yu(r);
          break;
        case 4:
          dr();
          break;
        case 13:
          G(X);
          break;
        case 19:
          G(X);
          break;
        case 10:
          hu(r.type._context);
          break;
        case 22:
        case 23:
          Eu();
      }
      n = n.return;
    }
  if (
    ((fe = e),
    (se = e = nn(e.current, null)),
    (ge = ze = t),
    (le = 0),
    (mi = null),
    (Tu = yo = Ln = 0),
    (Le = Kr = null),
    kn !== null)
  ) {
    for (t = 0; t < kn.length; t++)
      if (((n = kn[t]), (r = n.interleaved), r !== null)) {
        n.interleaved = null;
        var i = r.next,
          s = n.pending;
        if (s !== null) {
          var o = s.next;
          ((s.next = i), (r.next = o));
        }
        n.pending = r;
      }
    kn = null;
  }
  return e;
}
function Jp(e, t) {
  do {
    var n = se;
    try {
      if ((fu(), (us.current = zs), Fs)) {
        for (var r = Q.memoizedState; r !== null;) {
          var i = r.queue;
          (i !== null && (i.pending = null), (r = r.next));
        }
        Fs = !1;
      }
      if (
        ((An = 0),
        (de = ae = Q = null),
        (Hr = !1),
        (fi = 0),
        (Cu.current = null),
        n === null || n.return === null)
      ) {
        ((le = 1), (mi = t), (se = null));
        break;
      }
      e: {
        var s = e,
          o = n.return,
          l = n,
          u = t;
        if (
          ((t = ge),
          (l.flags |= 32768),
          u !== null && typeof u == "object" && typeof u.then == "function")
        ) {
          var c = u,
            d = l,
            f = d.tag;
          if (!(d.mode & 1) && (f === 0 || f === 11 || f === 15)) {
            var h = d.alternate;
            h
              ? ((d.updateQueue = h.updateQueue),
                (d.memoizedState = h.memoizedState),
                (d.lanes = h.lanes))
              : ((d.updateQueue = null), (d.memoizedState = null));
          }
          var m = td(o);
          if (m !== null) {
            ((m.flags &= -257),
              nd(m, o, l, s, t),
              m.mode & 1 && ed(s, c, t),
              (t = m),
              (u = c));
            var v = t.updateQueue;
            if (v === null) {
              var x = new Set();
              (x.add(u), (t.updateQueue = x));
            } else v.add(u);
            break e;
          } else {
            if (!(t & 1)) {
              (ed(s, c, t), Mu());
              break e;
            }
            u = Error(C(426));
          }
        } else if (Y && l.mode & 1) {
          var k = td(o);
          if (k !== null) {
            (!(k.flags & 65536) && (k.flags |= 256),
              nd(k, o, l, s, t),
              cu(fr(u, l)));
            break e;
          }
        }
        ((s = u = fr(u, l)),
          le !== 4 && (le = 2),
          Kr === null ? (Kr = [s]) : Kr.push(s),
          (s = o));
        do {
          switch (s.tag) {
            case 3:
              ((s.flags |= 65536), (t &= -t), (s.lanes |= t));
              var g = Vp(s, u, t);
              Yc(s, g);
              break e;
            case 1:
              l = u;
              var p = s.type,
                y = s.stateNode;
              if (
                !(s.flags & 128) &&
                (typeof p.getDerivedStateFromError == "function" ||
                  (y !== null &&
                    typeof y.componentDidCatch == "function" &&
                    (en === null || !en.has(y))))
              ) {
                ((s.flags |= 65536), (t &= -t), (s.lanes |= t));
                var w = Bp(s, l, t);
                Yc(s, w);
                break e;
              }
          }
          s = s.return;
        } while (s !== null);
      }
      nm(n);
    } catch (S) {
      ((t = S), se === n && n !== null && (se = n = n.return));
      continue;
    }
    break;
  } while (!0);
}
function em() {
  var e = _s.current;
  return ((_s.current = zs), e === null ? zs : e);
}
function Mu() {
  ((le === 0 || le === 3 || le === 2) && (le = 4),
    fe === null || (!(Ln & 268435455) && !(yo & 268435455)) || Ht(fe, ge));
}
function Hs(e, t) {
  var n = F;
  F |= 2;
  var r = em();
  (fe !== e || ge !== t) && ((Ct = null), Cn(e, t));
  do
    try {
      Pv();
      break;
    } catch (i) {
      Jp(e, i);
    }
  while (!0);
  if ((fu(), (F = n), (_s.current = r), se !== null)) throw Error(C(261));
  return ((fe = null), (ge = 0), le);
}
function Pv() {
  for (; se !== null;) tm(se);
}
function Nv() {
  for (; se !== null && !Jy();) tm(se);
}
function tm(e) {
  var t = im(e.alternate, e, ze);
  ((e.memoizedProps = e.pendingProps),
    t === null ? nm(e) : (se = t),
    (Cu.current = null));
}
function nm(e) {
  var t = e;
  do {
    var n = t.alternate;
    if (((e = t.return), t.flags & 32768)) {
      if (((n = kv(n, t)), n !== null)) {
        ((n.flags &= 32767), (se = n));
        return;
      }
      if (e !== null)
        ((e.flags |= 32768), (e.subtreeFlags = 0), (e.deletions = null));
      else {
        ((le = 6), (se = null));
        return;
      }
    } else if (((n = wv(n, t, ze)), n !== null)) {
      se = n;
      return;
    }
    if (((t = t.sibling), t !== null)) {
      se = t;
      return;
    }
    se = t = e;
  } while (t !== null);
  le === 0 && (le = 5);
}
function vn(e, t, n) {
  var r = z,
    i = Je.transition;
  try {
    ((Je.transition = null), (z = 1), Ev(e, t, n, r));
  } finally {
    ((Je.transition = i), (z = r));
  }
  return null;
}
function Ev(e, t, n, r) {
  do or();
  while (Kt !== null);
  if (F & 6) throw Error(C(327));
  n = e.finishedWork;
  var i = e.finishedLanes;
  if (n === null) return null;
  if (((e.finishedWork = null), (e.finishedLanes = 0), n === e.current))
    throw Error(C(177));
  ((e.callbackNode = null), (e.callbackPriority = 0));
  var s = n.lanes | n.childLanes;
  if (
    (u0(e, s),
    e === fe && ((se = fe = null), (ge = 0)),
    (!(n.subtreeFlags & 2064) && !(n.flags & 2064)) ||
      Qi ||
      ((Qi = !0),
      sm(Cs, function () {
        return (or(), null);
      })),
    (s = (n.flags & 15990) !== 0),
    n.subtreeFlags & 15990 || s)
  ) {
    ((s = Je.transition), (Je.transition = null));
    var o = z;
    z = 1;
    var l = F;
    ((F |= 4),
      (Cu.current = null),
      Sv(e, n),
      Qp(n, e),
      X0(Ua),
      (Ps = !!Wa),
      (Ua = Wa = null),
      (e.current = n),
      bv(n),
      e0(),
      (F = l),
      (z = o),
      (Je.transition = s));
  } else e.current = n;
  if (
    (Qi && ((Qi = !1), (Kt = e), (Us = i)),
    (s = e.pendingLanes),
    s === 0 && (en = null),
    r0(n.stateNode),
    Ve(e, te()),
    t !== null)
  )
    for (r = e.onRecoverableError, n = 0; n < t.length; n++)
      ((i = t[n]), r(i.value, { componentStack: i.stack, digest: i.digest }));
  if (Ws) throw ((Ws = !1), (e = ul), (ul = null), e);
  return (
    Us & 1 && e.tag !== 0 && or(),
    (s = e.pendingLanes),
    s & 1 ? (e === cl ? Gr++ : ((Gr = 0), (cl = e))) : (Gr = 0),
    dn(),
    null
  );
}
function or() {
  if (Kt !== null) {
    var e = Vh(Us),
      t = Je.transition,
      n = z;
    try {
      if (((Je.transition = null), (z = 16 > e ? 16 : e), Kt === null))
        var r = !1;
      else {
        if (((e = Kt), (Kt = null), (Us = 0), F & 6)) throw Error(C(331));
        var i = F;
        for (F |= 4, M = e.current; M !== null;) {
          var s = M,
            o = s.child;
          if (M.flags & 16) {
            var l = s.deletions;
            if (l !== null) {
              for (var u = 0; u < l.length; u++) {
                var c = l[u];
                for (M = c; M !== null;) {
                  var d = M;
                  switch (d.tag) {
                    case 0:
                    case 11:
                    case 15:
                      $r(8, d, s);
                  }
                  var f = d.child;
                  if (f !== null) ((f.return = d), (M = f));
                  else
                    for (; M !== null;) {
                      d = M;
                      var h = d.sibling,
                        m = d.return;
                      if ((Gp(d), d === c)) {
                        M = null;
                        break;
                      }
                      if (h !== null) {
                        ((h.return = m), (M = h));
                        break;
                      }
                      M = m;
                    }
                }
              }
              var v = s.alternate;
              if (v !== null) {
                var x = v.child;
                if (x !== null) {
                  v.child = null;
                  do {
                    var k = x.sibling;
                    ((x.sibling = null), (x = k));
                  } while (x !== null);
                }
              }
              M = s;
            }
          }
          if (s.subtreeFlags & 2064 && o !== null) ((o.return = s), (M = o));
          else
            e: for (; M !== null;) {
              if (((s = M), s.flags & 2048))
                switch (s.tag) {
                  case 0:
                  case 11:
                  case 15:
                    $r(9, s, s.return);
                }
              var g = s.sibling;
              if (g !== null) {
                ((g.return = s.return), (M = g));
                break e;
              }
              M = s.return;
            }
        }
        var p = e.current;
        for (M = p; M !== null;) {
          o = M;
          var y = o.child;
          if (o.subtreeFlags & 2064 && y !== null) ((y.return = o), (M = y));
          else
            e: for (o = p; M !== null;) {
              if (((l = M), l.flags & 2048))
                try {
                  switch (l.tag) {
                    case 0:
                    case 11:
                    case 15:
                      go(9, l);
                  }
                } catch (S) {
                  J(l, l.return, S);
                }
              if (l === o) {
                M = null;
                break e;
              }
              var w = l.sibling;
              if (w !== null) {
                ((w.return = l.return), (M = w));
                break e;
              }
              M = l.return;
            }
        }
        if (
          ((F = i), dn(), kt && typeof kt.onPostCommitFiberRoot == "function")
        )
          try {
            kt.onPostCommitFiberRoot(ao, e);
          } catch {}
        r = !0;
      }
      return r;
    } finally {
      ((z = n), (Je.transition = t));
    }
  }
  return !1;
}
function md(e, t, n) {
  ((t = fr(n, t)),
    (t = Vp(e, t, 1)),
    (e = Jt(e, t, 1)),
    (t = Pe()),
    e !== null && (Si(e, 1, t), Ve(e, t)));
}
function J(e, t, n) {
  if (e.tag === 3) md(e, e, n);
  else
    for (; t !== null;) {
      if (t.tag === 3) {
        md(t, e, n);
        break;
      } else if (t.tag === 1) {
        var r = t.stateNode;
        if (
          typeof t.type.getDerivedStateFromError == "function" ||
          (typeof r.componentDidCatch == "function" &&
            (en === null || !en.has(r)))
        ) {
          ((e = fr(n, e)),
            (e = Bp(t, e, 1)),
            (t = Jt(t, e, 1)),
            (e = Pe()),
            t !== null && (Si(t, 1, e), Ve(t, e)));
          break;
        }
      }
      t = t.return;
    }
}
function Mv(e, t, n) {
  var r = e.pingCache;
  (r !== null && r.delete(t),
    (t = Pe()),
    (e.pingedLanes |= e.suspendedLanes & n),
    fe === e &&
      (ge & n) === n &&
      (le === 4 || (le === 3 && (ge & 130023424) === ge && 500 > te() - Pu)
        ? Cn(e, 0)
        : (Tu |= n)),
    Ve(e, t));
}
function rm(e, t) {
  t === 0 &&
    (e.mode & 1
      ? ((t = zi), (zi <<= 1), !(zi & 130023424) && (zi = 4194304))
      : (t = 1));
  var n = Pe();
  ((e = Rt(e, t)), e !== null && (Si(e, t, n), Ve(e, n)));
}
function Av(e) {
  var t = e.memoizedState,
    n = 0;
  (t !== null && (n = t.retryLane), rm(e, n));
}
function Lv(e, t) {
  var n = 0;
  switch (e.tag) {
    case 13:
      var r = e.stateNode,
        i = e.memoizedState;
      i !== null && (n = i.retryLane);
      break;
    case 19:
      r = e.stateNode;
      break;
    default:
      throw Error(C(314));
  }
  (r !== null && r.delete(t), rm(e, n));
}
var im;
im = function (e, t, n) {
  if (e !== null)
    if (e.memoizedProps !== t.pendingProps || De.current) Re = !0;
    else {
      if (!(e.lanes & n) && !(t.flags & 128)) return ((Re = !1), xv(e, t, n));
      Re = !!(e.flags & 131072);
    }
  else ((Re = !1), Y && t.flags & 1048576 && lp(t, Ds, t.index));
  switch (((t.lanes = 0), t.tag)) {
    case 2:
      var r = t.type;
      (ds(e, t), (e = t.pendingProps));
      var i = lr(t, je.current);
      (sr(t, n), (i = wu(null, t, r, e, i, n)));
      var s = ku();
      return (
        (t.flags |= 1),
        typeof i == "object" &&
        i !== null &&
        typeof i.render == "function" &&
        i.$$typeof === void 0
          ? ((t.tag = 1),
            (t.memoizedState = null),
            (t.updateQueue = null),
            Ie(r) ? ((s = !0), Ls(t)) : (s = !1),
            (t.memoizedState =
              i.state !== null && i.state !== void 0 ? i.state : null),
            mu(t),
            (i.updater = mo),
            (t.stateNode = i),
            (i._reactInternals = t),
            qa(t, r, e, n),
            (t = tl(null, t, r, !0, s, n)))
          : ((t.tag = 0), Y && s && lu(t), be(null, t, i, n), (t = t.child)),
        t
      );
    case 16:
      r = t.elementType;
      e: {
        switch (
          (ds(e, t),
          (e = t.pendingProps),
          (i = r._init),
          (r = i(r._payload)),
          (t.type = r),
          (i = t.tag = Dv(r)),
          (e = lt(r, e)),
          i)
        ) {
          case 0:
            t = el(null, t, r, e, n);
            break e;
          case 1:
            t = sd(null, t, r, e, n);
            break e;
          case 11:
            t = rd(null, t, r, e, n);
            break e;
          case 14:
            t = id(null, t, r, lt(r.type, e), n);
            break e;
        }
        throw Error(C(306, r, ""));
      }
      return t;
    case 0:
      return (
        (r = t.type),
        (i = t.pendingProps),
        (i = t.elementType === r ? i : lt(r, i)),
        el(e, t, r, i, n)
      );
    case 1:
      return (
        (r = t.type),
        (i = t.pendingProps),
        (i = t.elementType === r ? i : lt(r, i)),
        sd(e, t, r, i, n)
      );
    case 3:
      e: {
        if ((_p(t), e === null)) throw Error(C(387));
        ((r = t.pendingProps),
          (s = t.memoizedState),
          (i = s.element),
          pp(e, t),
          Bs(t, r, null, n));
        var o = t.memoizedState;
        if (((r = o.element), s.isDehydrated))
          if (
            ((s = {
              element: r,
              isDehydrated: !1,
              cache: o.cache,
              pendingSuspenseBoundaries: o.pendingSuspenseBoundaries,
              transitions: o.transitions,
            }),
            (t.updateQueue.baseState = s),
            (t.memoizedState = s),
            t.flags & 256)
          ) {
            ((i = fr(Error(C(423)), t)), (t = od(e, t, r, n, i)));
            break e;
          } else if (r !== i) {
            ((i = fr(Error(C(424)), t)), (t = od(e, t, r, n, i)));
            break e;
          } else
            for (
              _e = qt(t.stateNode.containerInfo.firstChild),
                We = t,
                Y = !0,
                ct = null,
                n = fp(t, null, r, n),
                t.child = n;
              n;
            )
              ((n.flags = (n.flags & -3) | 4096), (n = n.sibling));
        else {
          if ((ur(), r === i)) {
            t = Dt(e, t, n);
            break e;
          }
          be(e, t, r, n);
        }
        t = t.child;
      }
      return t;
    case 5:
      return (
        mp(t),
        e === null && Xa(t),
        (r = t.type),
        (i = t.pendingProps),
        (s = e !== null ? e.memoizedProps : null),
        (o = i.children),
        Ha(r, i) ? (o = null) : s !== null && Ha(r, s) && (t.flags |= 32),
        zp(e, t),
        be(e, t, o, n),
        t.child
      );
    case 6:
      return (e === null && Xa(t), null);
    case 13:
      return Wp(e, t, n);
    case 4:
      return (
        gu(t, t.stateNode.containerInfo),
        (r = t.pendingProps),
        e === null ? (t.child = cr(t, null, r, n)) : be(e, t, r, n),
        t.child
      );
    case 11:
      return (
        (r = t.type),
        (i = t.pendingProps),
        (i = t.elementType === r ? i : lt(r, i)),
        rd(e, t, r, i, n)
      );
    case 7:
      return (be(e, t, t.pendingProps, n), t.child);
    case 8:
      return (be(e, t, t.pendingProps.children, n), t.child);
    case 12:
      return (be(e, t, t.pendingProps.children, n), t.child);
    case 10:
      e: {
        if (
          ((r = t.type._context),
          (i = t.pendingProps),
          (s = t.memoizedProps),
          (o = i.value),
          H(Is, r._currentValue),
          (r._currentValue = o),
          s !== null)
        )
          if (pt(s.value, o)) {
            if (s.children === i.children && !De.current) {
              t = Dt(e, t, n);
              break e;
            }
          } else
            for (s = t.child, s !== null && (s.return = t); s !== null;) {
              var l = s.dependencies;
              if (l !== null) {
                o = s.child;
                for (var u = l.firstContext; u !== null;) {
                  if (u.context === r) {
                    if (s.tag === 1) {
                      ((u = Mt(-1, n & -n)), (u.tag = 2));
                      var c = s.updateQueue;
                      if (c !== null) {
                        c = c.shared;
                        var d = c.pending;
                        (d === null
                          ? (u.next = u)
                          : ((u.next = d.next), (d.next = u)),
                          (c.pending = u));
                      }
                    }
                    ((s.lanes |= n),
                      (u = s.alternate),
                      u !== null && (u.lanes |= n),
                      Qa(s.return, n, t),
                      (l.lanes |= n));
                    break;
                  }
                  u = u.next;
                }
              } else if (s.tag === 10) o = s.type === t.type ? null : s.child;
              else if (s.tag === 18) {
                if (((o = s.return), o === null)) throw Error(C(341));
                ((o.lanes |= n),
                  (l = o.alternate),
                  l !== null && (l.lanes |= n),
                  Qa(o, n, t),
                  (o = s.sibling));
              } else o = s.child;
              if (o !== null) o.return = s;
              else
                for (o = s; o !== null;) {
                  if (o === t) {
                    o = null;
                    break;
                  }
                  if (((s = o.sibling), s !== null)) {
                    ((s.return = o.return), (o = s));
                    break;
                  }
                  o = o.return;
                }
              s = o;
            }
        (be(e, t, i.children, n), (t = t.child));
      }
      return t;
    case 9:
      return (
        (i = t.type),
        (r = t.pendingProps.children),
        sr(t, n),
        (i = nt(i)),
        (r = r(i)),
        (t.flags |= 1),
        be(e, t, r, n),
        t.child
      );
    case 14:
      return (
        (r = t.type),
        (i = lt(r, t.pendingProps)),
        (i = lt(r.type, i)),
        id(e, t, r, i, n)
      );
    case 15:
      return Op(e, t, t.type, t.pendingProps, n);
    case 17:
      return (
        (r = t.type),
        (i = t.pendingProps),
        (i = t.elementType === r ? i : lt(r, i)),
        ds(e, t),
        (t.tag = 1),
        Ie(r) ? ((e = !0), Ls(t)) : (e = !1),
        sr(t, n),
        Ip(t, r, i),
        qa(t, r, i, n),
        tl(null, t, r, !0, e, n)
      );
    case 19:
      return Up(e, t, n);
    case 22:
      return Fp(e, t, n);
  }
  throw Error(C(156, t.tag));
};
function sm(e, t) {
  return Lh(e, t);
}
function Rv(e, t, n, r) {
  ((this.tag = e),
    (this.key = n),
    (this.sibling =
      this.child =
      this.return =
      this.stateNode =
      this.type =
      this.elementType =
        null),
    (this.index = 0),
    (this.ref = null),
    (this.pendingProps = t),
    (this.dependencies =
      this.memoizedState =
      this.updateQueue =
      this.memoizedProps =
        null),
    (this.mode = r),
    (this.subtreeFlags = this.flags = 0),
    (this.deletions = null),
    (this.childLanes = this.lanes = 0),
    (this.alternate = null));
}
function Ze(e, t, n, r) {
  return new Rv(e, t, n, r);
}
function Au(e) {
  return ((e = e.prototype), !(!e || !e.isReactComponent));
}
function Dv(e) {
  if (typeof e == "function") return Au(e) ? 1 : 0;
  if (e != null) {
    if (((e = e.$$typeof), e === Ql)) return 11;
    if (e === Zl) return 14;
  }
  return 2;
}
function nn(e, t) {
  var n = e.alternate;
  return (
    n === null
      ? ((n = Ze(e.tag, t, e.key, e.mode)),
        (n.elementType = e.elementType),
        (n.type = e.type),
        (n.stateNode = e.stateNode),
        (n.alternate = e),
        (e.alternate = n))
      : ((n.pendingProps = t),
        (n.type = e.type),
        (n.flags = 0),
        (n.subtreeFlags = 0),
        (n.deletions = null)),
    (n.flags = e.flags & 14680064),
    (n.childLanes = e.childLanes),
    (n.lanes = e.lanes),
    (n.child = e.child),
    (n.memoizedProps = e.memoizedProps),
    (n.memoizedState = e.memoizedState),
    (n.updateQueue = e.updateQueue),
    (t = e.dependencies),
    (n.dependencies =
      t === null ? null : { lanes: t.lanes, firstContext: t.firstContext }),
    (n.sibling = e.sibling),
    (n.index = e.index),
    (n.ref = e.ref),
    n
  );
}
function ps(e, t, n, r, i, s) {
  var o = 2;
  if (((r = e), typeof e == "function")) Au(e) && (o = 1);
  else if (typeof e == "string") o = 5;
  else
    e: switch (e) {
      case _n:
        return Tn(n.children, i, s, t);
      case Xl:
        ((o = 8), (i |= 8));
        break;
      case ja:
        return (
          (e = Ze(12, n, t, i | 2)),
          (e.elementType = ja),
          (e.lanes = s),
          e
        );
      case Sa:
        return ((e = Ze(13, n, t, i)), (e.elementType = Sa), (e.lanes = s), e);
      case ba:
        return ((e = Ze(19, n, t, i)), (e.elementType = ba), (e.lanes = s), e);
      case mh:
        return vo(n, i, s, t);
      default:
        if (typeof e == "object" && e !== null)
          switch (e.$$typeof) {
            case hh:
              o = 10;
              break e;
            case ph:
              o = 9;
              break e;
            case Ql:
              o = 11;
              break e;
            case Zl:
              o = 14;
              break e;
            case _t:
              ((o = 16), (r = null));
              break e;
          }
        throw Error(C(130, e == null ? e : typeof e, ""));
    }
  return (
    (t = Ze(o, n, t, i)),
    (t.elementType = e),
    (t.type = r),
    (t.lanes = s),
    t
  );
}
function Tn(e, t, n, r) {
  return ((e = Ze(7, e, r, t)), (e.lanes = n), e);
}
function vo(e, t, n, r) {
  return (
    (e = Ze(22, e, r, t)),
    (e.elementType = mh),
    (e.lanes = n),
    (e.stateNode = { isHidden: !1 }),
    e
  );
}
function ta(e, t, n) {
  return ((e = Ze(6, e, null, t)), (e.lanes = n), e);
}
function na(e, t, n) {
  return (
    (t = Ze(4, e.children !== null ? e.children : [], e.key, t)),
    (t.lanes = n),
    (t.stateNode = {
      containerInfo: e.containerInfo,
      pendingChildren: null,
      implementation: e.implementation,
    }),
    t
  );
}
function Iv(e, t, n, r, i) {
  ((this.tag = t),
    (this.containerInfo = e),
    (this.finishedWork =
      this.pingCache =
      this.current =
      this.pendingChildren =
        null),
    (this.timeoutHandle = -1),
    (this.callbackNode = this.pendingContext = this.context = null),
    (this.callbackPriority = 0),
    (this.eventTimes = Vo(0)),
    (this.expirationTimes = Vo(-1)),
    (this.entangledLanes =
      this.finishedLanes =
      this.mutableReadLanes =
      this.expiredLanes =
      this.pingedLanes =
      this.suspendedLanes =
      this.pendingLanes =
        0),
    (this.entanglements = Vo(0)),
    (this.identifierPrefix = r),
    (this.onRecoverableError = i),
    (this.mutableSourceEagerHydrationData = null));
}
function Lu(e, t, n, r, i, s, o, l, u) {
  return (
    (e = new Iv(e, t, n, l, u)),
    t === 1 ? ((t = 1), s === !0 && (t |= 8)) : (t = 0),
    (s = Ze(3, null, null, t)),
    (e.current = s),
    (s.stateNode = e),
    (s.memoizedState = {
      element: r,
      isDehydrated: n,
      cache: null,
      transitions: null,
      pendingSuspenseBoundaries: null,
    }),
    mu(s),
    e
  );
}
function Vv(e, t, n) {
  var r = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
  return {
    $$typeof: zn,
    key: r == null ? null : "" + r,
    children: e,
    containerInfo: t,
    implementation: n,
  };
}
function om(e) {
  if (!e) return on;
  e = e._reactInternals;
  e: {
    if (In(e) !== e || e.tag !== 1) throw Error(C(170));
    var t = e;
    do {
      switch (t.tag) {
        case 3:
          t = t.stateNode.context;
          break e;
        case 1:
          if (Ie(t.type)) {
            t = t.stateNode.__reactInternalMemoizedMergedChildContext;
            break e;
          }
      }
      t = t.return;
    } while (t !== null);
    throw Error(C(171));
  }
  if (e.tag === 1) {
    var n = e.type;
    if (Ie(n)) return op(e, n, t);
  }
  return t;
}
function am(e, t, n, r, i, s, o, l, u) {
  return (
    (e = Lu(n, r, !0, e, i, s, o, l, u)),
    (e.context = om(null)),
    (n = e.current),
    (r = Pe()),
    (i = tn(n)),
    (s = Mt(r, i)),
    (s.callback = t ?? null),
    Jt(n, s, i),
    (e.current.lanes = i),
    Si(e, i, r),
    Ve(e, r),
    e
  );
}
function xo(e, t, n, r) {
  var i = t.current,
    s = Pe(),
    o = tn(i);
  return (
    (n = om(n)),
    t.context === null ? (t.context = n) : (t.pendingContext = n),
    (t = Mt(s, o)),
    (t.payload = { element: e }),
    (r = r === void 0 ? null : r),
    r !== null && (t.callback = r),
    (e = Jt(i, t, o)),
    e !== null && (ft(e, i, o, s), ls(e, i, o)),
    o
  );
}
function $s(e) {
  if (((e = e.current), !e.child)) return null;
  switch (e.child.tag) {
    case 5:
      return e.child.stateNode;
    default:
      return e.child.stateNode;
  }
}
function gd(e, t) {
  if (((e = e.memoizedState), e !== null && e.dehydrated !== null)) {
    var n = e.retryLane;
    e.retryLane = n !== 0 && n < t ? n : t;
  }
}
function Ru(e, t) {
  (gd(e, t), (e = e.alternate) && gd(e, t));
}
function Bv() {
  return null;
}
var lm =
  typeof reportError == "function"
    ? reportError
    : function (e) {
        console.error(e);
      };
function Du(e) {
  this._internalRoot = e;
}
wo.prototype.render = Du.prototype.render = function (e) {
  var t = this._internalRoot;
  if (t === null) throw Error(C(409));
  xo(e, t, null, null);
};
wo.prototype.unmount = Du.prototype.unmount = function () {
  var e = this._internalRoot;
  if (e !== null) {
    this._internalRoot = null;
    var t = e.containerInfo;
    (Rn(function () {
      xo(null, e, null, null);
    }),
      (t[Lt] = null));
  }
};
function wo(e) {
  this._internalRoot = e;
}
wo.prototype.unstable_scheduleHydration = function (e) {
  if (e) {
    var t = Fh();
    e = { blockedOn: null, target: e, priority: t };
    for (var n = 0; n < Ut.length && t !== 0 && t < Ut[n].priority; n++);
    (Ut.splice(n, 0, e), n === 0 && _h(e));
  }
};
function Iu(e) {
  return !(!e || (e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11));
}
function ko(e) {
  return !(
    !e ||
    (e.nodeType !== 1 &&
      e.nodeType !== 9 &&
      e.nodeType !== 11 &&
      (e.nodeType !== 8 || e.nodeValue !== " react-mount-point-unstable "))
  );
}
function yd() {}
function Ov(e, t, n, r, i) {
  if (i) {
    if (typeof r == "function") {
      var s = r;
      r = function () {
        var c = $s(o);
        s.call(c);
      };
    }
    var o = am(t, r, e, 0, null, !1, !1, "", yd);
    return (
      (e._reactRootContainer = o),
      (e[Lt] = o.current),
      ai(e.nodeType === 8 ? e.parentNode : e),
      Rn(),
      o
    );
  }
  for (; (i = e.lastChild);) e.removeChild(i);
  if (typeof r == "function") {
    var l = r;
    r = function () {
      var c = $s(u);
      l.call(c);
    };
  }
  var u = Lu(e, 0, !1, null, null, !1, !1, "", yd);
  return (
    (e._reactRootContainer = u),
    (e[Lt] = u.current),
    ai(e.nodeType === 8 ? e.parentNode : e),
    Rn(function () {
      xo(t, u, n, r);
    }),
    u
  );
}
function jo(e, t, n, r, i) {
  var s = n._reactRootContainer;
  if (s) {
    var o = s;
    if (typeof i == "function") {
      var l = i;
      i = function () {
        var u = $s(o);
        l.call(u);
      };
    }
    xo(t, o, e, i);
  } else o = Ov(n, t, e, i, r);
  return $s(o);
}
Bh = function (e) {
  switch (e.tag) {
    case 3:
      var t = e.stateNode;
      if (t.current.memoizedState.isDehydrated) {
        var n = Vr(t.pendingLanes);
        n !== 0 &&
          (eu(t, n | 1), Ve(t, te()), !(F & 6) && ((hr = te() + 500), dn()));
      }
      break;
    case 13:
      (Rn(function () {
        var r = Rt(e, 1);
        if (r !== null) {
          var i = Pe();
          ft(r, e, 1, i);
        }
      }),
        Ru(e, 1));
  }
};
tu = function (e) {
  if (e.tag === 13) {
    var t = Rt(e, 134217728);
    if (t !== null) {
      var n = Pe();
      ft(t, e, 134217728, n);
    }
    Ru(e, 134217728);
  }
};
Oh = function (e) {
  if (e.tag === 13) {
    var t = tn(e),
      n = Rt(e, t);
    if (n !== null) {
      var r = Pe();
      ft(n, e, t, r);
    }
    Ru(e, t);
  }
};
Fh = function () {
  return z;
};
zh = function (e, t) {
  var n = z;
  try {
    return ((z = e), t());
  } finally {
    z = n;
  }
};
Da = function (e, t, n) {
  switch (t) {
    case "input":
      if ((Pa(e, n), (t = n.name), n.type === "radio" && t != null)) {
        for (n = e; n.parentNode;) n = n.parentNode;
        for (
          n = n.querySelectorAll(
            "input[name=" + JSON.stringify("" + t) + '][type="radio"]',
          ),
            t = 0;
          t < n.length;
          t++
        ) {
          var r = n[t];
          if (r !== e && r.form === e.form) {
            var i = fo(r);
            if (!i) throw Error(C(90));
            (yh(r), Pa(r, i));
          }
        }
      }
      break;
    case "textarea":
      xh(e, n);
      break;
    case "select":
      ((t = n.value), t != null && tr(e, !!n.multiple, t, !1));
  }
};
Th = Nu;
Ph = Rn;
var Fv = { usingClientEntryPoint: !1, Events: [Ci, $n, fo, bh, Ch, Nu] },
  Ar = {
    findFiberByHostInstance: wn,
    bundleType: 0,
    version: "18.3.1",
    rendererPackageName: "react-dom",
  },
  zv = {
    bundleType: Ar.bundleType,
    version: Ar.version,
    rendererPackageName: Ar.rendererPackageName,
    rendererConfig: Ar.rendererConfig,
    overrideHookState: null,
    overrideHookStateDeletePath: null,
    overrideHookStateRenamePath: null,
    overrideProps: null,
    overridePropsDeletePath: null,
    overridePropsRenamePath: null,
    setErrorHandler: null,
    setSuspenseHandler: null,
    scheduleUpdate: null,
    currentDispatcherRef: It.ReactCurrentDispatcher,
    findHostInstanceByFiber: function (e) {
      return ((e = Mh(e)), e === null ? null : e.stateNode);
    },
    findFiberByHostInstance: Ar.findFiberByHostInstance || Bv,
    findHostInstancesForRefresh: null,
    scheduleRefresh: null,
    scheduleRoot: null,
    setRefreshHandler: null,
    getCurrentFiber: null,
    reconcilerVersion: "18.3.1-next-f1338f8080-20240426",
  };
if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
  var Zi = __REACT_DEVTOOLS_GLOBAL_HOOK__;
  if (!Zi.isDisabled && Zi.supportsFiber)
    try {
      ((ao = Zi.inject(zv)), (kt = Zi));
    } catch {}
}
$e.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = Fv;
$e.createPortal = function (e, t) {
  var n = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
  if (!Iu(t)) throw Error(C(200));
  return Vv(e, t, null, n);
};
$e.createRoot = function (e, t) {
  if (!Iu(e)) throw Error(C(299));
  var n = !1,
    r = "",
    i = lm;
  return (
    t != null &&
      (t.unstable_strictMode === !0 && (n = !0),
      t.identifierPrefix !== void 0 && (r = t.identifierPrefix),
      t.onRecoverableError !== void 0 && (i = t.onRecoverableError)),
    (t = Lu(e, 1, !1, null, null, n, !1, r, i)),
    (e[Lt] = t.current),
    ai(e.nodeType === 8 ? e.parentNode : e),
    new Du(t)
  );
};
$e.findDOMNode = function (e) {
  if (e == null) return null;
  if (e.nodeType === 1) return e;
  var t = e._reactInternals;
  if (t === void 0)
    throw typeof e.render == "function"
      ? Error(C(188))
      : ((e = Object.keys(e).join(",")), Error(C(268, e)));
  return ((e = Mh(t)), (e = e === null ? null : e.stateNode), e);
};
$e.flushSync = function (e) {
  return Rn(e);
};
$e.hydrate = function (e, t, n) {
  if (!ko(t)) throw Error(C(200));
  return jo(null, e, t, !0, n);
};
$e.hydrateRoot = function (e, t, n) {
  if (!Iu(e)) throw Error(C(405));
  var r = (n != null && n.hydratedSources) || null,
    i = !1,
    s = "",
    o = lm;
  if (
    (n != null &&
      (n.unstable_strictMode === !0 && (i = !0),
      n.identifierPrefix !== void 0 && (s = n.identifierPrefix),
      n.onRecoverableError !== void 0 && (o = n.onRecoverableError)),
    (t = am(t, null, e, 1, n ?? null, i, !1, s, o)),
    (e[Lt] = t.current),
    ai(e),
    r)
  )
    for (e = 0; e < r.length; e++)
      ((n = r[e]),
        (i = n._getVersion),
        (i = i(n._source)),
        t.mutableSourceEagerHydrationData == null
          ? (t.mutableSourceEagerHydrationData = [n, i])
          : t.mutableSourceEagerHydrationData.push(n, i));
  return new wo(t);
};
$e.render = function (e, t, n) {
  if (!ko(t)) throw Error(C(200));
  return jo(null, e, t, !1, n);
};
$e.unmountComponentAtNode = function (e) {
  if (!ko(e)) throw Error(C(40));
  return e._reactRootContainer
    ? (Rn(function () {
        jo(null, null, e, !1, function () {
          ((e._reactRootContainer = null), (e[Lt] = null));
        });
      }),
      !0)
    : !1;
};
$e.unstable_batchedUpdates = Nu;
$e.unstable_renderSubtreeIntoContainer = function (e, t, n, r) {
  if (!ko(n)) throw Error(C(200));
  if (e == null || e._reactInternals === void 0) throw Error(C(38));
  return jo(e, t, n, !1, r);
};
$e.version = "18.3.1-next-f1338f8080-20240426";
function um() {
  if (!(
    typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" ||
    typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function"
  ))
    try {
      __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(um);
    } catch (e) {
      console.error(e);
    }
}
(um(), (uh.exports = $e));
var _v = uh.exports,
  vd = _v;
((wa.createRoot = vd.createRoot), (wa.hydrateRoot = vd.hydrateRoot));
/**
 * @remix-run/router v1.23.2
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */ function gi() {
  return (
    (gi = Object.assign
      ? Object.assign.bind()
      : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n)
              Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
          }
          return e;
        }),
    gi.apply(this, arguments)
  );
}
var Gt;
(function (e) {
  ((e.Pop = "POP"), (e.Push = "PUSH"), (e.Replace = "REPLACE"));
})(Gt || (Gt = {}));
const xd = "popstate";
function Wv(e) {
  e === void 0 && (e = {});
  function t(r, i) {
    let { pathname: s, search: o, hash: l } = r.location;
    return hl(
      "",
      { pathname: s, search: o, hash: l },
      (i.state && i.state.usr) || null,
      (i.state && i.state.key) || "default",
    );
  }
  function n(r, i) {
    return typeof i == "string" ? i : Ks(i);
  }
  return Hv(t, n, null, e);
}
function ee(e, t) {
  if (e === !1 || e === null || typeof e > "u") throw new Error(t);
}
function Vu(e, t) {
  if (!e) {
    typeof console < "u" && console.warn(t);
    try {
      throw new Error(t);
    } catch {}
  }
}
function Uv() {
  return Math.random().toString(36).substr(2, 8);
}
function wd(e, t) {
  return { usr: e.state, key: e.key, idx: t };
}
function hl(e, t, n, r) {
  return (
    n === void 0 && (n = null),
    gi(
      { pathname: typeof e == "string" ? e : e.pathname, search: "", hash: "" },
      typeof t == "string" ? wr(t) : t,
      { state: n, key: (t && t.key) || r || Uv() },
    )
  );
}
function Ks(e) {
  let { pathname: t = "/", search: n = "", hash: r = "" } = e;
  return (
    n && n !== "?" && (t += n.charAt(0) === "?" ? n : "?" + n),
    r && r !== "#" && (t += r.charAt(0) === "#" ? r : "#" + r),
    t
  );
}
function wr(e) {
  let t = {};
  if (e) {
    let n = e.indexOf("#");
    n >= 0 && ((t.hash = e.substr(n)), (e = e.substr(0, n)));
    let r = e.indexOf("?");
    (r >= 0 && ((t.search = e.substr(r)), (e = e.substr(0, r))),
      e && (t.pathname = e));
  }
  return t;
}
function Hv(e, t, n, r) {
  r === void 0 && (r = {});
  let { window: i = document.defaultView, v5Compat: s = !1 } = r,
    o = i.history,
    l = Gt.Pop,
    u = null,
    c = d();
  c == null && ((c = 0), o.replaceState(gi({}, o.state, { idx: c }), ""));
  function d() {
    return (o.state || { idx: null }).idx;
  }
  function f() {
    l = Gt.Pop;
    let k = d(),
      g = k == null ? null : k - c;
    ((c = k), u && u({ action: l, location: x.location, delta: g }));
  }
  function h(k, g) {
    l = Gt.Push;
    let p = hl(x.location, k, g);
    c = d() + 1;
    let y = wd(p, c),
      w = x.createHref(p);
    try {
      o.pushState(y, "", w);
    } catch (S) {
      if (S instanceof DOMException && S.name === "DataCloneError") throw S;
      i.location.assign(w);
    }
    s && u && u({ action: l, location: x.location, delta: 1 });
  }
  function m(k, g) {
    l = Gt.Replace;
    let p = hl(x.location, k, g);
    c = d();
    let y = wd(p, c),
      w = x.createHref(p);
    (o.replaceState(y, "", w),
      s && u && u({ action: l, location: x.location, delta: 0 }));
  }
  function v(k) {
    let g = i.location.origin !== "null" ? i.location.origin : i.location.href,
      p = typeof k == "string" ? k : Ks(k);
    return (
      (p = p.replace(/ $/, "%20")),
      ee(
        g,
        "No window.location.(origin|href) available to create URL for href: " +
          p,
      ),
      new URL(p, g)
    );
  }
  let x = {
    get action() {
      return l;
    },
    get location() {
      return e(i, o);
    },
    listen(k) {
      if (u) throw new Error("A history only accepts one active listener");
      return (
        i.addEventListener(xd, f),
        (u = k),
        () => {
          (i.removeEventListener(xd, f), (u = null));
        }
      );
    },
    createHref(k) {
      return t(i, k);
    },
    createURL: v,
    encodeLocation(k) {
      let g = v(k);
      return { pathname: g.pathname, search: g.search, hash: g.hash };
    },
    push: h,
    replace: m,
    go(k) {
      return o.go(k);
    },
  };
  return x;
}
var kd;
(function (e) {
  ((e.data = "data"),
    (e.deferred = "deferred"),
    (e.redirect = "redirect"),
    (e.error = "error"));
})(kd || (kd = {}));
function $v(e, t, n) {
  return (n === void 0 && (n = "/"), Kv(e, t, n));
}
function Kv(e, t, n, r) {
  let i = typeof t == "string" ? wr(t) : t,
    s = pr(i.pathname || "/", n);
  if (s == null) return null;
  let o = cm(e);
  Gv(o);
  let l = null;
  for (let u = 0; l == null && u < o.length; ++u) {
    let c = i1(s);
    l = n1(o[u], c);
  }
  return l;
}
function cm(e, t, n, r) {
  (t === void 0 && (t = []),
    n === void 0 && (n = []),
    r === void 0 && (r = ""));
  let i = (s, o, l) => {
    let u = {
      relativePath: l === void 0 ? s.path || "" : l,
      caseSensitive: s.caseSensitive === !0,
      childrenIndex: o,
      route: s,
    };
    u.relativePath.startsWith("/") &&
      (ee(
        u.relativePath.startsWith(r),
        'Absolute route path "' +
          u.relativePath +
          '" nested under path ' +
          ('"' + r + '" is not valid. An absolute child route path ') +
          "must start with the combined path of all its parent routes.",
      ),
      (u.relativePath = u.relativePath.slice(r.length)));
    let c = rn([r, u.relativePath]),
      d = n.concat(u);
    (s.children &&
      s.children.length > 0 &&
      (ee(
        s.index !== !0,
        "Index routes must not have child routes. Please remove " +
          ('all child routes from route path "' + c + '".'),
      ),
      cm(s.children, t, d, c)),
      !(s.path == null && !s.index) &&
        t.push({ path: c, score: e1(c, s.index), routesMeta: d }));
  };
  return (
    e.forEach((s, o) => {
      var l;
      if (s.path === "" || !((l = s.path) != null && l.includes("?"))) i(s, o);
      else for (let u of dm(s.path)) i(s, o, u);
    }),
    t
  );
}
function dm(e) {
  let t = e.split("/");
  if (t.length === 0) return [];
  let [n, ...r] = t,
    i = n.endsWith("?"),
    s = n.replace(/\?$/, "");
  if (r.length === 0) return i ? [s, ""] : [s];
  let o = dm(r.join("/")),
    l = [];
  return (
    l.push(...o.map((u) => (u === "" ? s : [s, u].join("/")))),
    i && l.push(...o),
    l.map((u) => (e.startsWith("/") && u === "" ? "/" : u))
  );
}
function Gv(e) {
  e.sort((t, n) =>
    t.score !== n.score
      ? n.score - t.score
      : t1(
          t.routesMeta.map((r) => r.childrenIndex),
          n.routesMeta.map((r) => r.childrenIndex),
        ),
  );
}
const Yv = /^:[\w-]+$/,
  Xv = 3,
  Qv = 2,
  Zv = 1,
  qv = 10,
  Jv = -2,
  jd = (e) => e === "*";
function e1(e, t) {
  let n = e.split("/"),
    r = n.length;
  return (
    n.some(jd) && (r += Jv),
    t && (r += Qv),
    n
      .filter((i) => !jd(i))
      .reduce((i, s) => i + (Yv.test(s) ? Xv : s === "" ? Zv : qv), r)
  );
}
function t1(e, t) {
  return e.length === t.length && e.slice(0, -1).every((r, i) => r === t[i])
    ? e[e.length - 1] - t[t.length - 1]
    : 0;
}
function n1(e, t, n) {
  let { routesMeta: r } = e,
    i = {},
    s = "/",
    o = [];
  for (let l = 0; l < r.length; ++l) {
    let u = r[l],
      c = l === r.length - 1,
      d = s === "/" ? t : t.slice(s.length) || "/",
      f = pl(
        { path: u.relativePath, caseSensitive: u.caseSensitive, end: c },
        d,
      ),
      h = u.route;
    if (!f) return null;
    (Object.assign(i, f.params),
      o.push({
        params: i,
        pathname: rn([s, f.pathname]),
        pathnameBase: u1(rn([s, f.pathnameBase])),
        route: h,
      }),
      f.pathnameBase !== "/" && (s = rn([s, f.pathnameBase])));
  }
  return o;
}
function pl(e, t) {
  typeof e == "string" && (e = { path: e, caseSensitive: !1, end: !0 });
  let [n, r] = r1(e.path, e.caseSensitive, e.end),
    i = t.match(n);
  if (!i) return null;
  let s = i[0],
    o = s.replace(/(.)\/+$/, "$1"),
    l = i.slice(1);
  return {
    params: r.reduce((c, d, f) => {
      let { paramName: h, isOptional: m } = d;
      if (h === "*") {
        let x = l[f] || "";
        o = s.slice(0, s.length - x.length).replace(/(.)\/+$/, "$1");
      }
      const v = l[f];
      return (
        m && !v ? (c[h] = void 0) : (c[h] = (v || "").replace(/%2F/g, "/")),
        c
      );
    }, {}),
    pathname: s,
    pathnameBase: o,
    pattern: e,
  };
}
function r1(e, t, n) {
  (t === void 0 && (t = !1),
    n === void 0 && (n = !0),
    Vu(
      e === "*" || !e.endsWith("*") || e.endsWith("/*"),
      'Route path "' +
        e +
        '" will be treated as if it were ' +
        ('"' + e.replace(/\*$/, "/*") + '" because the `*` character must ') +
        "always follow a `/` in the pattern. To get rid of this warning, " +
        ('please change the route path to "' + e.replace(/\*$/, "/*") + '".'),
    ));
  let r = [],
    i =
      "^" +
      e
        .replace(/\/*\*?$/, "")
        .replace(/^\/*/, "/")
        .replace(/[\\.*+^${}|()[\]]/g, "\\$&")
        .replace(
          /\/:([\w-]+)(\?)?/g,
          (o, l, u) => (
            r.push({ paramName: l, isOptional: u != null }),
            u ? "/?([^\\/]+)?" : "/([^\\/]+)"
          ),
        );
  return (
    e.endsWith("*")
      ? (r.push({ paramName: "*" }),
        (i += e === "*" || e === "/*" ? "(.*)$" : "(?:\\/(.+)|\\/*)$"))
      : n
        ? (i += "\\/*$")
        : e !== "" && e !== "/" && (i += "(?:(?=\\/|$))"),
    [new RegExp(i, t ? void 0 : "i"), r]
  );
}
function i1(e) {
  try {
    return e
      .split("/")
      .map((t) => decodeURIComponent(t).replace(/\//g, "%2F"))
      .join("/");
  } catch (t) {
    return (
      Vu(
        !1,
        'The URL path "' +
          e +
          '" could not be decoded because it is is a malformed URL segment. This is probably due to a bad percent ' +
          ("encoding (" + t + ")."),
      ),
      e
    );
  }
}
function pr(e, t) {
  if (t === "/") return e;
  if (!e.toLowerCase().startsWith(t.toLowerCase())) return null;
  let n = t.endsWith("/") ? t.length - 1 : t.length,
    r = e.charAt(n);
  return r && r !== "/" ? null : e.slice(n) || "/";
}
const s1 = /^(?:[a-z][a-z0-9+.-]*:|\/\/)/i,
  o1 = (e) => s1.test(e);
function a1(e, t) {
  t === void 0 && (t = "/");
  let {
      pathname: n,
      search: r = "",
      hash: i = "",
    } = typeof e == "string" ? wr(e) : e,
    s;
  if (n)
    if (o1(n)) s = n;
    else {
      if (n.includes("//")) {
        let o = n;
        ((n = n.replace(/\/\/+/g, "/")),
          Vu(
            !1,
            "Pathnames cannot have embedded double slashes - normalizing " +
              (o + " -> " + n),
          ));
      }
      n.startsWith("/") ? (s = Sd(n.substring(1), "/")) : (s = Sd(n, t));
    }
  else s = t;
  return { pathname: s, search: c1(r), hash: d1(i) };
}
function Sd(e, t) {
  let n = t.replace(/\/+$/, "").split("/");
  return (
    e.split("/").forEach((i) => {
      i === ".." ? n.length > 1 && n.pop() : i !== "." && n.push(i);
    }),
    n.length > 1 ? n.join("/") : "/"
  );
}
function ra(e, t, n, r) {
  return (
    "Cannot include a '" +
    e +
    "' character in a manually specified " +
    ("`to." +
      t +
      "` field [" +
      JSON.stringify(r) +
      "].  Please separate it out to the ") +
    ("`to." + n + "` field. Alternatively you may provide the full path as ") +
    'a string in <Link to="..."> and the router will parse it for you.'
  );
}
function l1(e) {
  return e.filter(
    (t, n) => n === 0 || (t.route.path && t.route.path.length > 0),
  );
}
function fm(e, t) {
  let n = l1(e);
  return t
    ? n.map((r, i) => (i === n.length - 1 ? r.pathname : r.pathnameBase))
    : n.map((r) => r.pathnameBase);
}
function hm(e, t, n, r) {
  r === void 0 && (r = !1);
  let i;
  typeof e == "string"
    ? (i = wr(e))
    : ((i = gi({}, e)),
      ee(
        !i.pathname || !i.pathname.includes("?"),
        ra("?", "pathname", "search", i),
      ),
      ee(
        !i.pathname || !i.pathname.includes("#"),
        ra("#", "pathname", "hash", i),
      ),
      ee(!i.search || !i.search.includes("#"), ra("#", "search", "hash", i)));
  let s = e === "" || i.pathname === "",
    o = s ? "/" : i.pathname,
    l;
  if (o == null) l = n;
  else {
    let f = t.length - 1;
    if (!r && o.startsWith("..")) {
      let h = o.split("/");
      for (; h[0] === "..";) (h.shift(), (f -= 1));
      i.pathname = h.join("/");
    }
    l = f >= 0 ? t[f] : "/";
  }
  let u = a1(i, l),
    c = o && o !== "/" && o.endsWith("/"),
    d = (s || o === ".") && n.endsWith("/");
  return (!u.pathname.endsWith("/") && (c || d) && (u.pathname += "/"), u);
}
const rn = (e) => e.join("/").replace(/\/\/+/g, "/"),
  u1 = (e) => e.replace(/\/+$/, "").replace(/^\/*/, "/"),
  c1 = (e) => (!e || e === "?" ? "" : e.startsWith("?") ? e : "?" + e),
  d1 = (e) => (!e || e === "#" ? "" : e.startsWith("#") ? e : "#" + e);
function f1(e) {
  return (
    e != null &&
    typeof e.status == "number" &&
    typeof e.statusText == "string" &&
    typeof e.internal == "boolean" &&
    "data" in e
  );
}
const pm = ["post", "put", "patch", "delete"];
new Set(pm);
const h1 = ["get", ...pm];
new Set(h1);
/**
 * React Router v6.30.3
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */ function yi() {
  return (
    (yi = Object.assign
      ? Object.assign.bind()
      : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n)
              Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
          }
          return e;
        }),
    yi.apply(this, arguments)
  );
}
const So = j.createContext(null),
  mm = j.createContext(null),
  fn = j.createContext(null),
  bo = j.createContext(null),
  Vn = j.createContext({ outlet: null, matches: [], isDataRoute: !1 }),
  gm = j.createContext(null);
function p1(e, t) {
  let { relative: n } = t === void 0 ? {} : t;
  Pi() || ee(!1);
  let { basename: r, navigator: i } = j.useContext(fn),
    { hash: s, pathname: o, search: l } = Co(e, { relative: n }),
    u = o;
  return (
    r !== "/" && (u = o === "/" ? r : rn([r, o])),
    i.createHref({ pathname: u, search: l, hash: s })
  );
}
function Pi() {
  return j.useContext(bo) != null;
}
function Bn() {
  return (Pi() || ee(!1), j.useContext(bo).location);
}
function ym(e) {
  j.useContext(fn).static || j.useLayoutEffect(e);
}
function vm() {
  let { isDataRoute: e } = j.useContext(Vn);
  return e ? P1() : m1();
}
function m1() {
  Pi() || ee(!1);
  let e = j.useContext(So),
    { basename: t, future: n, navigator: r } = j.useContext(fn),
    { matches: i } = j.useContext(Vn),
    { pathname: s } = Bn(),
    o = JSON.stringify(fm(i, n.v7_relativeSplatPath)),
    l = j.useRef(!1);
  return (
    ym(() => {
      l.current = !0;
    }),
    j.useCallback(
      function (c, d) {
        if ((d === void 0 && (d = {}), !l.current)) return;
        if (typeof c == "number") {
          r.go(c);
          return;
        }
        let f = hm(c, JSON.parse(o), s, d.relative === "path");
        (e == null &&
          t !== "/" &&
          (f.pathname = f.pathname === "/" ? t : rn([t, f.pathname])),
          (d.replace ? r.replace : r.push)(f, d.state, d));
      },
      [t, r, o, s, e],
    )
  );
}
function Co(e, t) {
  let { relative: n } = t === void 0 ? {} : t,
    { future: r } = j.useContext(fn),
    { matches: i } = j.useContext(Vn),
    { pathname: s } = Bn(),
    o = JSON.stringify(fm(i, r.v7_relativeSplatPath));
  return j.useMemo(() => hm(e, JSON.parse(o), s, n === "path"), [e, o, s, n]);
}
function g1(e, t) {
  return y1(e, t);
}
function y1(e, t, n, r) {
  Pi() || ee(!1);
  let { navigator: i } = j.useContext(fn),
    { matches: s } = j.useContext(Vn),
    o = s[s.length - 1],
    l = o ? o.params : {};
  o && o.pathname;
  let u = o ? o.pathnameBase : "/";
  o && o.route;
  let c = Bn(),
    d;
  if (t) {
    var f;
    let k = typeof t == "string" ? wr(t) : t;
    (u === "/" || ((f = k.pathname) != null && f.startsWith(u)) || ee(!1),
      (d = k));
  } else d = c;
  let h = d.pathname || "/",
    m = h;
  if (u !== "/") {
    let k = u.replace(/^\//, "").split("/");
    m = "/" + h.replace(/^\//, "").split("/").slice(k.length).join("/");
  }
  let v = $v(e, { pathname: m }),
    x = j1(
      v &&
        v.map((k) =>
          Object.assign({}, k, {
            params: Object.assign({}, l, k.params),
            pathname: rn([
              u,
              i.encodeLocation
                ? i.encodeLocation(k.pathname).pathname
                : k.pathname,
            ]),
            pathnameBase:
              k.pathnameBase === "/"
                ? u
                : rn([
                    u,
                    i.encodeLocation
                      ? i.encodeLocation(k.pathnameBase).pathname
                      : k.pathnameBase,
                  ]),
          }),
        ),
      s,
      n,
      r,
    );
  return t && x
    ? j.createElement(
        bo.Provider,
        {
          value: {
            location: yi(
              {
                pathname: "/",
                search: "",
                hash: "",
                state: null,
                key: "default",
              },
              d,
            ),
            navigationType: Gt.Pop,
          },
        },
        x,
      )
    : x;
}
function v1() {
  let e = T1(),
    t = f1(e)
      ? e.status + " " + e.statusText
      : e instanceof Error
        ? e.message
        : JSON.stringify(e),
    n = e instanceof Error ? e.stack : null,
    i = { padding: "0.5rem", backgroundColor: "rgba(200,200,200, 0.5)" };
  return j.createElement(
    j.Fragment,
    null,
    j.createElement("h2", null, "Unexpected Application Error!"),
    j.createElement("h3", { style: { fontStyle: "italic" } }, t),
    n ? j.createElement("pre", { style: i }, n) : null,
    null,
  );
}
const x1 = j.createElement(v1, null);
class w1 extends j.Component {
  constructor(t) {
    (super(t),
      (this.state = {
        location: t.location,
        revalidation: t.revalidation,
        error: t.error,
      }));
  }
  static getDerivedStateFromError(t) {
    return { error: t };
  }
  static getDerivedStateFromProps(t, n) {
    return n.location !== t.location ||
      (n.revalidation !== "idle" && t.revalidation === "idle")
      ? { error: t.error, location: t.location, revalidation: t.revalidation }
      : {
          error: t.error !== void 0 ? t.error : n.error,
          location: n.location,
          revalidation: t.revalidation || n.revalidation,
        };
  }
  componentDidCatch(t, n) {
    console.error(
      "React Router caught the following error during render",
      t,
      n,
    );
  }
  render() {
    return this.state.error !== void 0
      ? j.createElement(
          Vn.Provider,
          { value: this.props.routeContext },
          j.createElement(gm.Provider, {
            value: this.state.error,
            children: this.props.component,
          }),
        )
      : this.props.children;
  }
}
function k1(e) {
  let { routeContext: t, match: n, children: r } = e,
    i = j.useContext(So);
  return (
    i &&
      i.static &&
      i.staticContext &&
      (n.route.errorElement || n.route.ErrorBoundary) &&
      (i.staticContext._deepestRenderedBoundaryId = n.route.id),
    j.createElement(Vn.Provider, { value: t }, r)
  );
}
function j1(e, t, n, r) {
  var i;
  if (
    (t === void 0 && (t = []),
    n === void 0 && (n = null),
    r === void 0 && (r = null),
    e == null)
  ) {
    var s;
    if (!n) return null;
    if (n.errors) e = n.matches;
    else if (
      (s = r) != null &&
      s.v7_partialHydration &&
      t.length === 0 &&
      !n.initialized &&
      n.matches.length > 0
    )
      e = n.matches;
    else return null;
  }
  let o = e,
    l = (i = n) == null ? void 0 : i.errors;
  if (l != null) {
    let d = o.findIndex(
      (f) => f.route.id && (l == null ? void 0 : l[f.route.id]) !== void 0,
    );
    (d >= 0 || ee(!1), (o = o.slice(0, Math.min(o.length, d + 1))));
  }
  let u = !1,
    c = -1;
  if (n && r && r.v7_partialHydration)
    for (let d = 0; d < o.length; d++) {
      let f = o[d];
      if (
        ((f.route.HydrateFallback || f.route.hydrateFallbackElement) && (c = d),
        f.route.id)
      ) {
        let { loaderData: h, errors: m } = n,
          v =
            f.route.loader &&
            h[f.route.id] === void 0 &&
            (!m || m[f.route.id] === void 0);
        if (f.route.lazy || v) {
          ((u = !0), c >= 0 ? (o = o.slice(0, c + 1)) : (o = [o[0]]));
          break;
        }
      }
    }
  return o.reduceRight((d, f, h) => {
    let m,
      v = !1,
      x = null,
      k = null;
    n &&
      ((m = l && f.route.id ? l[f.route.id] : void 0),
      (x = f.route.errorElement || x1),
      u &&
        (c < 0 && h === 0
          ? (N1("route-fallback"), (v = !0), (k = null))
          : c === h &&
            ((v = !0), (k = f.route.hydrateFallbackElement || null))));
    let g = t.concat(o.slice(0, h + 1)),
      p = () => {
        let y;
        return (
          m
            ? (y = x)
            : v
              ? (y = k)
              : f.route.Component
                ? (y = j.createElement(f.route.Component, null))
                : f.route.element
                  ? (y = f.route.element)
                  : (y = d),
          j.createElement(k1, {
            match: f,
            routeContext: { outlet: d, matches: g, isDataRoute: n != null },
            children: y,
          })
        );
      };
    return n && (f.route.ErrorBoundary || f.route.errorElement || h === 0)
      ? j.createElement(w1, {
          location: n.location,
          revalidation: n.revalidation,
          component: x,
          error: m,
          children: p(),
          routeContext: { outlet: null, matches: g, isDataRoute: !0 },
        })
      : p();
  }, null);
}
var xm = (function (e) {
    return (
      (e.UseBlocker = "useBlocker"),
      (e.UseRevalidator = "useRevalidator"),
      (e.UseNavigateStable = "useNavigate"),
      e
    );
  })(xm || {}),
  wm = (function (e) {
    return (
      (e.UseBlocker = "useBlocker"),
      (e.UseLoaderData = "useLoaderData"),
      (e.UseActionData = "useActionData"),
      (e.UseRouteError = "useRouteError"),
      (e.UseNavigation = "useNavigation"),
      (e.UseRouteLoaderData = "useRouteLoaderData"),
      (e.UseMatches = "useMatches"),
      (e.UseRevalidator = "useRevalidator"),
      (e.UseNavigateStable = "useNavigate"),
      (e.UseRouteId = "useRouteId"),
      e
    );
  })(wm || {});
function S1(e) {
  let t = j.useContext(So);
  return (t || ee(!1), t);
}
function b1(e) {
  let t = j.useContext(mm);
  return (t || ee(!1), t);
}
function C1(e) {
  let t = j.useContext(Vn);
  return (t || ee(!1), t);
}
function km(e) {
  let t = C1(),
    n = t.matches[t.matches.length - 1];
  return (n.route.id || ee(!1), n.route.id);
}
function T1() {
  var e;
  let t = j.useContext(gm),
    n = b1(),
    r = km();
  return t !== void 0 ? t : (e = n.errors) == null ? void 0 : e[r];
}
function P1() {
  let { router: e } = S1(xm.UseNavigateStable),
    t = km(wm.UseNavigateStable),
    n = j.useRef(!1);
  return (
    ym(() => {
      n.current = !0;
    }),
    j.useCallback(
      function (i, s) {
        (s === void 0 && (s = {}),
          n.current &&
            (typeof i == "number"
              ? e.navigate(i)
              : e.navigate(i, yi({ fromRouteId: t }, s))));
      },
      [e, t],
    )
  );
}
const bd = {};
function N1(e, t, n) {
  bd[e] || (bd[e] = !0);
}
function E1(e, t) {
  (e == null || e.v7_startTransition, e == null || e.v7_relativeSplatPath);
}
function Ot(e) {
  ee(!1);
}
function M1(e) {
  let {
    basename: t = "/",
    children: n = null,
    location: r,
    navigationType: i = Gt.Pop,
    navigator: s,
    static: o = !1,
    future: l,
  } = e;
  Pi() && ee(!1);
  let u = t.replace(/^\/*/, "/"),
    c = j.useMemo(
      () => ({
        basename: u,
        navigator: s,
        static: o,
        future: yi({ v7_relativeSplatPath: !1 }, l),
      }),
      [u, l, s, o],
    );
  typeof r == "string" && (r = wr(r));
  let {
      pathname: d = "/",
      search: f = "",
      hash: h = "",
      state: m = null,
      key: v = "default",
    } = r,
    x = j.useMemo(() => {
      let k = pr(d, u);
      return k == null
        ? null
        : {
            location: { pathname: k, search: f, hash: h, state: m, key: v },
            navigationType: i,
          };
    }, [u, d, f, h, m, v, i]);
  return x == null
    ? null
    : j.createElement(
        fn.Provider,
        { value: c },
        j.createElement(bo.Provider, { children: n, value: x }),
      );
}
function A1(e) {
  let { children: t, location: n } = e;
  return g1(ml(t), n);
}
new Promise(() => {});
function ml(e, t) {
  t === void 0 && (t = []);
  let n = [];
  return (
    j.Children.forEach(e, (r, i) => {
      if (!j.isValidElement(r)) return;
      let s = [...t, i];
      if (r.type === j.Fragment) {
        n.push.apply(n, ml(r.props.children, s));
        return;
      }
      (r.type !== Ot && ee(!1), !r.props.index || !r.props.children || ee(!1));
      let o = {
        id: r.props.id || s.join("-"),
        caseSensitive: r.props.caseSensitive,
        element: r.props.element,
        Component: r.props.Component,
        index: r.props.index,
        path: r.props.path,
        loader: r.props.loader,
        action: r.props.action,
        errorElement: r.props.errorElement,
        ErrorBoundary: r.props.ErrorBoundary,
        hasErrorBoundary:
          r.props.ErrorBoundary != null || r.props.errorElement != null,
        shouldRevalidate: r.props.shouldRevalidate,
        handle: r.props.handle,
        lazy: r.props.lazy,
      };
      (r.props.children && (o.children = ml(r.props.children, s)), n.push(o));
    }),
    n
  );
}
/**
 * React Router DOM v6.30.3
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */ function Gs() {
  return (
    (Gs = Object.assign
      ? Object.assign.bind()
      : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n)
              Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
          }
          return e;
        }),
    Gs.apply(this, arguments)
  );
}
function jm(e, t) {
  if (e == null) return {};
  var n = {},
    r = Object.keys(e),
    i,
    s;
  for (s = 0; s < r.length; s++)
    ((i = r[s]), !(t.indexOf(i) >= 0) && (n[i] = e[i]));
  return n;
}
function L1(e) {
  return !!(e.metaKey || e.altKey || e.ctrlKey || e.shiftKey);
}
function R1(e, t) {
  return e.button === 0 && (!t || t === "_self") && !L1(e);
}
const D1 = [
    "onClick",
    "relative",
    "reloadDocument",
    "replace",
    "state",
    "target",
    "to",
    "preventScrollReset",
    "viewTransition",
  ],
  I1 = [
    "aria-current",
    "caseSensitive",
    "className",
    "end",
    "style",
    "to",
    "viewTransition",
    "children",
  ],
  V1 = "6";
try {
  window.__reactRouterVersion = V1;
} catch {}
const B1 = j.createContext({ isTransitioning: !1 }),
  O1 = "startTransition",
  Cd = My[O1];
function F1(e) {
  let { basename: t, children: n, future: r, window: i } = e,
    s = j.useRef();
  s.current == null && (s.current = Wv({ window: i, v5Compat: !0 }));
  let o = s.current,
    [l, u] = j.useState({ action: o.action, location: o.location }),
    { v7_startTransition: c } = r || {},
    d = j.useCallback(
      (f) => {
        c && Cd ? Cd(() => u(f)) : u(f);
      },
      [u, c],
    );
  return (
    j.useLayoutEffect(() => o.listen(d), [o, d]),
    j.useEffect(() => E1(r), [r]),
    j.createElement(M1, {
      basename: t,
      children: n,
      location: l.location,
      navigationType: l.action,
      navigator: o,
      future: r,
    })
  );
}
const z1 =
    typeof window < "u" &&
    typeof window.document < "u" &&
    typeof window.document.createElement < "u",
  _1 = /^(?:[a-z][a-z0-9+.-]*:|\/\/)/i,
  ye = j.forwardRef(function (t, n) {
    let {
        onClick: r,
        relative: i,
        reloadDocument: s,
        replace: o,
        state: l,
        target: u,
        to: c,
        preventScrollReset: d,
        viewTransition: f,
      } = t,
      h = jm(t, D1),
      { basename: m } = j.useContext(fn),
      v,
      x = !1;
    if (typeof c == "string" && _1.test(c) && ((v = c), z1))
      try {
        let y = new URL(window.location.href),
          w = c.startsWith("//") ? new URL(y.protocol + c) : new URL(c),
          S = pr(w.pathname, m);
        w.origin === y.origin && S != null
          ? (c = S + w.search + w.hash)
          : (x = !0);
      } catch {}
    let k = p1(c, { relative: i }),
      g = H1(c, {
        replace: o,
        state: l,
        target: u,
        preventScrollReset: d,
        relative: i,
        viewTransition: f,
      });
    function p(y) {
      (r && r(y), y.defaultPrevented || g(y));
    }
    return j.createElement(
      "a",
      Gs({}, h, { href: v || k, onClick: x || s ? r : p, ref: n, target: u }),
    );
  }),
  W1 = j.forwardRef(function (t, n) {
    let {
        "aria-current": r = "page",
        caseSensitive: i = !1,
        className: s = "",
        end: o = !1,
        style: l,
        to: u,
        viewTransition: c,
        children: d,
      } = t,
      f = jm(t, I1),
      h = Co(u, { relative: f.relative }),
      m = Bn(),
      v = j.useContext(mm),
      { navigator: x, basename: k } = j.useContext(fn),
      g = v != null && $1(h) && c === !0,
      p = x.encodeLocation ? x.encodeLocation(h).pathname : h.pathname,
      y = m.pathname,
      w =
        v && v.navigation && v.navigation.location
          ? v.navigation.location.pathname
          : null;
    (i ||
      ((y = y.toLowerCase()),
      (w = w ? w.toLowerCase() : null),
      (p = p.toLowerCase())),
      w && k && (w = pr(w, k) || w));
    const S = p !== "/" && p.endsWith("/") ? p.length - 1 : p.length;
    let b = y === p || (!o && y.startsWith(p) && y.charAt(S) === "/"),
      P =
        w != null &&
        (w === p || (!o && w.startsWith(p) && w.charAt(p.length) === "/")),
      T = { isActive: b, isPending: P, isTransitioning: g },
      V = b ? r : void 0,
      N;
    typeof s == "function"
      ? (N = s(T))
      : (N = [
          s,
          b ? "active" : null,
          P ? "pending" : null,
          g ? "transitioning" : null,
        ]
          .filter(Boolean)
          .join(" "));
    let O = typeof l == "function" ? l(T) : l;
    return j.createElement(
      ye,
      Gs({}, f, {
        "aria-current": V,
        className: N,
        ref: n,
        style: O,
        to: u,
        viewTransition: c,
      }),
      typeof d == "function" ? d(T) : d,
    );
  });
var gl;
(function (e) {
  ((e.UseScrollRestoration = "useScrollRestoration"),
    (e.UseSubmit = "useSubmit"),
    (e.UseSubmitFetcher = "useSubmitFetcher"),
    (e.UseFetcher = "useFetcher"),
    (e.useViewTransitionState = "useViewTransitionState"));
})(gl || (gl = {}));
var Td;
(function (e) {
  ((e.UseFetcher = "useFetcher"),
    (e.UseFetchers = "useFetchers"),
    (e.UseScrollRestoration = "useScrollRestoration"));
})(Td || (Td = {}));
function U1(e) {
  let t = j.useContext(So);
  return (t || ee(!1), t);
}
function H1(e, t) {
  let {
      target: n,
      replace: r,
      state: i,
      preventScrollReset: s,
      relative: o,
      viewTransition: l,
    } = t === void 0 ? {} : t,
    u = vm(),
    c = Bn(),
    d = Co(e, { relative: o });
  return j.useCallback(
    (f) => {
      if (R1(f, n)) {
        f.preventDefault();
        let h = r !== void 0 ? r : Ks(c) === Ks(d);
        u(e, {
          replace: h,
          state: i,
          preventScrollReset: s,
          relative: o,
          viewTransition: l,
        });
      }
    },
    [c, u, d, r, i, n, e, s, o, l],
  );
}
function $1(e, t) {
  t === void 0 && (t = {});
  let n = j.useContext(B1);
  n == null && ee(!1);
  let { basename: r } = U1(gl.useViewTransitionState),
    i = Co(e, { relative: t.relative });
  if (!n.isTransitioning) return !1;
  let s = pr(n.currentLocation.pathname, r) || n.currentLocation.pathname,
    o = pr(n.nextLocation.pathname, r) || n.nextLocation.pathname;
  return pl(i.pathname, o) != null || pl(i.pathname, s) != null;
}
const Pd = [
  { label: "Home", href: "/" },
  { label: "About Us", href: "/#about" },
  { label: "Services", href: "/services" },
  { label: "News", href: "/#news" },
  { label: "Events", href: "/events" },
  { label: "Contact Us", href: "/contact" },
];
function Yr(...e) {
  return e.filter(Boolean).join(" ");
}
const Nd = { "/#about": "about", "/services": "services", "/#news": "news" },
  K1 = ["about", "services", "news"];
function G1() {
  const [e, t] = j.useState(!1),
    [n, r] = j.useState(null),
    [i, s] = j.useState(!0),
    o = Bn(),
    l = vm(),
    u = j.useRef(null);
  (j.useEffect(() => {
    t(!1);
  }, [o.pathname]),
    j.useEffect(() => {
      const m = (v) => {
        v.key === "Escape" && t(!1);
      };
      return (
        window.addEventListener("keydown", m),
        () => window.removeEventListener("keydown", m)
      );
    }, []),
    j.useEffect(() => {
      if (o.pathname !== "/") {
        s(!0);
        return;
      }
      const m = () => s(window.scrollY < 80);
      return (
        m(),
        window.addEventListener("scroll", m, { passive: !0 }),
        () => window.removeEventListener("scroll", m)
      );
    }, [o.pathname]),
    j.useEffect(() => {
      var x, k;
      if (o.pathname !== "/") {
        (r(null), (x = u.current) == null || x.disconnect());
        return;
      }
      (k = u.current) == null || k.disconnect();
      const m = new IntersectionObserver(
          (g) => {
            const p = g
              .filter((y) => y.isIntersecting)
              .sort(
                (y, w) => y.boundingClientRect.top - w.boundingClientRect.top,
              );
            p.length > 0 && r(p[0].target.id);
          },
          { rootMargin: "-15% 0px -65% 0px", threshold: 0 },
        ),
        v = setTimeout(() => {
          K1.forEach((g) => {
            const p = document.getElementById(g);
            p && m.observe(p);
          });
        }, 120);
      return (
        (u.current = m),
        () => {
          (clearTimeout(v), m.disconnect());
        }
      );
    }, [o.pathname]));
  const c = (m) => {
      const v = document.getElementById(m);
      if (!v) return;
      const x = v.getBoundingClientRect().top + window.scrollY - 96;
      window.scrollTo({ top: x, behavior: "smooth" });
    },
    d = (m) => {
      (t(!1), o.pathname === "/" ? c(m) : l("/", { state: { scrollTo: m } }));
    };
  j.useEffect(() => {
    var m;
    if (o.pathname === "/" && (m = o.state) != null && m.scrollTo) {
      const v = o.state.scrollTo,
        x = setTimeout(() => c(v), 150);
      return () => clearTimeout(x);
    }
  }, [o]);
  const f = (m) => {
      const v = Nd[m];
      return v
        ? o.pathname === "/" && n === v
        : m === "/"
          ? o.pathname === "/" && i
          : o.pathname === m;
    },
    h = (m, v = !1) => {
      const x = f(m.href),
        k = Nd[m.href],
        g = { fontFamily: "'Montserrat', sans-serif", fontWeight: 600 },
        p = Yr(
          "text-black text-sm tracking-wide uppercase transition-colors duration-150 whitespace-nowrap",
          x ? "underline underline-offset-4" : "hover:text-black/55",
        ),
        y = Yr(
          "px-3 py-3 text-left text-sm font-semibold uppercase tracking-wide text-black w-full transition-colors",
          x ? "bg-black/10" : "hover:bg-black/[0.06]",
        );
      return k
        ? a.jsx(
            "button",
            {
              onClick: () => d(k),
              className: v ? y : p,
              style: g,
              children: m.label,
            },
            m.href,
          )
        : m.href === "/"
          ? a.jsx(
              "button",
              {
                onClick: () => {
                  (t(!1),
                    o.pathname === "/"
                      ? window.scrollTo({ top: 0, behavior: "smooth" })
                      : l("/"));
                },
                className: v ? y : p,
                style: g,
                children: m.label,
              },
              m.href,
            )
          : a.jsx(
              W1,
              {
                to: m.href,
                end: m.href === "/",
                className: () => (v ? y : p),
                style: g,
                children: m.label,
              },
              m.href,
            );
    };
  return a.jsxs("header", {
    className: "fixed inset-x-0 top-0 z-50 bg-white shadow-md overflow-hidden",
    children: [
      a.jsx("style", {
        children: `
        @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&display=swap');
        .nb-heading { font-family: 'Montserrat', sans-serif; font-weight: 600; }
      `,
      }),
      a.jsxs("div", {
        className:
          "container-shell flex h-20 items-center justify-between gap-6",
        children: [
          a.jsx(ye, {
            to: "/",
            className: "shrink-0",
            style: {
              height: "80px",
              overflow: "hidden",
              display: "flex",
              alignItems: "center",
            },
            onClick: () => window.scrollTo({ top: 0, behavior: "smooth" }),
            children: a.jsx("img", {
              src: "/assets/logo.png",
              alt: "Matseke Business Investment logo",
              style: {
                height: "160px",
                width: "auto",
                objectFit: "contain",
                flexShrink: 0,
              },
              loading: "eager",
            }),
          }),
          a.jsx("nav", {
            className:
              "hidden md:flex flex-1 items-center justify-center gap-6",
            "aria-label": "Primary",
            children: Pd.map((m) => h(m)),
          }),
          a.jsx("button", {
            type: "button",
            className:
              "md:hidden inline-flex items-center justify-center rounded-none bg-black/10 px-3 py-2 text-black hover:bg-black/20 focus-visible:outline-none",
            "aria-label": "Toggle menu",
            "aria-expanded": e,
            onClick: () => t((m) => !m),
            children: a.jsx("span", {
              className: "text-lg nb-heading",
              children: e ? "✕" : "☰",
            }),
          }),
        ],
      }),
      a.jsx("div", {
        className: Yr(
          "md:hidden overflow-hidden bg-white transition-[max-height] duration-300",
          e ? "max-h-screen" : "max-h-0",
        ),
        children: a.jsxs("div", {
          className: "container-shell py-4",
          children: [
            a.jsx("nav", {
              className: "flex flex-col",
              "aria-label": "Mobile",
              children: Pd.map((m) => h(m, !0)),
            }),
            a.jsx("div", {
              className: "mt-4",
              children: a.jsx(ye, {
                to: "/contact",
                children: a.jsx("button", {
                  className:
                    "nb-heading w-full bg-black text-white text-sm uppercase tracking-wide hover:opacity-80 transition-opacity py-3",
                  onClick: () => t(!1),
                  children: "Get in Touch",
                }),
              }),
            }),
          ],
        }),
      }),
    ],
  });
}
var Sm = {
    color: void 0,
    size: void 0,
    className: void 0,
    style: void 0,
    attr: void 0,
  },
  Ed = Et.createContext && Et.createContext(Sm),
  Y1 = ["attr", "size", "title"];
function X1(e, t) {
  if (e == null) return {};
  var n,
    r,
    i = Q1(e, t);
  if (Object.getOwnPropertySymbols) {
    var s = Object.getOwnPropertySymbols(e);
    for (r = 0; r < s.length; r++)
      ((n = s[r]),
        t.indexOf(n) === -1 &&
          {}.propertyIsEnumerable.call(e, n) &&
          (i[n] = e[n]));
  }
  return i;
}
function Q1(e, t) {
  if (e == null) return {};
  var n = {};
  for (var r in e)
    if ({}.hasOwnProperty.call(e, r)) {
      if (t.indexOf(r) !== -1) continue;
      n[r] = e[r];
    }
  return n;
}
function Ys() {
  return (
    (Ys = Object.assign
      ? Object.assign.bind()
      : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n) ({}).hasOwnProperty.call(n, r) && (e[r] = n[r]);
          }
          return e;
        }),
    Ys.apply(null, arguments)
  );
}
function Md(e, t) {
  var n = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var r = Object.getOwnPropertySymbols(e);
    (t &&
      (r = r.filter(function (i) {
        return Object.getOwnPropertyDescriptor(e, i).enumerable;
      })),
      n.push.apply(n, r));
  }
  return n;
}
function Xs(e) {
  for (var t = 1; t < arguments.length; t++) {
    var n = arguments[t] != null ? arguments[t] : {};
    t % 2
      ? Md(Object(n), !0).forEach(function (r) {
          Z1(e, r, n[r]);
        })
      : Object.getOwnPropertyDescriptors
        ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n))
        : Md(Object(n)).forEach(function (r) {
            Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(n, r));
          });
  }
  return e;
}
function Z1(e, t, n) {
  return (
    (t = q1(t)) in e
      ? Object.defineProperty(e, t, {
          value: n,
          enumerable: !0,
          configurable: !0,
          writable: !0,
        })
      : (e[t] = n),
    e
  );
}
function q1(e) {
  var t = J1(e, "string");
  return typeof t == "symbol" ? t : t + "";
}
function J1(e, t) {
  if (typeof e != "object" || !e) return e;
  var n = e[Symbol.toPrimitive];
  if (n !== void 0) {
    var r = n.call(e, t);
    if (typeof r != "object") return r;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function bm(e) {
  return (
    e &&
    e.map((t, n) =>
      Et.createElement(t.tag, Xs({ key: n }, t.attr), bm(t.child)),
    )
  );
}
function Se(e) {
  return (t) =>
    Et.createElement(ex, Ys({ attr: Xs({}, e.attr) }, t), bm(e.child));
}
function ex(e) {
  var t = (n) => {
    var { attr: r, size: i, title: s } = e,
      o = X1(e, Y1),
      l = i || n.size || "1em",
      u;
    return (
      n.className && (u = n.className),
      e.className && (u = (u ? u + " " : "") + e.className),
      Et.createElement(
        "svg",
        Ys(
          { stroke: "currentColor", fill: "currentColor", strokeWidth: "0" },
          n.attr,
          r,
          o,
          {
            className: u,
            style: Xs(Xs({ color: e.color || n.color }, n.style), e.style),
            height: l,
            width: l,
            xmlns: "http://www.w3.org/2000/svg",
          },
        ),
        s && Et.createElement("title", null, s),
        e.children,
      )
    );
  };
  return Ed !== void 0
    ? Et.createElement(Ed.Consumer, null, (n) => t(n))
    : t(Sm);
}
function tx(e) {
  return Se({
    attr: { viewBox: "0 0 448 512" },
    child: [
      {
        tag: "path",
        attr: {
          d: "M100.28 448H7.4V148.9h92.88zM53.79 108.1C24.09 108.1 0 83.5 0 53.8a53.79 53.79 0 0 1 107.58 0c0 29.7-24.1 54.3-53.79 54.3zM447.9 448h-92.68V302.4c0-34.7-.7-79.2-48.29-79.2-48.29 0-55.69 37.7-55.69 76.7V448h-92.78V148.9h89.08v40.8h1.3c12.4-23.5 42.69-48.3 87.88-48.3 94 0 111.28 61.9 111.28 142.3V448z",
        },
        child: [],
      },
    ],
  })(e);
}
function nx(e) {
  return Se({
    attr: { viewBox: "0 0 448 512" },
    child: [
      {
        tag: "path",
        attr: {
          d: "M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z",
        },
        child: [],
      },
    ],
  })(e);
}
function rx(e) {
  return Se({
    attr: { viewBox: "0 0 24 24" },
    child: [
      { tag: "path", attr: { fill: "none", d: "M0 0h24v24H0z" }, child: [] },
      {
        tag: "path",
        attr: {
          d: "M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z",
        },
        child: [],
      },
    ],
  })(e);
}
function ix(e) {
  return Se({
    attr: { viewBox: "0 0 24 24" },
    child: [
      { tag: "path", attr: { fill: "none", d: "M0 0h24v24H0z" }, child: [] },
      {
        tag: "path",
        attr: {
          d: "M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5a2.5 2.5 0 0 1 0-5 2.5 2.5 0 0 1 0 5z",
        },
        child: [],
      },
    ],
  })(e);
}
const W = "#000000";
function sx() {
  return a.jsxs("footer", {
    className: "bg-white",
    style: { color: W, fontFamily: "'Montserrat', sans-serif" },
    children: [
      a.jsx("style", {
        children: `
        @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&display=swap');
        .footer-heading { font-family: 'Montserrat', sans-serif; font-weight: 600; letter-spacing: -0.01em; }
        .footer-body    { font-family: 'Montserrat', sans-serif; font-weight: 400; }
      `,
      }),
      a.jsxs("div", {
        className: "container-shell py-5",
        children: [
          a.jsxs("div", {
            className: "grid gap-8 pb-10 md:grid-cols-3",
            style: { borderBottom: `1px solid ${W}33` },
            children: [
              a.jsxs("div", {
                children: [
                  a.jsx("h4", {
                    className: "footer-heading font-semibold",
                    style: { color: W },
                    children: "Contact Us",
                  }),
                  a.jsxs("div", {
                    className:
                      "mt-2 flex items-start gap-2 text-sm footer-body",
                    style: { color: `${W}cc` },
                    children: [
                      a.jsx(ix, {
                        className: "shrink-0 text-xl mt-0.5",
                        style: { color: W, minWidth: "20px" },
                      }),
                      a.jsx("p", {
                        className: "footer-body",
                        style: { textAlign: "left" },
                        children:
                          "54 Maxwell drive, Woodmead Office Park, Building B, Waterfall",
                      }),
                    ],
                  }),
                  a.jsxs("div", {
                    className:
                      "mt-2 flex items-center gap-2 text-sm footer-body",
                    style: { color: `${W}cc` },
                    children: [
                      a.jsx(rx, {
                        className: "shrink-0 text-xl",
                        style: { color: W, minWidth: "20px" },
                      }),
                      a.jsx("p", {
                        className: "footer-body",
                        style: { textAlign: "left" },
                        children: "(010) 005 5942",
                      }),
                    ],
                  }),
                ],
              }),
              a.jsxs("div", {
                children: [
                  a.jsx("h4", {
                    className: "footer-heading font-semibold",
                    style: { color: W },
                    children: "Office Hours",
                  }),
                  a.jsx("p", {
                    className: "mt-2 text-sm footer-body",
                    style: { color: `${W}cc`, textAlign: "left" },
                    children: "Monday to Friday",
                  }),
                  a.jsx("p", {
                    className: "text-sm footer-body",
                    style: { color: `${W}cc`, textAlign: "left" },
                    children: "9:00 am to 4:00 pm",
                  }),
                ],
              }),
              a.jsxs("div", {
                children: [
                  a.jsx("h4", {
                    className: "footer-heading font-semibold",
                    style: { color: W },
                    children: "Follow us online",
                  }),
                  a.jsxs("div", {
                    className: "mt-4 flex gap-3",
                    children: [
                      a.jsx("a", {
                        href: "https://www.linkedin.com/company/matsekebusinessinvestment/?viewAsMember=true",
                        target: "_blank",
                        rel: "noopener noreferrer",
                        "aria-label": "LinkedIn",
                        className:
                          "grid size-9 place-items-center rounded-xl transition-colors",
                        style: { backgroundColor: `${W}1a`, color: W },
                        onMouseEnter: (e) => {
                          ((e.currentTarget.style.backgroundColor = W),
                            (e.currentTarget.style.color = "white"));
                        },
                        onMouseLeave: (e) => {
                          ((e.currentTarget.style.backgroundColor = `${W}1a`),
                            (e.currentTarget.style.color = W));
                        },
                        children: a.jsx(tx, { className: "text-sm" }),
                      }),
                      a.jsx("a", {
                        href: "https://www.instagram.com/matsekebusinessinvestment/",
                        target: "_blank",
                        rel: "noopener noreferrer",
                        "aria-label": "Instagram",
                        className:
                          "grid size-9 place-items-center rounded-xl transition-colors",
                        style: { backgroundColor: `${W}1a`, color: W },
                        onMouseEnter: (e) => {
                          ((e.currentTarget.style.backgroundColor = W),
                            (e.currentTarget.style.color = "white"));
                        },
                        onMouseLeave: (e) => {
                          ((e.currentTarget.style.backgroundColor = `${W}1a`),
                            (e.currentTarget.style.color = W));
                        },
                        children: a.jsx(nx, { className: "text-sm" }),
                      }),
                    ],
                  }),
                ],
              }),
            ],
          }),
          a.jsxs("div", {
            className: "mt-6 flex flex-col items-center gap-3 text-center",
            children: [
              a.jsxs("div", {
                className: "leading-tight",
                children: [
                  a.jsx("div", {
                    className: "footer-heading text-sm tracking-wide",
                    style: { color: W },
                    children: "MATSEKE BUSINESS INVESTMENT",
                  }),
                  a.jsx("div", {
                    className: "footer-body text-xs",
                    style: { color: `${W}b3` },
                    children: "AUTHORISED FINANCIAL SERVICES PROVIDER",
                  }),
                ],
              }),
              a.jsxs("div", {
                className:
                  "mt-1 flex flex-wrap items-center justify-center gap-6 text-xs footer-body",
                style: { color: `${W}cc` },
                children: [
                  a.jsx(ye, {
                    to: "/terms-and-conditions",
                    className:
                      "transition-opacity hover:opacity-60 underline underline-offset-2",
                    style: { color: `${W}cc` },
                    children: "Terms & Conditions",
                  }),
                  a.jsx(ye, {
                    to: "/privacy-policy",
                    className:
                      "transition-opacity hover:opacity-60 underline underline-offset-2",
                    style: { color: `${W}cc` },
                    children: "Privacy Policy",
                  }),
                ],
              }),
              a.jsxs("div", {
                className: "mt-1 text-[11px] footer-body",
                style: { color: `${W}99` },
                children: [
                  "© ",
                  new Date().getFullYear(),
                  " Matseke Business Investment. All rights reserved.",
                ],
              }),
            ],
          }),
        ],
      }),
    ],
  });
}
const Cm = j.createContext({});
function ox(e) {
  const t = j.useRef(null);
  return (t.current === null && (t.current = e()), t.current);
}
const ax = typeof window < "u",
  lx = ax ? j.useLayoutEffect : j.useEffect,
  Bu = j.createContext(null);
function Ou(e, t) {
  e.indexOf(t) === -1 && e.push(t);
}
function Qs(e, t) {
  const n = e.indexOf(t);
  n > -1 && e.splice(n, 1);
}
const bt = (e, t, n) => (n > t ? t : n < e ? e : n);
let Fu = () => {};
const an = {},
  Tm = (e) => /^-?(?:\d+(?:\.\d+)?|\.\d+)$/u.test(e);
function Pm(e) {
  return typeof e == "object" && e !== null;
}
const Nm = (e) => /^0[^.\s]+$/u.test(e);
function Em(e) {
  let t;
  return () => (t === void 0 && (t = e()), t);
}
const et = (e) => e,
  ux = (e, t) => (n) => t(e(n)),
  Ni = (...e) => e.reduce(ux),
  vi = (e, t, n) => {
    const r = t - e;
    return r === 0 ? 1 : (n - e) / r;
  };
class zu {
  constructor() {
    this.subscriptions = [];
  }
  add(t) {
    return (Ou(this.subscriptions, t), () => Qs(this.subscriptions, t));
  }
  notify(t, n, r) {
    const i = this.subscriptions.length;
    if (i)
      if (i === 1) this.subscriptions[0](t, n, r);
      else
        for (let s = 0; s < i; s++) {
          const o = this.subscriptions[s];
          o && o(t, n, r);
        }
  }
  getSize() {
    return this.subscriptions.length;
  }
  clear() {
    this.subscriptions.length = 0;
  }
}
const Ue = (e) => e * 1e3,
  qe = (e) => e / 1e3;
function Mm(e, t) {
  return t ? e * (1e3 / t) : 0;
}
const Am = (e, t, n) =>
    (((1 - 3 * n + 3 * t) * e + (3 * n - 6 * t)) * e + 3 * t) * e,
  cx = 1e-7,
  dx = 12;
function fx(e, t, n, r, i) {
  let s,
    o,
    l = 0;
  do ((o = t + (n - t) / 2), (s = Am(o, r, i) - e), s > 0 ? (n = o) : (t = o));
  while (Math.abs(s) > cx && ++l < dx);
  return o;
}
function Ei(e, t, n, r) {
  if (e === t && n === r) return et;
  const i = (s) => fx(s, 0, 1, e, n);
  return (s) => (s === 0 || s === 1 ? s : Am(i(s), t, r));
}
const Lm = (e) => (t) => (t <= 0.5 ? e(2 * t) / 2 : (2 - e(2 * (1 - t))) / 2),
  Rm = (e) => (t) => 1 - e(1 - t),
  Dm = Ei(0.33, 1.53, 0.69, 0.99),
  _u = Rm(Dm),
  Im = Lm(_u),
  Vm = (e) =>
    e >= 1
      ? 1
      : (e *= 2) < 1
        ? 0.5 * _u(e)
        : 0.5 * (2 - Math.pow(2, -10 * (e - 1))),
  Wu = (e) => 1 - Math.sin(Math.acos(e)),
  Bm = Rm(Wu),
  Om = Lm(Wu),
  hx = Ei(0.42, 0, 1, 1),
  px = Ei(0, 0, 0.58, 1),
  Fm = Ei(0.42, 0, 0.58, 1),
  mx = (e) => Array.isArray(e) && typeof e[0] != "number",
  zm = (e) => Array.isArray(e) && typeof e[0] == "number",
  gx = {
    linear: et,
    easeIn: hx,
    easeInOut: Fm,
    easeOut: px,
    circIn: Wu,
    circInOut: Om,
    circOut: Bm,
    backIn: _u,
    backInOut: Im,
    backOut: Dm,
    anticipate: Vm,
  },
  yx = (e) => typeof e == "string",
  Ad = (e) => {
    if (zm(e)) {
      Fu(e.length === 4);
      const [t, n, r, i] = e;
      return Ei(t, n, r, i);
    } else if (yx(e)) return gx[e];
    return e;
  },
  qi = [
    "setup",
    "read",
    "resolveKeyframes",
    "preUpdate",
    "update",
    "preRender",
    "render",
    "postRender",
  ];
function vx(e, t) {
  let n = new Set(),
    r = new Set(),
    i = !1,
    s = !1;
  const o = new WeakSet();
  let l = { delta: 0, timestamp: 0, isProcessing: !1 };
  function u(d) {
    (o.has(d) && (c.schedule(d), e()), d(l));
  }
  const c = {
    schedule: (d, f = !1, h = !1) => {
      const v = h && i ? n : r;
      return (f && o.add(d), v.add(d), d);
    },
    cancel: (d) => {
      (r.delete(d), o.delete(d));
    },
    process: (d) => {
      if (((l = d), i)) {
        s = !0;
        return;
      }
      i = !0;
      const f = n;
      ((n = r),
        (r = f),
        n.forEach(u),
        n.clear(),
        (i = !1),
        s && ((s = !1), c.process(d)));
    },
  };
  return c;
}
const xx = 40;
function _m(e, t) {
  let n = !1,
    r = !0;
  const i = { delta: 0, timestamp: 0, isProcessing: !1 },
    s = () => (n = !0),
    o = qi.reduce((y, w) => ((y[w] = vx(s)), y), {}),
    {
      setup: l,
      read: u,
      resolveKeyframes: c,
      preUpdate: d,
      update: f,
      preRender: h,
      render: m,
      postRender: v,
    } = o,
    x = () => {
      const y = an.useManualTiming,
        w = y ? i.timestamp : performance.now();
      ((n = !1),
        y ||
          (i.delta = r ? 1e3 / 60 : Math.max(Math.min(w - i.timestamp, xx), 1)),
        (i.timestamp = w),
        (i.isProcessing = !0),
        l.process(i),
        u.process(i),
        c.process(i),
        d.process(i),
        f.process(i),
        h.process(i),
        m.process(i),
        v.process(i),
        (i.isProcessing = !1),
        n && t && ((r = !1), e(x)));
    },
    k = () => {
      ((n = !0), (r = !0), i.isProcessing || e(x));
    };
  return {
    schedule: qi.reduce((y, w) => {
      const S = o[w];
      return (
        (y[w] = (b, P = !1, T = !1) => (n || k(), S.schedule(b, P, T))),
        y
      );
    }, {}),
    cancel: (y) => {
      for (let w = 0; w < qi.length; w++) o[qi[w]].cancel(y);
    },
    state: i,
    steps: o,
  };
}
const {
  schedule: U,
  cancel: ln,
  state: pe,
  steps: ia,
} = _m(typeof requestAnimationFrame < "u" ? requestAnimationFrame : et, !0);
let ms;
function wx() {
  ms = void 0;
}
const Ce = {
    now: () => (
      ms === void 0 &&
        Ce.set(
          pe.isProcessing || an.useManualTiming
            ? pe.timestamp
            : performance.now(),
        ),
      ms
    ),
    set: (e) => {
      ((ms = e), queueMicrotask(wx));
    },
  },
  Wm = (e) => (t) => typeof t == "string" && t.startsWith(e),
  Um = Wm("--"),
  kx = Wm("var(--"),
  Uu = (e) => (kx(e) ? jx.test(e.split("/*")[0].trim()) : !1),
  jx =
    /var\(--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)$/iu;
function Ld(e) {
  return typeof e != "string" ? !1 : e.split("/*")[0].includes("var(--");
}
const kr = {
    test: (e) => typeof e == "number",
    parse: parseFloat,
    transform: (e) => e,
  },
  xi = { ...kr, transform: (e) => bt(0, 1, e) },
  Ji = { ...kr, default: 1 },
  Xr = (e) => Math.round(e * 1e5) / 1e5,
  Hu = /-?(?:\d+(?:\.\d+)?|\.\d+)/gu;
function Sx(e) {
  return e == null;
}
const bx =
    /^(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))$/iu,
  $u = (e, t) => (n) =>
    !!(
      (typeof n == "string" && bx.test(n) && n.startsWith(e)) ||
      (t && !Sx(n) && Object.prototype.hasOwnProperty.call(n, t))
    ),
  Hm = (e, t, n) => (r) => {
    if (typeof r != "string") return r;
    const [i, s, o, l] = r.match(Hu);
    return {
      [e]: parseFloat(i),
      [t]: parseFloat(s),
      [n]: parseFloat(o),
      alpha: l !== void 0 ? parseFloat(l) : 1,
    };
  },
  Cx = (e) => bt(0, 255, e),
  sa = { ...kr, transform: (e) => Math.round(Cx(e)) },
  Sn = {
    test: $u("rgb", "red"),
    parse: Hm("red", "green", "blue"),
    transform: ({ red: e, green: t, blue: n, alpha: r = 1 }) =>
      "rgba(" +
      sa.transform(e) +
      ", " +
      sa.transform(t) +
      ", " +
      sa.transform(n) +
      ", " +
      Xr(xi.transform(r)) +
      ")",
  };
function Tx(e) {
  let t = "",
    n = "",
    r = "",
    i = "";
  return (
    e.length > 5
      ? ((t = e.substring(1, 3)),
        (n = e.substring(3, 5)),
        (r = e.substring(5, 7)),
        (i = e.substring(7, 9)))
      : ((t = e.substring(1, 2)),
        (n = e.substring(2, 3)),
        (r = e.substring(3, 4)),
        (i = e.substring(4, 5)),
        (t += t),
        (n += n),
        (r += r),
        (i += i)),
    {
      red: parseInt(t, 16),
      green: parseInt(n, 16),
      blue: parseInt(r, 16),
      alpha: i ? parseInt(i, 16) / 255 : 1,
    }
  );
}
const yl = { test: $u("#"), parse: Tx, transform: Sn.transform },
  Mi = (e) => ({
    test: (t) =>
      typeof t == "string" && t.endsWith(e) && t.split(" ").length === 1,
    parse: parseFloat,
    transform: (t) => `${t}${e}`,
  }),
  Ft = Mi("deg"),
  St = Mi("%"),
  A = Mi("px"),
  Px = Mi("vh"),
  Nx = Mi("vw"),
  Rd = {
    ...St,
    parse: (e) => St.parse(e) / 100,
    transform: (e) => St.transform(e * 100),
  },
  qn = {
    test: $u("hsl", "hue"),
    parse: Hm("hue", "saturation", "lightness"),
    transform: ({ hue: e, saturation: t, lightness: n, alpha: r = 1 }) =>
      "hsla(" +
      Math.round(e) +
      ", " +
      St.transform(Xr(t)) +
      ", " +
      St.transform(Xr(n)) +
      ", " +
      Xr(xi.transform(r)) +
      ")",
  },
  ie = {
    test: (e) => Sn.test(e) || yl.test(e) || qn.test(e),
    parse: (e) =>
      Sn.test(e) ? Sn.parse(e) : qn.test(e) ? qn.parse(e) : yl.parse(e),
    transform: (e) =>
      typeof e == "string"
        ? e
        : e.hasOwnProperty("red")
          ? Sn.transform(e)
          : qn.transform(e),
    getAnimatableNone: (e) => {
      const t = ie.parse(e);
      return ((t.alpha = 0), ie.transform(t));
    },
  },
  Ex =
    /(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))/giu;
function Mx(e) {
  var t, n;
  return (
    isNaN(e) &&
    typeof e == "string" &&
    (((t = e.match(Hu)) == null ? void 0 : t.length) || 0) +
      (((n = e.match(Ex)) == null ? void 0 : n.length) || 0) >
      0
  );
}
const $m = "number",
  Km = "color",
  Ax = "var",
  Lx = "var(",
  Dd = "${}",
  Rx =
    /var\s*\(\s*--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)|#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\)|-?(?:\d+(?:\.\d+)?|\.\d+)/giu;
function mr(e) {
  const t = e.toString(),
    n = [],
    r = { color: [], number: [], var: [] },
    i = [];
  let s = 0;
  const l = t
    .replace(
      Rx,
      (u) => (
        ie.test(u)
          ? (r.color.push(s), i.push(Km), n.push(ie.parse(u)))
          : u.startsWith(Lx)
            ? (r.var.push(s), i.push(Ax), n.push(u))
            : (r.number.push(s), i.push($m), n.push(parseFloat(u))),
        ++s,
        Dd
      ),
    )
    .split(Dd);
  return { values: n, split: l, indexes: r, types: i };
}
function Dx(e) {
  return mr(e).values;
}
function Gm({ split: e, types: t }) {
  const n = e.length;
  return (r) => {
    let i = "";
    for (let s = 0; s < n; s++)
      if (((i += e[s]), r[s] !== void 0)) {
        const o = t[s];
        o === $m
          ? (i += Xr(r[s]))
          : o === Km
            ? (i += ie.transform(r[s]))
            : (i += r[s]);
      }
    return i;
  };
}
function Ix(e) {
  return Gm(mr(e));
}
const Vx = (e) =>
    typeof e == "number" ? 0 : ie.test(e) ? ie.getAnimatableNone(e) : e,
  Bx = (e, t) =>
    typeof e == "number"
      ? t != null && t.trim().endsWith("/")
        ? e
        : 0
      : Vx(e);
function Ox(e) {
  const t = mr(e);
  return Gm(t)(t.values.map((r, i) => Bx(r, t.split[i])));
}
const ht = {
  test: Mx,
  parse: Dx,
  createTransformer: Ix,
  getAnimatableNone: Ox,
};
function oa(e, t, n) {
  return (
    n < 0 && (n += 1),
    n > 1 && (n -= 1),
    n < 1 / 6
      ? e + (t - e) * 6 * n
      : n < 1 / 2
        ? t
        : n < 2 / 3
          ? e + (t - e) * (2 / 3 - n) * 6
          : e
  );
}
function Fx({ hue: e, saturation: t, lightness: n, alpha: r }) {
  ((e /= 360), (t /= 100), (n /= 100));
  let i = 0,
    s = 0,
    o = 0;
  if (!t) i = s = o = n;
  else {
    const l = n < 0.5 ? n * (1 + t) : n + t - n * t,
      u = 2 * n - l;
    ((i = oa(u, l, e + 1 / 3)), (s = oa(u, l, e)), (o = oa(u, l, e - 1 / 3)));
  }
  return {
    red: Math.round(i * 255),
    green: Math.round(s * 255),
    blue: Math.round(o * 255),
    alpha: r,
  };
}
function Zs(e, t) {
  return (n) => (n > 0 ? t : e);
}
const K = (e, t, n) => e + (t - e) * n,
  aa = (e, t, n) => {
    const r = e * e,
      i = n * (t * t - r) + r;
    return i < 0 ? 0 : Math.sqrt(i);
  },
  zx = [yl, Sn, qn],
  _x = (e) => zx.find((t) => t.test(e));
function Id(e) {
  const t = _x(e);
  if (!t) return !1;
  let n = t.parse(e);
  return (t === qn && (n = Fx(n)), n);
}
const Vd = (e, t) => {
    const n = Id(e),
      r = Id(t);
    if (!n || !r) return Zs(e, t);
    const i = { ...n };
    return (s) => (
      (i.red = aa(n.red, r.red, s)),
      (i.green = aa(n.green, r.green, s)),
      (i.blue = aa(n.blue, r.blue, s)),
      (i.alpha = K(n.alpha, r.alpha, s)),
      Sn.transform(i)
    );
  },
  vl = new Set(["none", "hidden"]);
function Wx(e, t) {
  return vl.has(e) ? (n) => (n <= 0 ? e : t) : (n) => (n >= 1 ? t : e);
}
function Ux(e, t) {
  return (n) => K(e, t, n);
}
function Ku(e) {
  return typeof e == "number"
    ? Ux
    : typeof e == "string"
      ? Uu(e)
        ? Zs
        : ie.test(e)
          ? Vd
          : Kx
      : Array.isArray(e)
        ? Ym
        : typeof e == "object"
          ? ie.test(e)
            ? Vd
            : Hx
          : Zs;
}
function Ym(e, t) {
  const n = [...e],
    r = n.length,
    i = e.map((s, o) => Ku(s)(s, t[o]));
  return (s) => {
    for (let o = 0; o < r; o++) n[o] = i[o](s);
    return n;
  };
}
function Hx(e, t) {
  const n = { ...e, ...t },
    r = {};
  for (const i in n)
    e[i] !== void 0 && t[i] !== void 0 && (r[i] = Ku(e[i])(e[i], t[i]));
  return (i) => {
    for (const s in r) n[s] = r[s](i);
    return n;
  };
}
function $x(e, t) {
  const n = [],
    r = { color: 0, var: 0, number: 0 };
  for (let i = 0; i < t.values.length; i++) {
    const s = t.types[i],
      o = e.indexes[s][r[s]],
      l = e.values[o] ?? 0;
    ((n[i] = l), r[s]++);
  }
  return n;
}
const Kx = (e, t) => {
  const n = ht.createTransformer(t),
    r = mr(e),
    i = mr(t);
  return r.indexes.var.length === i.indexes.var.length &&
    r.indexes.color.length === i.indexes.color.length &&
    r.indexes.number.length >= i.indexes.number.length
    ? (vl.has(e) && !i.values.length) || (vl.has(t) && !r.values.length)
      ? Wx(e, t)
      : Ni(Ym($x(r, i), i.values), n)
    : Zs(e, t);
};
function Xm(e, t, n) {
  return typeof e == "number" && typeof t == "number" && typeof n == "number"
    ? K(e, t, n)
    : Ku(e)(e, t);
}
const Gx = (e) => {
    const t = ({ timestamp: n }) => e(n);
    return {
      start: (n = !0) => U.update(t, n),
      stop: () => ln(t),
      now: () => (pe.isProcessing ? pe.timestamp : Ce.now()),
    };
  },
  Qm = (e, t, n = 10) => {
    let r = "";
    const i = Math.max(Math.round(t / n), 2);
    for (let s = 0; s < i; s++)
      r += Math.round(e(s / (i - 1)) * 1e4) / 1e4 + ", ";
    return `linear(${r.substring(0, r.length - 2)})`;
  },
  qs = 2e4;
function Gu(e) {
  let t = 0;
  const n = 50;
  let r = e.next(t);
  for (; !r.done && t < qs;) ((t += n), (r = e.next(t)));
  return t >= qs ? 1 / 0 : t;
}
function Yx(e, t = 100, n) {
  const r = n({ ...e, keyframes: [0, t] }),
    i = Math.min(Gu(r), qs);
  return {
    type: "keyframes",
    ease: (s) => r.next(i * s).value / t,
    duration: qe(i),
  };
}
const q = {
  stiffness: 100,
  damping: 10,
  mass: 1,
  velocity: 0,
  duration: 800,
  bounce: 0.3,
  visualDuration: 0.3,
  restSpeed: { granular: 0.01, default: 2 },
  restDelta: { granular: 0.005, default: 0.5 },
  minDuration: 0.01,
  maxDuration: 10,
  minDamping: 0.05,
  maxDamping: 1,
};
function xl(e, t) {
  return e * Math.sqrt(1 - t * t);
}
const Xx = 12;
function Qx(e, t, n) {
  let r = n;
  for (let i = 1; i < Xx; i++) r = r - e(r) / t(r);
  return r;
}
const la = 0.001;
function Zx({
  duration: e = q.duration,
  bounce: t = q.bounce,
  velocity: n = q.velocity,
  mass: r = q.mass,
}) {
  let i,
    s,
    o = 1 - t;
  ((o = bt(q.minDamping, q.maxDamping, o)),
    (e = bt(q.minDuration, q.maxDuration, qe(e))),
    o < 1
      ? ((i = (c) => {
          const d = c * o,
            f = d * e,
            h = d - n,
            m = xl(c, o),
            v = Math.exp(-f);
          return la - (h / m) * v;
        }),
        (s = (c) => {
          const f = c * o * e,
            h = f * n + n,
            m = Math.pow(o, 2) * Math.pow(c, 2) * e,
            v = Math.exp(-f),
            x = xl(Math.pow(c, 2), o);
          return ((-i(c) + la > 0 ? -1 : 1) * ((h - m) * v)) / x;
        }))
      : ((i = (c) => {
          const d = Math.exp(-c * e),
            f = (c - n) * e + 1;
          return -la + d * f;
        }),
        (s = (c) => {
          const d = Math.exp(-c * e),
            f = (n - c) * (e * e);
          return d * f;
        })));
  const l = 5 / e,
    u = Qx(i, s, l);
  if (((e = Ue(e)), isNaN(u)))
    return { stiffness: q.stiffness, damping: q.damping, duration: e };
  {
    const c = Math.pow(u, 2) * r;
    return { stiffness: c, damping: o * 2 * Math.sqrt(r * c), duration: e };
  }
}
const qx = ["duration", "bounce"],
  Jx = ["stiffness", "damping", "mass"];
function Bd(e, t) {
  return t.some((n) => e[n] !== void 0);
}
function e2(e) {
  let t = {
    velocity: q.velocity,
    stiffness: q.stiffness,
    damping: q.damping,
    mass: q.mass,
    isResolvedFromDuration: !1,
    ...e,
  };
  if (!Bd(e, Jx) && Bd(e, qx))
    if (((t.velocity = 0), e.visualDuration)) {
      const n = e.visualDuration,
        r = (2 * Math.PI) / (n * 1.2),
        i = r * r,
        s = 2 * bt(0.05, 1, 1 - (e.bounce || 0)) * Math.sqrt(i);
      t = { ...t, mass: q.mass, stiffness: i, damping: s };
    } else {
      const n = Zx({ ...e, velocity: 0 });
      ((t = { ...t, ...n, mass: q.mass }), (t.isResolvedFromDuration = !0));
    }
  return t;
}
function Js(e = q.visualDuration, t = q.bounce) {
  const n =
    typeof e != "object"
      ? { visualDuration: e, keyframes: [0, 1], bounce: t }
      : e;
  let { restSpeed: r, restDelta: i } = n;
  const s = n.keyframes[0],
    o = n.keyframes[n.keyframes.length - 1],
    l = { done: !1, value: s },
    {
      stiffness: u,
      damping: c,
      mass: d,
      duration: f,
      velocity: h,
      isResolvedFromDuration: m,
    } = e2({ ...n, velocity: -qe(n.velocity || 0) }),
    v = h || 0,
    x = c / (2 * Math.sqrt(u * d)),
    k = o - s,
    g = qe(Math.sqrt(u / d)),
    p = Math.abs(k) < 5;
  (r || (r = p ? q.restSpeed.granular : q.restSpeed.default),
    i || (i = p ? q.restDelta.granular : q.restDelta.default));
  let y, w, S, b, P, T;
  if (x < 1)
    ((S = xl(g, x)),
      (b = (v + x * g * k) / S),
      (y = (N) => {
        const O = Math.exp(-x * g * N);
        return o - O * (b * Math.sin(S * N) + k * Math.cos(S * N));
      }),
      (P = x * g * b + k * S),
      (T = x * g * k - b * S),
      (w = (N) =>
        Math.exp(-x * g * N) * (P * Math.sin(S * N) + T * Math.cos(S * N))));
  else if (x === 1) {
    y = (O) => o - Math.exp(-g * O) * (k + (v + g * k) * O);
    const N = v + g * k;
    w = (O) => Math.exp(-g * O) * (g * N * O - v);
  } else {
    const N = g * Math.sqrt(x * x - 1);
    y = (Oe) => {
      const it = Math.exp(-x * g * Oe),
        Me = Math.min(N * Oe, 300);
      return (
        o - (it * ((v + x * g * k) * Math.sinh(Me) + N * k * Math.cosh(Me))) / N
      );
    };
    const O = (v + x * g * k) / N,
      ne = x * g * O - k * N,
      Be = x * g * k - O * N;
    w = (Oe) => {
      const it = Math.exp(-x * g * Oe),
        Me = Math.min(N * Oe, 300);
      return it * (ne * Math.sinh(Me) + Be * Math.cosh(Me));
    };
  }
  const V = {
    calculatedDuration: (m && f) || null,
    velocity: (N) => Ue(w(N)),
    next: (N) => {
      if (!m && x < 1) {
        const ne = Math.exp(-x * g * N),
          Be = Math.sin(S * N),
          Oe = Math.cos(S * N),
          it = o - ne * (b * Be + k * Oe),
          Me = Ue(ne * (P * Be + T * Oe));
        return (
          (l.done = Math.abs(Me) <= r && Math.abs(o - it) <= i),
          (l.value = l.done ? o : it),
          l
        );
      }
      const O = y(N);
      if (m) l.done = N >= f;
      else {
        const ne = Ue(w(N));
        l.done = Math.abs(ne) <= r && Math.abs(o - O) <= i;
      }
      return ((l.value = l.done ? o : O), l);
    },
    toString: () => {
      const N = Math.min(Gu(V), qs),
        O = Qm((ne) => V.next(N * ne).value, N, 30);
      return N + "ms " + O;
    },
    toTransition: () => {},
  };
  return V;
}
Js.applyToOptions = (e) => {
  const t = Yx(e, 100, Js);
  return (
    (e.ease = t.ease),
    (e.duration = Ue(t.duration)),
    (e.type = "keyframes"),
    e
  );
};
const t2 = 5;
function Zm(e, t, n) {
  const r = Math.max(t - t2, 0);
  return Mm(n - e(r), t - r);
}
function wl({
  keyframes: e,
  velocity: t = 0,
  power: n = 0.8,
  timeConstant: r = 325,
  bounceDamping: i = 10,
  bounceStiffness: s = 500,
  modifyTarget: o,
  min: l,
  max: u,
  restDelta: c = 0.5,
  restSpeed: d,
}) {
  const f = e[0],
    h = { done: !1, value: f },
    m = (T) => (l !== void 0 && T < l) || (u !== void 0 && T > u),
    v = (T) =>
      l === void 0
        ? u
        : u === void 0 || Math.abs(l - T) < Math.abs(u - T)
          ? l
          : u;
  let x = n * t;
  const k = f + x,
    g = o === void 0 ? k : o(k);
  g !== k && (x = g - f);
  const p = (T) => -x * Math.exp(-T / r),
    y = (T) => g + p(T),
    w = (T) => {
      const V = p(T),
        N = y(T);
      ((h.done = Math.abs(V) <= c), (h.value = h.done ? g : N));
    };
  let S, b;
  const P = (T) => {
    m(h.value) &&
      ((S = T),
      (b = Js({
        keyframes: [h.value, v(h.value)],
        velocity: Zm(y, T, h.value),
        damping: i,
        stiffness: s,
        restDelta: c,
        restSpeed: d,
      })));
  };
  return (
    P(0),
    {
      calculatedDuration: null,
      next: (T) => {
        let V = !1;
        return (
          !b && S === void 0 && ((V = !0), w(T), P(T)),
          S !== void 0 && T >= S ? b.next(T - S) : (!V && w(T), h)
        );
      },
    }
  );
}
function n2(e, t, n) {
  const r = [],
    i = n || an.mix || Xm,
    s = e.length - 1;
  for (let o = 0; o < s; o++) {
    let l = i(e[o], e[o + 1]);
    if (t) {
      const u = Array.isArray(t) ? t[o] || et : t;
      l = Ni(u, l);
    }
    r.push(l);
  }
  return r;
}
function r2(e, t, { clamp: n = !0, ease: r, mixer: i } = {}) {
  const s = e.length;
  if ((Fu(s === t.length), s === 1)) return () => t[0];
  if (s === 2 && t[0] === t[1]) return () => t[1];
  const o = e[0] === e[1];
  e[0] > e[s - 1] && ((e = [...e].reverse()), (t = [...t].reverse()));
  const l = n2(t, r, i),
    u = l.length,
    c = (d) => {
      if (o && d < e[0]) return t[0];
      let f = 0;
      if (u > 1) for (; f < e.length - 2 && !(d < e[f + 1]); f++);
      const h = vi(e[f], e[f + 1], d);
      return l[f](h);
    };
  return n ? (d) => c(bt(e[0], e[s - 1], d)) : c;
}
function i2(e, t) {
  const n = e[e.length - 1];
  for (let r = 1; r <= t; r++) {
    const i = vi(0, t, r);
    e.push(K(n, 1, i));
  }
}
function s2(e) {
  const t = [0];
  return (i2(t, e.length - 1), t);
}
function o2(e, t) {
  return e.map((n) => n * t);
}
function a2(e, t) {
  return e.map(() => t || Fm).splice(0, e.length - 1);
}
function Qr({
  duration: e = 300,
  keyframes: t,
  times: n,
  ease: r = "easeInOut",
}) {
  const i = mx(r) ? r.map(Ad) : Ad(r),
    s = { done: !1, value: t[0] },
    o = o2(n && n.length === t.length ? n : s2(t), e),
    l = r2(o, t, { ease: Array.isArray(i) ? i : a2(t, i) });
  return {
    calculatedDuration: e,
    next: (u) => ((s.value = l(u)), (s.done = u >= e), s),
  };
}
const l2 = (e) => e !== null;
function To(e, { repeat: t, repeatType: n = "loop" }, r, i = 1) {
  const s = e.filter(l2),
    l = i < 0 || (t && n !== "loop" && t % 2 === 1) ? 0 : s.length - 1;
  return !l || r === void 0 ? s[l] : r;
}
const u2 = { decay: wl, inertia: wl, tween: Qr, keyframes: Qr, spring: Js };
function qm(e) {
  typeof e.type == "string" && (e.type = u2[e.type]);
}
class Yu {
  constructor() {
    this.updateFinished();
  }
  get finished() {
    return this._finished;
  }
  updateFinished() {
    this._finished = new Promise((t) => {
      this.resolve = t;
    });
  }
  notifyFinished() {
    this.resolve();
  }
  then(t, n) {
    return this.finished.then(t, n);
  }
}
const c2 = (e) => e / 100;
class eo extends Yu {
  constructor(t) {
    (super(),
      (this.state = "idle"),
      (this.startTime = null),
      (this.isStopped = !1),
      (this.currentTime = 0),
      (this.holdTime = null),
      (this.playbackSpeed = 1),
      (this.delayState = { done: !1, value: void 0 }),
      (this.stop = () => {
        var r, i;
        const { motionValue: n } = this.options;
        (n && n.updatedAt !== Ce.now() && this.tick(Ce.now()),
          (this.isStopped = !0),
          this.state !== "idle" &&
            (this.teardown(),
            (i = (r = this.options).onStop) == null || i.call(r)));
      }),
      (this.options = t),
      this.initAnimation(),
      this.play(),
      t.autoplay === !1 && this.pause());
  }
  initAnimation() {
    const { options: t } = this;
    qm(t);
    const {
      type: n = Qr,
      repeat: r = 0,
      repeatDelay: i = 0,
      repeatType: s,
      velocity: o = 0,
    } = t;
    let { keyframes: l } = t;
    const u = n || Qr;
    u !== Qr &&
      typeof l[0] != "number" &&
      ((this.mixKeyframes = Ni(c2, Xm(l[0], l[1]))), (l = [0, 100]));
    const c = u({ ...t, keyframes: l });
    (s === "mirror" &&
      (this.mirroredGenerator = u({
        ...t,
        keyframes: [...l].reverse(),
        velocity: -o,
      })),
      c.calculatedDuration === null && (c.calculatedDuration = Gu(c)));
    const { calculatedDuration: d } = c;
    ((this.calculatedDuration = d),
      (this.resolvedDuration = d + i),
      (this.totalDuration = this.resolvedDuration * (r + 1) - i),
      (this.generator = c));
  }
  updateTime(t) {
    const n = Math.round(t - this.startTime) * this.playbackSpeed;
    this.holdTime !== null
      ? (this.currentTime = this.holdTime)
      : (this.currentTime = n);
  }
  tick(t, n = !1) {
    const {
      generator: r,
      totalDuration: i,
      mixKeyframes: s,
      mirroredGenerator: o,
      resolvedDuration: l,
      calculatedDuration: u,
    } = this;
    if (this.startTime === null) return r.next(0);
    const {
      delay: c = 0,
      keyframes: d,
      repeat: f,
      repeatType: h,
      repeatDelay: m,
      type: v,
      onUpdate: x,
      finalKeyframe: k,
    } = this.options;
    (this.speed > 0
      ? (this.startTime = Math.min(this.startTime, t))
      : this.speed < 0 &&
        (this.startTime = Math.min(t - i / this.speed, this.startTime)),
      n ? (this.currentTime = t) : this.updateTime(t));
    const g = this.currentTime - c * (this.playbackSpeed >= 0 ? 1 : -1),
      p = this.playbackSpeed >= 0 ? g < 0 : g > i;
    ((this.currentTime = Math.max(g, 0)),
      this.state === "finished" &&
        this.holdTime === null &&
        (this.currentTime = i));
    let y = this.currentTime,
      w = r;
    if (f) {
      const T = Math.min(this.currentTime, i) / l;
      let V = Math.floor(T),
        N = T % 1;
      (!N && T >= 1 && (N = 1),
        N === 1 && V--,
        (V = Math.min(V, f + 1)),
        !!(V % 2) &&
          (h === "reverse"
            ? ((N = 1 - N), m && (N -= m / l))
            : h === "mirror" && (w = o)),
        (y = bt(0, 1, N) * l));
    }
    let S;
    (p
      ? ((this.delayState.value = d[0]), (S = this.delayState))
      : (S = w.next(y)),
      s && !p && (S.value = s(S.value)));
    let { done: b } = S;
    !p &&
      u !== null &&
      (b =
        this.playbackSpeed >= 0
          ? this.currentTime >= i
          : this.currentTime <= 0);
    const P =
      this.holdTime === null &&
      (this.state === "finished" || (this.state === "running" && b));
    return (
      P && v !== wl && (S.value = To(d, this.options, k, this.speed)),
      x && x(S.value),
      P && this.finish(),
      S
    );
  }
  then(t, n) {
    return this.finished.then(t, n);
  }
  get duration() {
    return qe(this.calculatedDuration);
  }
  get iterationDuration() {
    const { delay: t = 0 } = this.options || {};
    return this.duration + qe(t);
  }
  get time() {
    return qe(this.currentTime);
  }
  set time(t) {
    ((t = Ue(t)),
      (this.currentTime = t),
      this.startTime === null ||
      this.holdTime !== null ||
      this.playbackSpeed === 0
        ? (this.holdTime = t)
        : this.driver &&
          (this.startTime = this.driver.now() - t / this.playbackSpeed),
      this.driver
        ? this.driver.start(!1)
        : ((this.startTime = 0),
          (this.state = "paused"),
          (this.holdTime = t),
          this.tick(t)));
  }
  getGeneratorVelocity() {
    const t = this.currentTime;
    if (t <= 0) return this.options.velocity || 0;
    if (this.generator.velocity) return this.generator.velocity(t);
    const n = this.generator.next(t).value;
    return Zm((r) => this.generator.next(r).value, t, n);
  }
  get speed() {
    return this.playbackSpeed;
  }
  set speed(t) {
    const n = this.playbackSpeed !== t;
    (n && this.driver && this.updateTime(Ce.now()),
      (this.playbackSpeed = t),
      n && this.driver && (this.time = qe(this.currentTime)));
  }
  play() {
    var i, s;
    if (this.isStopped) return;
    const { driver: t = Gx, startTime: n } = this.options;
    (this.driver || (this.driver = t((o) => this.tick(o))),
      (s = (i = this.options).onPlay) == null || s.call(i));
    const r = this.driver.now();
    (this.state === "finished"
      ? (this.updateFinished(), (this.startTime = r))
      : this.holdTime !== null
        ? (this.startTime = r - this.holdTime)
        : this.startTime || (this.startTime = n ?? r),
      this.state === "finished" &&
        this.speed < 0 &&
        (this.startTime += this.calculatedDuration),
      (this.holdTime = null),
      (this.state = "running"),
      this.driver.start());
  }
  pause() {
    ((this.state = "paused"),
      this.updateTime(Ce.now()),
      (this.holdTime = this.currentTime));
  }
  complete() {
    (this.state !== "running" && this.play(),
      (this.state = "finished"),
      (this.holdTime = null));
  }
  finish() {
    var t, n;
    (this.notifyFinished(),
      this.teardown(),
      (this.state = "finished"),
      (n = (t = this.options).onComplete) == null || n.call(t));
  }
  cancel() {
    var t, n;
    ((this.holdTime = null),
      (this.startTime = 0),
      this.tick(0),
      this.teardown(),
      (n = (t = this.options).onCancel) == null || n.call(t));
  }
  teardown() {
    ((this.state = "idle"),
      this.stopDriver(),
      (this.startTime = this.holdTime = null));
  }
  stopDriver() {
    this.driver && (this.driver.stop(), (this.driver = void 0));
  }
  sample(t) {
    return ((this.startTime = 0), this.tick(t, !0));
  }
  attachTimeline(t) {
    var n;
    return (
      this.options.allowFlatten &&
        ((this.options.type = "keyframes"),
        (this.options.ease = "linear"),
        this.initAnimation()),
      (n = this.driver) == null || n.stop(),
      t.observe(this)
    );
  }
}
function d2(e) {
  for (let t = 1; t < e.length; t++) e[t] ?? (e[t] = e[t - 1]);
}
const bn = (e) => (e * 180) / Math.PI,
  kl = (e) => {
    const t = bn(Math.atan2(e[1], e[0]));
    return jl(t);
  },
  f2 = {
    x: 4,
    y: 5,
    translateX: 4,
    translateY: 5,
    scaleX: 0,
    scaleY: 3,
    scale: (e) => (Math.abs(e[0]) + Math.abs(e[3])) / 2,
    rotate: kl,
    rotateZ: kl,
    skewX: (e) => bn(Math.atan(e[1])),
    skewY: (e) => bn(Math.atan(e[2])),
    skew: (e) => (Math.abs(e[1]) + Math.abs(e[2])) / 2,
  },
  jl = (e) => ((e = e % 360), e < 0 && (e += 360), e),
  Od = kl,
  Fd = (e) => Math.sqrt(e[0] * e[0] + e[1] * e[1]),
  zd = (e) => Math.sqrt(e[4] * e[4] + e[5] * e[5]),
  h2 = {
    x: 12,
    y: 13,
    z: 14,
    translateX: 12,
    translateY: 13,
    translateZ: 14,
    scaleX: Fd,
    scaleY: zd,
    scale: (e) => (Fd(e) + zd(e)) / 2,
    rotateX: (e) => jl(bn(Math.atan2(e[6], e[5]))),
    rotateY: (e) => jl(bn(Math.atan2(-e[2], e[0]))),
    rotateZ: Od,
    rotate: Od,
    skewX: (e) => bn(Math.atan(e[4])),
    skewY: (e) => bn(Math.atan(e[1])),
    skew: (e) => (Math.abs(e[1]) + Math.abs(e[4])) / 2,
  };
function Sl(e) {
  return e.includes("scale") ? 1 : 0;
}
function bl(e, t) {
  if (!e || e === "none") return Sl(t);
  const n = e.match(/^matrix3d\(([-\d.e\s,]+)\)$/u);
  let r, i;
  if (n) ((r = h2), (i = n));
  else {
    const l = e.match(/^matrix\(([-\d.e\s,]+)\)$/u);
    ((r = f2), (i = l));
  }
  if (!i) return Sl(t);
  const s = r[t],
    o = i[1].split(",").map(m2);
  return typeof s == "function" ? s(o) : o[s];
}
const p2 = (e, t) => {
  const { transform: n = "none" } = getComputedStyle(e);
  return bl(n, t);
};
function m2(e) {
  return parseFloat(e.trim());
}
const jr = [
    "transformPerspective",
    "x",
    "y",
    "z",
    "translateX",
    "translateY",
    "translateZ",
    "scale",
    "scaleX",
    "scaleY",
    "rotate",
    "rotateX",
    "rotateY",
    "rotateZ",
    "skew",
    "skewX",
    "skewY",
  ],
  Sr = new Set(jr),
  _d = (e) => e === kr || e === A,
  g2 = new Set(["x", "y", "z"]),
  y2 = jr.filter((e) => !g2.has(e));
function v2(e) {
  const t = [];
  return (
    y2.forEach((n) => {
      const r = e.getValue(n);
      r !== void 0 &&
        (t.push([n, r.get()]), r.set(n.startsWith("scale") ? 1 : 0));
    }),
    t
  );
}
const Yt = {
  width: (
    { x: e },
    { paddingLeft: t = "0", paddingRight: n = "0", boxSizing: r },
  ) => {
    const i = e.max - e.min;
    return r === "border-box" ? i : i - parseFloat(t) - parseFloat(n);
  },
  height: (
    { y: e },
    { paddingTop: t = "0", paddingBottom: n = "0", boxSizing: r },
  ) => {
    const i = e.max - e.min;
    return r === "border-box" ? i : i - parseFloat(t) - parseFloat(n);
  },
  top: (e, { top: t }) => parseFloat(t),
  left: (e, { left: t }) => parseFloat(t),
  bottom: ({ y: e }, { top: t }) => parseFloat(t) + (e.max - e.min),
  right: ({ x: e }, { left: t }) => parseFloat(t) + (e.max - e.min),
  x: (e, { transform: t }) => bl(t, "x"),
  y: (e, { transform: t }) => bl(t, "y"),
};
Yt.translateX = Yt.x;
Yt.translateY = Yt.y;
const Pn = new Set();
let Cl = !1,
  Tl = !1,
  Pl = !1;
function Jm() {
  if (Tl) {
    const e = Array.from(Pn).filter((r) => r.needsMeasurement),
      t = new Set(e.map((r) => r.element)),
      n = new Map();
    (t.forEach((r) => {
      const i = v2(r);
      i.length && (n.set(r, i), r.render());
    }),
      e.forEach((r) => r.measureInitialState()),
      t.forEach((r) => {
        r.render();
        const i = n.get(r);
        i &&
          i.forEach(([s, o]) => {
            var l;
            (l = r.getValue(s)) == null || l.set(o);
          });
      }),
      e.forEach((r) => r.measureEndState()),
      e.forEach((r) => {
        r.suspendedScrollY !== void 0 && window.scrollTo(0, r.suspendedScrollY);
      }));
  }
  ((Tl = !1), (Cl = !1), Pn.forEach((e) => e.complete(Pl)), Pn.clear());
}
function eg() {
  Pn.forEach((e) => {
    (e.readKeyframes(), e.needsMeasurement && (Tl = !0));
  });
}
function x2() {
  ((Pl = !0), eg(), Jm(), (Pl = !1));
}
class Xu {
  constructor(t, n, r, i, s, o = !1) {
    ((this.state = "pending"),
      (this.isAsync = !1),
      (this.needsMeasurement = !1),
      (this.unresolvedKeyframes = [...t]),
      (this.onComplete = n),
      (this.name = r),
      (this.motionValue = i),
      (this.element = s),
      (this.isAsync = o));
  }
  scheduleResolve() {
    ((this.state = "scheduled"),
      this.isAsync
        ? (Pn.add(this), Cl || ((Cl = !0), U.read(eg), U.resolveKeyframes(Jm)))
        : (this.readKeyframes(), this.complete()));
  }
  readKeyframes() {
    const {
      unresolvedKeyframes: t,
      name: n,
      element: r,
      motionValue: i,
    } = this;
    if (t[0] === null) {
      const s = i == null ? void 0 : i.get(),
        o = t[t.length - 1];
      if (s !== void 0) t[0] = s;
      else if (r && n) {
        const l = r.readValue(n, o);
        l != null && (t[0] = l);
      }
      (t[0] === void 0 && (t[0] = o), i && s === void 0 && i.set(t[0]));
    }
    d2(t);
  }
  setFinalKeyframe() {}
  measureInitialState() {}
  renderEndStyles() {}
  measureEndState() {}
  complete(t = !1) {
    ((this.state = "complete"),
      this.onComplete(this.unresolvedKeyframes, this.finalKeyframe, t),
      Pn.delete(this));
  }
  cancel() {
    this.state === "scheduled" && (Pn.delete(this), (this.state = "pending"));
  }
  resume() {
    this.state === "pending" && this.scheduleResolve();
  }
}
const w2 = (e) => e.startsWith("--");
function tg(e, t, n) {
  w2(t) ? e.style.setProperty(t, n) : (e.style[t] = n);
}
const k2 = {};
function ng(e, t) {
  const n = Em(e);
  return () => k2[t] ?? n();
}
const j2 = ng(() => window.ScrollTimeline !== void 0, "scrollTimeline"),
  rg = ng(() => {
    try {
      document
        .createElement("div")
        .animate({ opacity: 0 }, { easing: "linear(0, 1)" });
    } catch {
      return !1;
    }
    return !0;
  }, "linearEasing"),
  Or = ([e, t, n, r]) => `cubic-bezier(${e}, ${t}, ${n}, ${r})`,
  Wd = {
    linear: "linear",
    ease: "ease",
    easeIn: "ease-in",
    easeOut: "ease-out",
    easeInOut: "ease-in-out",
    circIn: Or([0, 0.65, 0.55, 1]),
    circOut: Or([0.55, 0, 1, 0.45]),
    backIn: Or([0.31, 0.01, 0.66, -0.59]),
    backOut: Or([0.33, 1.53, 0.69, 0.99]),
  };
function ig(e, t) {
  if (e)
    return typeof e == "function"
      ? rg()
        ? Qm(e, t)
        : "ease-out"
      : zm(e)
        ? Or(e)
        : Array.isArray(e)
          ? e.map((n) => ig(n, t) || Wd.easeOut)
          : Wd[e];
}
function S2(
  e,
  t,
  n,
  {
    delay: r = 0,
    duration: i = 300,
    repeat: s = 0,
    repeatType: o = "loop",
    ease: l = "easeOut",
    times: u,
  } = {},
  c = void 0,
) {
  const d = { [t]: n };
  u && (d.offset = u);
  const f = ig(l, i);
  Array.isArray(f) && (d.easing = f);
  const h = {
    delay: r,
    duration: i,
    easing: Array.isArray(f) ? "linear" : f,
    fill: "both",
    iterations: s + 1,
    direction: o === "reverse" ? "alternate" : "normal",
  };
  return (c && (h.pseudoElement = c), e.animate(d, h));
}
function sg(e) {
  return typeof e == "function" && "applyToOptions" in e;
}
function b2({ type: e, ...t }) {
  return sg(e) && rg()
    ? e.applyToOptions(t)
    : (t.duration ?? (t.duration = 300), t.ease ?? (t.ease = "easeOut"), t);
}
class og extends Yu {
  constructor(t) {
    if (
      (super(),
      (this.finishedTime = null),
      (this.isStopped = !1),
      (this.manualStartTime = null),
      !t)
    )
      return;
    const {
      element: n,
      name: r,
      keyframes: i,
      pseudoElement: s,
      allowFlatten: o = !1,
      finalKeyframe: l,
      onComplete: u,
    } = t;
    ((this.isPseudoElement = !!s),
      (this.allowFlatten = o),
      (this.options = t),
      Fu(typeof t.type != "string"));
    const c = b2(t);
    ((this.animation = S2(n, r, i, c, s)),
      c.autoplay === !1 && this.animation.pause(),
      (this.animation.onfinish = () => {
        if (((this.finishedTime = this.time), !s)) {
          const d = To(i, this.options, l, this.speed);
          (this.updateMotionValue && this.updateMotionValue(d),
            tg(n, r, d),
            this.animation.cancel());
        }
        (u == null || u(), this.notifyFinished());
      }));
  }
  play() {
    this.isStopped ||
      ((this.manualStartTime = null),
      this.animation.play(),
      this.state === "finished" && this.updateFinished());
  }
  pause() {
    this.animation.pause();
  }
  complete() {
    var t, n;
    (n = (t = this.animation).finish) == null || n.call(t);
  }
  cancel() {
    try {
      this.animation.cancel();
    } catch {}
  }
  stop() {
    if (this.isStopped) return;
    this.isStopped = !0;
    const { state: t } = this;
    t === "idle" ||
      t === "finished" ||
      (this.updateMotionValue ? this.updateMotionValue() : this.commitStyles(),
      this.isPseudoElement || this.cancel());
  }
  commitStyles() {
    var n, r, i;
    const t = (n = this.options) == null ? void 0 : n.element;
    !this.isPseudoElement &&
      t != null &&
      t.isConnected &&
      ((i = (r = this.animation).commitStyles) == null || i.call(r));
  }
  get duration() {
    var n, r;
    const t =
      ((r =
        (n = this.animation.effect) == null ? void 0 : n.getComputedTiming) ==
      null
        ? void 0
        : r.call(n).duration) || 0;
    return qe(Number(t));
  }
  get iterationDuration() {
    const { delay: t = 0 } = this.options || {};
    return this.duration + qe(t);
  }
  get time() {
    return qe(Number(this.animation.currentTime) || 0);
  }
  set time(t) {
    const n = this.finishedTime !== null;
    ((this.manualStartTime = null),
      (this.finishedTime = null),
      (this.animation.currentTime = Ue(t)),
      n && this.animation.pause());
  }
  get speed() {
    return this.animation.playbackRate;
  }
  set speed(t) {
    (t < 0 && (this.finishedTime = null), (this.animation.playbackRate = t));
  }
  get state() {
    return this.finishedTime !== null ? "finished" : this.animation.playState;
  }
  get startTime() {
    return this.manualStartTime ?? Number(this.animation.startTime);
  }
  set startTime(t) {
    this.manualStartTime = this.animation.startTime = t;
  }
  attachTimeline({ timeline: t, rangeStart: n, rangeEnd: r, observe: i }) {
    var s;
    return (
      this.allowFlatten &&
        ((s = this.animation.effect) == null ||
          s.updateTiming({ easing: "linear" })),
      (this.animation.onfinish = null),
      t && j2()
        ? ((this.animation.timeline = t),
          n && (this.animation.rangeStart = n),
          r && (this.animation.rangeEnd = r),
          et)
        : i(this)
    );
  }
}
const ag = { anticipate: Vm, backInOut: Im, circInOut: Om };
function C2(e) {
  return e in ag;
}
function T2(e) {
  typeof e.ease == "string" && C2(e.ease) && (e.ease = ag[e.ease]);
}
const ua = 10;
class P2 extends og {
  constructor(t) {
    (T2(t),
      qm(t),
      super(t),
      t.startTime !== void 0 &&
        t.autoplay !== !1 &&
        (this.startTime = t.startTime),
      (this.options = t));
  }
  updateMotionValue(t) {
    const {
      motionValue: n,
      onUpdate: r,
      onComplete: i,
      element: s,
      ...o
    } = this.options;
    if (!n) return;
    if (t !== void 0) {
      n.set(t);
      return;
    }
    const l = new eo({ ...o, autoplay: !1 }),
      u = Math.max(ua, Ce.now() - this.startTime),
      c = bt(0, ua, u - ua),
      d = l.sample(u).value,
      { name: f } = this.options;
    (s && f && tg(s, f, d),
      n.setWithVelocity(l.sample(Math.max(0, u - c)).value, d, c),
      l.stop());
  }
}
const Ud = (e, t) =>
  t === "zIndex"
    ? !1
    : !!(
        typeof e == "number" ||
        Array.isArray(e) ||
        (typeof e == "string" &&
          (ht.test(e) || e === "0") &&
          !e.startsWith("url("))
      );
function N2(e) {
  const t = e[0];
  if (e.length === 1) return !0;
  for (let n = 0; n < e.length; n++) if (e[n] !== t) return !0;
}
function E2(e, t, n, r) {
  const i = e[0];
  if (i === null) return !1;
  if (t === "display" || t === "visibility") return !0;
  const s = e[e.length - 1],
    o = Ud(i, t),
    l = Ud(s, t);
  return !o || !l ? !1 : N2(e) || ((n === "spring" || sg(n)) && r);
}
function Nl(e) {
  ((e.duration = 0), (e.type = "keyframes"));
}
const lg = new Set(["opacity", "clipPath", "filter", "transform"]),
  M2 = /^(?:oklch|oklab|lab|lch|color|color-mix|light-dark)\(/;
function A2(e) {
  for (let t = 0; t < e.length; t++)
    if (typeof e[t] == "string" && M2.test(e[t])) return !0;
  return !1;
}
const L2 = new Set([
    "color",
    "backgroundColor",
    "outlineColor",
    "fill",
    "stroke",
    "borderColor",
    "borderTopColor",
    "borderRightColor",
    "borderBottomColor",
    "borderLeftColor",
  ]),
  R2 = Em(() => Object.hasOwnProperty.call(Element.prototype, "animate"));
function D2(e) {
  var f;
  const {
    motionValue: t,
    name: n,
    repeatDelay: r,
    repeatType: i,
    damping: s,
    type: o,
    keyframes: l,
  } = e;
  if (
    !(
      ((f = t == null ? void 0 : t.owner) == null
        ? void 0
        : f.current) instanceof HTMLElement
    )
  )
    return !1;
  const { onUpdate: c, transformTemplate: d } = t.owner.getProps();
  return (
    R2() &&
    n &&
    (lg.has(n) || (L2.has(n) && A2(l))) &&
    (n !== "transform" || !d) &&
    !c &&
    !r &&
    i !== "mirror" &&
    s !== 0 &&
    o !== "inertia"
  );
}
const I2 = 40;
class V2 extends Yu {
  constructor({
    autoplay: t = !0,
    delay: n = 0,
    type: r = "keyframes",
    repeat: i = 0,
    repeatDelay: s = 0,
    repeatType: o = "loop",
    keyframes: l,
    name: u,
    motionValue: c,
    element: d,
    ...f
  }) {
    var v;
    (super(),
      (this.stop = () => {
        var x, k;
        (this._animation &&
          (this._animation.stop(),
          (x = this.stopTimeline) == null || x.call(this)),
          (k = this.keyframeResolver) == null || k.cancel());
      }),
      (this.createdAt = Ce.now()));
    const h = {
        autoplay: t,
        delay: n,
        type: r,
        repeat: i,
        repeatDelay: s,
        repeatType: o,
        name: u,
        motionValue: c,
        element: d,
        ...f,
      },
      m = (d == null ? void 0 : d.KeyframeResolver) || Xu;
    ((this.keyframeResolver = new m(
      l,
      (x, k, g) => this.onKeyframesResolved(x, k, h, !g),
      u,
      c,
      d,
    )),
      (v = this.keyframeResolver) == null || v.scheduleResolve());
  }
  onKeyframesResolved(t, n, r, i) {
    var g, p;
    this.keyframeResolver = void 0;
    const {
      name: s,
      type: o,
      velocity: l,
      delay: u,
      isHandoff: c,
      onUpdate: d,
    } = r;
    this.resolvedAt = Ce.now();
    let f = !0;
    E2(t, s, o, l) ||
      ((f = !1),
      (an.instantAnimations || !u) && (d == null || d(To(t, r, n))),
      (t[0] = t[t.length - 1]),
      Nl(r),
      (r.repeat = 0));
    const m = {
        startTime: i
          ? this.resolvedAt
            ? this.resolvedAt - this.createdAt > I2
              ? this.resolvedAt
              : this.createdAt
            : this.createdAt
          : void 0,
        finalKeyframe: n,
        ...r,
        keyframes: t,
      },
      v = f && !c && D2(m),
      x =
        (p = (g = m.motionValue) == null ? void 0 : g.owner) == null
          ? void 0
          : p.current;
    let k;
    if (v)
      try {
        k = new P2({ ...m, element: x });
      } catch {
        k = new eo(m);
      }
    else k = new eo(m);
    (k.finished
      .then(() => {
        this.notifyFinished();
      })
      .catch(et),
      this.pendingTimeline &&
        ((this.stopTimeline = k.attachTimeline(this.pendingTimeline)),
        (this.pendingTimeline = void 0)),
      (this._animation = k));
  }
  get finished() {
    return this._animation ? this.animation.finished : this._finished;
  }
  then(t, n) {
    return this.finished.finally(t).then(() => {});
  }
  get animation() {
    var t;
    return (
      this._animation ||
        ((t = this.keyframeResolver) == null || t.resume(), x2()),
      this._animation
    );
  }
  get duration() {
    return this.animation.duration;
  }
  get iterationDuration() {
    return this.animation.iterationDuration;
  }
  get time() {
    return this.animation.time;
  }
  set time(t) {
    this.animation.time = t;
  }
  get speed() {
    return this.animation.speed;
  }
  get state() {
    return this.animation.state;
  }
  set speed(t) {
    this.animation.speed = t;
  }
  get startTime() {
    return this.animation.startTime;
  }
  attachTimeline(t) {
    return (
      this._animation
        ? (this.stopTimeline = this.animation.attachTimeline(t))
        : (this.pendingTimeline = t),
      () => this.stop()
    );
  }
  play() {
    this.animation.play();
  }
  pause() {
    this.animation.pause();
  }
  complete() {
    this.animation.complete();
  }
  cancel() {
    var t;
    (this._animation && this.animation.cancel(),
      (t = this.keyframeResolver) == null || t.cancel());
  }
}
function ug(e, t, n, r = 0, i = 1) {
  const s = Array.from(e)
      .sort((c, d) => c.sortNodePosition(d))
      .indexOf(t),
    o = e.size,
    l = (o - 1) * r;
  return typeof n == "function" ? n(s, o) : i === 1 ? s * r : l - s * r;
}
const B2 = /^var\(--(?:([\w-]+)|([\w-]+), ?([a-zA-Z\d ()%#.,-]+))\)/u;
function O2(e) {
  const t = B2.exec(e);
  if (!t) return [,];
  const [, n, r, i] = t;
  return [`--${n ?? r}`, i];
}
function cg(e, t, n = 1) {
  const [r, i] = O2(e);
  if (!r) return;
  const s = window.getComputedStyle(t).getPropertyValue(r);
  if (s) {
    const o = s.trim();
    return Tm(o) ? parseFloat(o) : o;
  }
  return Uu(i) ? cg(i, t, n + 1) : i;
}
const F2 = { type: "spring", stiffness: 500, damping: 25, restSpeed: 10 },
  z2 = (e) => ({
    type: "spring",
    stiffness: 550,
    damping: e === 0 ? 2 * Math.sqrt(550) : 30,
    restSpeed: 10,
  }),
  _2 = { type: "keyframes", duration: 0.8 },
  W2 = { type: "keyframes", ease: [0.25, 0.1, 0.35, 1], duration: 0.3 },
  U2 = (e, { keyframes: t }) =>
    t.length > 2
      ? _2
      : Sr.has(e)
        ? e.startsWith("scale")
          ? z2(t[1])
          : F2
        : W2;
function dg(e, t) {
  if (e != null && e.inherit && t) {
    const { inherit: n, ...r } = e;
    return { ...t, ...r };
  }
  return e;
}
function Qu(e, t) {
  const n =
    (e == null ? void 0 : e[t]) ?? (e == null ? void 0 : e.default) ?? e;
  return n !== e ? dg(n, e) : n;
}
const H2 = new Set([
  "when",
  "delay",
  "delayChildren",
  "staggerChildren",
  "staggerDirection",
  "repeat",
  "repeatType",
  "repeatDelay",
  "from",
  "elapsed",
]);
function $2(e) {
  for (const t in e) if (!H2.has(t)) return !0;
  return !1;
}
const Zu =
  (e, t, n, r = {}, i, s) =>
  (o) => {
    const l = Qu(r, e) || {},
      u = l.delay || r.delay || 0;
    let { elapsed: c = 0 } = r;
    c = c - Ue(u);
    const d = {
      keyframes: Array.isArray(n) ? n : [null, n],
      ease: "easeOut",
      velocity: t.getVelocity(),
      ...l,
      delay: -c,
      onUpdate: (h) => {
        (t.set(h), l.onUpdate && l.onUpdate(h));
      },
      onComplete: () => {
        (o(), l.onComplete && l.onComplete());
      },
      name: e,
      motionValue: t,
      element: s ? void 0 : i,
    };
    ($2(l) || Object.assign(d, U2(e, d)),
      d.duration && (d.duration = Ue(d.duration)),
      d.repeatDelay && (d.repeatDelay = Ue(d.repeatDelay)),
      d.from !== void 0 && (d.keyframes[0] = d.from));
    let f = !1;
    if (
      ((d.type === !1 || (d.duration === 0 && !d.repeatDelay)) &&
        (Nl(d), d.delay === 0 && (f = !0)),
      (an.instantAnimations ||
        an.skipAnimations ||
        (i != null && i.shouldSkipAnimations)) &&
        ((f = !0), Nl(d), (d.delay = 0)),
      (d.allowFlatten = !l.type && !l.ease),
      f && !s && t.get() !== void 0)
    ) {
      const h = To(d.keyframes, l);
      if (h !== void 0) {
        U.update(() => {
          (d.onUpdate(h), d.onComplete());
        });
        return;
      }
    }
    return l.isSync ? new eo(d) : new V2(d);
  };
function Hd(e) {
  const t = [{}, {}];
  return (
    e == null ||
      e.values.forEach((n, r) => {
        ((t[0][r] = n.get()), (t[1][r] = n.getVelocity()));
      }),
    t
  );
}
function qu(e, t, n, r) {
  if (typeof t == "function") {
    const [i, s] = Hd(r);
    t = t(n !== void 0 ? n : e.custom, i, s);
  }
  if (
    (typeof t == "string" && (t = e.variants && e.variants[t]),
    typeof t == "function")
  ) {
    const [i, s] = Hd(r);
    t = t(n !== void 0 ? n : e.custom, i, s);
  }
  return t;
}
function Nn(e, t, n) {
  const r = e.getProps();
  return qu(r, t, n !== void 0 ? n : r.custom, e);
}
const fg = new Set([
    "width",
    "height",
    "top",
    "left",
    "right",
    "bottom",
    ...jr,
  ]),
  $d = 30,
  K2 = (e) => !isNaN(parseFloat(e));
class G2 {
  constructor(t, n = {}) {
    ((this.canTrackVelocity = null),
      (this.events = {}),
      (this.updateAndNotify = (r) => {
        var s;
        const i = Ce.now();
        if (
          (this.updatedAt !== i && this.setPrevFrameValue(),
          (this.prev = this.current),
          this.setCurrent(r),
          this.current !== this.prev &&
            ((s = this.events.change) == null || s.notify(this.current),
            this.dependents))
        )
          for (const o of this.dependents) o.dirty();
      }),
      (this.hasAnimated = !1),
      this.setCurrent(t),
      (this.owner = n.owner));
  }
  setCurrent(t) {
    ((this.current = t),
      (this.updatedAt = Ce.now()),
      this.canTrackVelocity === null &&
        t !== void 0 &&
        (this.canTrackVelocity = K2(this.current)));
  }
  setPrevFrameValue(t = this.current) {
    ((this.prevFrameValue = t), (this.prevUpdatedAt = this.updatedAt));
  }
  onChange(t) {
    return this.on("change", t);
  }
  on(t, n) {
    this.events[t] || (this.events[t] = new zu());
    const r = this.events[t].add(n);
    return t === "change"
      ? () => {
          (r(),
            U.read(() => {
              this.events.change.getSize() || this.stop();
            }));
        }
      : r;
  }
  clearListeners() {
    for (const t in this.events) this.events[t].clear();
  }
  attach(t, n) {
    ((this.passiveEffect = t), (this.stopPassiveEffect = n));
  }
  set(t) {
    this.passiveEffect
      ? this.passiveEffect(t, this.updateAndNotify)
      : this.updateAndNotify(t);
  }
  setWithVelocity(t, n, r) {
    (this.set(n),
      (this.prev = void 0),
      (this.prevFrameValue = t),
      (this.prevUpdatedAt = this.updatedAt - r));
  }
  jump(t, n = !0) {
    (this.updateAndNotify(t),
      (this.prev = t),
      (this.prevUpdatedAt = this.prevFrameValue = void 0),
      n && this.stop(),
      this.stopPassiveEffect && this.stopPassiveEffect());
  }
  dirty() {
    var t;
    (t = this.events.change) == null || t.notify(this.current);
  }
  addDependent(t) {
    (this.dependents || (this.dependents = new Set()), this.dependents.add(t));
  }
  removeDependent(t) {
    this.dependents && this.dependents.delete(t);
  }
  get() {
    return this.current;
  }
  getPrevious() {
    return this.prev;
  }
  getVelocity() {
    const t = Ce.now();
    if (
      !this.canTrackVelocity ||
      this.prevFrameValue === void 0 ||
      t - this.updatedAt > $d
    )
      return 0;
    const n = Math.min(this.updatedAt - this.prevUpdatedAt, $d);
    return Mm(parseFloat(this.current) - parseFloat(this.prevFrameValue), n);
  }
  start(t) {
    return (
      this.stop(),
      new Promise((n) => {
        ((this.hasAnimated = !0),
          (this.animation = t(n)),
          this.events.animationStart && this.events.animationStart.notify());
      }).then(() => {
        (this.events.animationComplete &&
          this.events.animationComplete.notify(),
          this.clearAnimation());
      })
    );
  }
  stop() {
    (this.animation &&
      (this.animation.stop(),
      this.events.animationCancel && this.events.animationCancel.notify()),
      this.clearAnimation());
  }
  isAnimating() {
    return !!this.animation;
  }
  clearAnimation() {
    delete this.animation;
  }
  destroy() {
    var t, n;
    ((t = this.dependents) == null || t.clear(),
      (n = this.events.destroy) == null || n.notify(),
      this.clearListeners(),
      this.stop(),
      this.stopPassiveEffect && this.stopPassiveEffect());
  }
}
function gr(e, t) {
  return new G2(e, t);
}
const El = (e) => Array.isArray(e);
function Y2(e, t, n) {
  e.hasValue(t) ? e.getValue(t).set(n) : e.addValue(t, gr(n));
}
function X2(e) {
  return El(e) ? e[e.length - 1] || 0 : e;
}
function Q2(e, t) {
  const n = Nn(e, t);
  let { transitionEnd: r = {}, transition: i = {}, ...s } = n || {};
  s = { ...s, ...r };
  for (const o in s) {
    const l = X2(s[o]);
    Y2(e, o, l);
  }
}
const me = (e) => !!(e && e.getVelocity);
function Z2(e) {
  return !!(me(e) && e.add);
}
function Ml(e, t) {
  const n = e.getValue("willChange");
  if (Z2(n)) return n.add(t);
  if (!n && an.WillChange) {
    const r = new an.WillChange("auto");
    (e.addValue("willChange", r), r.add(t));
  }
}
function Ju(e) {
  return e.replace(/([A-Z])/g, (t) => `-${t.toLowerCase()}`);
}
const q2 = "framerAppearId",
  hg = "data-" + Ju(q2);
function pg(e) {
  return e.props[hg];
}
function J2({ protectedKeys: e, needsAnimating: t }, n) {
  const r = e.hasOwnProperty(n) && t[n] !== !0;
  return ((t[n] = !1), r);
}
function mg(e, t, { delay: n = 0, transitionOverride: r, type: i } = {}) {
  let { transition: s, transitionEnd: o, ...l } = t;
  const u = e.getDefaultTransition();
  s = s ? dg(s, u) : u;
  const c = s == null ? void 0 : s.reduceMotion;
  r && (s = r);
  const d = [],
    f = i && e.animationState && e.animationState.getState()[i];
  for (const h in l) {
    const m = e.getValue(h, e.latestValues[h] ?? null),
      v = l[h];
    if (v === void 0 || (f && J2(f, h))) continue;
    const x = { delay: n, ...Qu(s || {}, h) },
      k = m.get();
    if (
      k !== void 0 &&
      !m.isAnimating() &&
      !Array.isArray(v) &&
      v === k &&
      !x.velocity
    ) {
      U.update(() => m.set(v));
      continue;
    }
    let g = !1;
    if (window.MotionHandoffAnimation) {
      const w = pg(e);
      if (w) {
        const S = window.MotionHandoffAnimation(w, h, U);
        S !== null && ((x.startTime = S), (g = !0));
      }
    }
    Ml(e, h);
    const p = c ?? e.shouldReduceMotion;
    m.start(Zu(h, m, v, p && fg.has(h) ? { type: !1 } : x, e, g));
    const y = m.animation;
    y && d.push(y);
  }
  if (o) {
    const h = () =>
      U.update(() => {
        o && Q2(e, o);
      });
    d.length ? Promise.all(d).then(h) : h();
  }
  return d;
}
function Al(e, t, n = {}) {
  var u;
  const r = Nn(
    e,
    t,
    n.type === "exit"
      ? (u = e.presenceContext) == null
        ? void 0
        : u.custom
      : void 0,
  );
  let { transition: i = e.getDefaultTransition() || {} } = r || {};
  n.transitionOverride && (i = n.transitionOverride);
  const s = r ? () => Promise.all(mg(e, r, n)) : () => Promise.resolve(),
    o =
      e.variantChildren && e.variantChildren.size
        ? (c = 0) => {
            const {
              delayChildren: d = 0,
              staggerChildren: f,
              staggerDirection: h,
            } = i;
            return ew(e, t, c, d, f, h, n);
          }
        : () => Promise.resolve(),
    { when: l } = i;
  if (l) {
    const [c, d] = l === "beforeChildren" ? [s, o] : [o, s];
    return c().then(() => d());
  } else return Promise.all([s(), o(n.delay)]);
}
function ew(e, t, n = 0, r = 0, i = 0, s = 1, o) {
  const l = [];
  for (const u of e.variantChildren)
    (u.notify("AnimationStart", t),
      l.push(
        Al(u, t, {
          ...o,
          delay:
            n +
            (typeof r == "function" ? 0 : r) +
            ug(e.variantChildren, u, r, i, s),
        }).then(() => u.notify("AnimationComplete", t)),
      ));
  return Promise.all(l);
}
function tw(e, t, n = {}) {
  e.notify("AnimationStart", t);
  let r;
  if (Array.isArray(t)) {
    const i = t.map((s) => Al(e, s, n));
    r = Promise.all(i);
  } else if (typeof t == "string") r = Al(e, t, n);
  else {
    const i = typeof t == "function" ? Nn(e, t, n.custom) : t;
    r = Promise.all(mg(e, i, n));
  }
  return r.then(() => {
    e.notify("AnimationComplete", t);
  });
}
const nw = { test: (e) => e === "auto", parse: (e) => e },
  gg = (e) => (t) => t.test(e),
  yg = [kr, A, St, Ft, Nx, Px, nw],
  Kd = (e) => yg.find(gg(e));
function rw(e) {
  return typeof e == "number"
    ? e === 0
    : e !== null
      ? e === "none" || e === "0" || Nm(e)
      : !0;
}
const iw = new Set(["brightness", "contrast", "saturate", "opacity"]);
function sw(e) {
  const [t, n] = e.slice(0, -1).split("(");
  if (t === "drop-shadow") return e;
  const [r] = n.match(Hu) || [];
  if (!r) return e;
  const i = n.replace(r, "");
  let s = iw.has(t) ? 1 : 0;
  return (r !== n && (s *= 100), t + "(" + s + i + ")");
}
const ow = /\b([a-z-]*)\(.*?\)/gu,
  Ll = {
    ...ht,
    getAnimatableNone: (e) => {
      const t = e.match(ow);
      return t ? t.map(sw).join(" ") : e;
    },
  },
  Rl = {
    ...ht,
    getAnimatableNone: (e) => {
      const t = ht.parse(e);
      return ht.createTransformer(e)(
        t.map((r) =>
          typeof r == "number"
            ? 0
            : typeof r == "object"
              ? { ...r, alpha: 1 }
              : r,
        ),
      );
    },
  },
  Gd = { ...kr, transform: Math.round },
  aw = {
    rotate: Ft,
    rotateX: Ft,
    rotateY: Ft,
    rotateZ: Ft,
    scale: Ji,
    scaleX: Ji,
    scaleY: Ji,
    scaleZ: Ji,
    skew: Ft,
    skewX: Ft,
    skewY: Ft,
    distance: A,
    translateX: A,
    translateY: A,
    translateZ: A,
    x: A,
    y: A,
    z: A,
    perspective: A,
    transformPerspective: A,
    opacity: xi,
    originX: Rd,
    originY: Rd,
    originZ: A,
  },
  ec = {
    borderWidth: A,
    borderTopWidth: A,
    borderRightWidth: A,
    borderBottomWidth: A,
    borderLeftWidth: A,
    borderRadius: A,
    borderTopLeftRadius: A,
    borderTopRightRadius: A,
    borderBottomRightRadius: A,
    borderBottomLeftRadius: A,
    width: A,
    maxWidth: A,
    height: A,
    maxHeight: A,
    top: A,
    right: A,
    bottom: A,
    left: A,
    inset: A,
    insetBlock: A,
    insetBlockStart: A,
    insetBlockEnd: A,
    insetInline: A,
    insetInlineStart: A,
    insetInlineEnd: A,
    padding: A,
    paddingTop: A,
    paddingRight: A,
    paddingBottom: A,
    paddingLeft: A,
    paddingBlock: A,
    paddingBlockStart: A,
    paddingBlockEnd: A,
    paddingInline: A,
    paddingInlineStart: A,
    paddingInlineEnd: A,
    margin: A,
    marginTop: A,
    marginRight: A,
    marginBottom: A,
    marginLeft: A,
    marginBlock: A,
    marginBlockStart: A,
    marginBlockEnd: A,
    marginInline: A,
    marginInlineStart: A,
    marginInlineEnd: A,
    fontSize: A,
    backgroundPositionX: A,
    backgroundPositionY: A,
    ...aw,
    zIndex: Gd,
    fillOpacity: xi,
    strokeOpacity: xi,
    numOctaves: Gd,
  },
  lw = {
    ...ec,
    color: ie,
    backgroundColor: ie,
    outlineColor: ie,
    fill: ie,
    stroke: ie,
    borderColor: ie,
    borderTopColor: ie,
    borderRightColor: ie,
    borderBottomColor: ie,
    borderLeftColor: ie,
    filter: Ll,
    WebkitFilter: Ll,
    mask: Rl,
    WebkitMask: Rl,
  },
  vg = (e) => lw[e],
  uw = new Set([Ll, Rl]);
function xg(e, t) {
  let n = vg(e);
  return (
    uw.has(n) || (n = ht),
    n.getAnimatableNone ? n.getAnimatableNone(t) : void 0
  );
}
const cw = new Set(["auto", "none", "0"]);
function dw(e, t, n) {
  let r = 0,
    i;
  for (; r < e.length && !i;) {
    const s = e[r];
    (typeof s == "string" && !cw.has(s) && mr(s).values.length && (i = e[r]),
      r++);
  }
  if (i && n) for (const s of t) e[s] = xg(n, i);
}
class fw extends Xu {
  constructor(t, n, r, i, s) {
    super(t, n, r, i, s, !0);
  }
  readKeyframes() {
    const { unresolvedKeyframes: t, element: n, name: r } = this;
    if (!n || !n.current) return;
    super.readKeyframes();
    for (let d = 0; d < t.length; d++) {
      let f = t[d];
      if (typeof f == "string" && ((f = f.trim()), Uu(f))) {
        const h = cg(f, n.current);
        (h !== void 0 && (t[d] = h),
          d === t.length - 1 && (this.finalKeyframe = f));
      }
    }
    if ((this.resolveNoneKeyframes(), !fg.has(r) || t.length !== 2)) return;
    const [i, s] = t,
      o = Kd(i),
      l = Kd(s),
      u = Ld(i),
      c = Ld(s);
    if (u !== c && Yt[r]) {
      this.needsMeasurement = !0;
      return;
    }
    if (o !== l)
      if (_d(o) && _d(l))
        for (let d = 0; d < t.length; d++) {
          const f = t[d];
          typeof f == "string" && (t[d] = parseFloat(f));
        }
      else Yt[r] && (this.needsMeasurement = !0);
  }
  resolveNoneKeyframes() {
    const { unresolvedKeyframes: t, name: n } = this,
      r = [];
    for (let i = 0; i < t.length; i++) (t[i] === null || rw(t[i])) && r.push(i);
    r.length && dw(t, r, n);
  }
  measureInitialState() {
    const { element: t, unresolvedKeyframes: n, name: r } = this;
    if (!t || !t.current) return;
    (r === "height" && (this.suspendedScrollY = window.pageYOffset),
      (this.measuredOrigin = Yt[r](
        t.measureViewportBox(),
        window.getComputedStyle(t.current),
      )),
      (n[0] = this.measuredOrigin));
    const i = n[n.length - 1];
    i !== void 0 && t.getValue(r, i).jump(i, !1);
  }
  measureEndState() {
    var l;
    const { element: t, name: n, unresolvedKeyframes: r } = this;
    if (!t || !t.current) return;
    const i = t.getValue(n);
    i && i.jump(this.measuredOrigin, !1);
    const s = r.length - 1,
      o = r[s];
    ((r[s] = Yt[n](t.measureViewportBox(), window.getComputedStyle(t.current))),
      o !== null && this.finalKeyframe === void 0 && (this.finalKeyframe = o),
      (l = this.removedTransforms) != null &&
        l.length &&
        this.removedTransforms.forEach(([u, c]) => {
          t.getValue(u).set(c);
        }),
      this.resolveNoneKeyframes());
  }
}
function wg(e, t, n) {
  if (e == null) return [];
  if (e instanceof EventTarget) return [e];
  if (typeof e == "string") {
    let r = document;
    const i = (n == null ? void 0 : n[e]) ?? r.querySelectorAll(e);
    return i ? Array.from(i) : [];
  }
  return Array.from(e).filter((r) => r != null);
}
const kg = (e, t) => (t && typeof e == "number" ? t.transform(e) : e);
function hw(e) {
  return Pm(e) && "offsetHeight" in e && !("ownerSVGElement" in e);
}
const { schedule: tc } = _m(queueMicrotask, !1),
  at = { x: !1, y: !1 };
function jg() {
  return at.x || at.y;
}
function pw(e) {
  return e === "x" || e === "y"
    ? at[e]
      ? null
      : ((at[e] = !0),
        () => {
          at[e] = !1;
        })
    : at.x || at.y
      ? null
      : ((at.x = at.y = !0),
        () => {
          at.x = at.y = !1;
        });
}
function Sg(e, t) {
  const n = wg(e),
    r = new AbortController(),
    i = { passive: !0, ...t, signal: r.signal };
  return [n, i, () => r.abort()];
}
function mw(e) {
  return !(e.pointerType === "touch" || jg());
}
function gw(e, t, n = {}) {
  const [r, i, s] = Sg(e, n);
  return (
    r.forEach((o) => {
      let l = !1,
        u = !1,
        c;
      const d = () => {
          o.removeEventListener("pointerleave", v);
        },
        f = (k) => {
          (c && (c(k), (c = void 0)), d());
        },
        h = (k) => {
          ((l = !1),
            window.removeEventListener("pointerup", h),
            window.removeEventListener("pointercancel", h),
            u && ((u = !1), f(k)));
        },
        m = () => {
          ((l = !0),
            window.addEventListener("pointerup", h, i),
            window.addEventListener("pointercancel", h, i));
        },
        v = (k) => {
          if (k.pointerType !== "touch") {
            if (l) {
              u = !0;
              return;
            }
            f(k);
          }
        },
        x = (k) => {
          if (!mw(k)) return;
          u = !1;
          const g = t(o, k);
          typeof g == "function" &&
            ((c = g), o.addEventListener("pointerleave", v, i));
        };
      (o.addEventListener("pointerenter", x, i),
        o.addEventListener("pointerdown", m, i));
    }),
    s
  );
}
const bg = (e, t) => (t ? (e === t ? !0 : bg(e, t.parentElement)) : !1),
  nc = (e) =>
    e.pointerType === "mouse"
      ? typeof e.button != "number" || e.button <= 0
      : e.isPrimary !== !1,
  yw = new Set(["BUTTON", "INPUT", "SELECT", "TEXTAREA", "A"]);
function vw(e) {
  return yw.has(e.tagName) || e.isContentEditable === !0;
}
const xw = new Set(["INPUT", "SELECT", "TEXTAREA"]);
function ww(e) {
  return xw.has(e.tagName) || e.isContentEditable === !0;
}
const gs = new WeakSet();
function Yd(e) {
  return (t) => {
    t.key === "Enter" && e(t);
  };
}
function ca(e, t) {
  e.dispatchEvent(
    new PointerEvent("pointer" + t, { isPrimary: !0, bubbles: !0 }),
  );
}
const kw = (e, t) => {
  const n = e.currentTarget;
  if (!n) return;
  const r = Yd(() => {
    if (gs.has(n)) return;
    ca(n, "down");
    const i = Yd(() => {
        ca(n, "up");
      }),
      s = () => ca(n, "cancel");
    (n.addEventListener("keyup", i, t), n.addEventListener("blur", s, t));
  });
  (n.addEventListener("keydown", r, t),
    n.addEventListener("blur", () => n.removeEventListener("keydown", r), t));
};
function Xd(e) {
  return nc(e) && !jg();
}
const Qd = new WeakSet();
function jw(e, t, n = {}) {
  const [r, i, s] = Sg(e, n),
    o = (l) => {
      const u = l.currentTarget;
      if (!Xd(l) || Qd.has(l)) return;
      (gs.add(u), n.stopPropagation && Qd.add(l));
      const c = t(u, l),
        d = (m, v) => {
          (window.removeEventListener("pointerup", f),
            window.removeEventListener("pointercancel", h),
            gs.has(u) && gs.delete(u),
            Xd(m) && typeof c == "function" && c(m, { success: v }));
        },
        f = (m) => {
          d(
            m,
            u === window ||
              u === document ||
              n.useGlobalTarget ||
              bg(u, m.target),
          );
        },
        h = (m) => {
          d(m, !1);
        };
      (window.addEventListener("pointerup", f, i),
        window.addEventListener("pointercancel", h, i));
    };
  return (
    r.forEach((l) => {
      ((n.useGlobalTarget ? window : l).addEventListener("pointerdown", o, i),
        hw(l) &&
          (l.addEventListener("focus", (c) => kw(c, i)),
          !vw(l) && !l.hasAttribute("tabindex") && (l.tabIndex = 0)));
    }),
    s
  );
}
function rc(e) {
  return Pm(e) && "ownerSVGElement" in e;
}
const ys = new WeakMap();
let zt;
const Cg = (e, t, n) => (r, i) =>
    i && i[0]
      ? i[0][e + "Size"]
      : rc(r) && "getBBox" in r
        ? r.getBBox()[t]
        : r[n],
  Sw = Cg("inline", "width", "offsetWidth"),
  bw = Cg("block", "height", "offsetHeight");
function Cw({ target: e, borderBoxSize: t }) {
  var n;
  (n = ys.get(e)) == null ||
    n.forEach((r) => {
      r(e, {
        get width() {
          return Sw(e, t);
        },
        get height() {
          return bw(e, t);
        },
      });
    });
}
function Tw(e) {
  e.forEach(Cw);
}
function Pw() {
  typeof ResizeObserver > "u" || (zt = new ResizeObserver(Tw));
}
function Nw(e, t) {
  zt || Pw();
  const n = wg(e);
  return (
    n.forEach((r) => {
      let i = ys.get(r);
      (i || ((i = new Set()), ys.set(r, i)),
        i.add(t),
        zt == null || zt.observe(r));
    }),
    () => {
      n.forEach((r) => {
        const i = ys.get(r);
        (i == null || i.delete(t),
          (i != null && i.size) || zt == null || zt.unobserve(r));
      });
    }
  );
}
const vs = new Set();
let Jn;
function Ew() {
  ((Jn = () => {
    const e = {
      get width() {
        return window.innerWidth;
      },
      get height() {
        return window.innerHeight;
      },
    };
    vs.forEach((t) => t(e));
  }),
    window.addEventListener("resize", Jn));
}
function Mw(e) {
  return (
    vs.add(e),
    Jn || Ew(),
    () => {
      (vs.delete(e),
        !vs.size &&
          typeof Jn == "function" &&
          (window.removeEventListener("resize", Jn), (Jn = void 0)));
    }
  );
}
function Zd(e, t) {
  return typeof e == "function" ? Mw(e) : Nw(e, t);
}
function Aw(e) {
  return rc(e) && e.tagName === "svg";
}
const Lw = [...yg, ie, ht],
  Rw = (e) => Lw.find(gg(e)),
  qd = () => ({ translate: 0, scale: 1, origin: 0, originPoint: 0 }),
  er = () => ({ x: qd(), y: qd() }),
  Jd = () => ({ min: 0, max: 0 }),
  oe = () => ({ x: Jd(), y: Jd() }),
  Dw = new WeakMap();
function Po(e) {
  return e !== null && typeof e == "object" && typeof e.start == "function";
}
function wi(e) {
  return typeof e == "string" || Array.isArray(e);
}
const ic = [
    "animate",
    "whileInView",
    "whileFocus",
    "whileHover",
    "whileTap",
    "whileDrag",
    "exit",
  ],
  sc = ["initial", ...ic];
function No(e) {
  return Po(e.animate) || sc.some((t) => wi(e[t]));
}
function Tg(e) {
  return !!(No(e) || e.variants);
}
function Iw(e, t, n) {
  for (const r in t) {
    const i = t[r],
      s = n[r];
    if (me(i)) e.addValue(r, i);
    else if (me(s)) e.addValue(r, gr(i, { owner: e }));
    else if (s !== i)
      if (e.hasValue(r)) {
        const o = e.getValue(r);
        o.liveStyle === !0 ? o.jump(i) : o.hasAnimated || o.set(i);
      } else {
        const o = e.getStaticValue(r);
        e.addValue(r, gr(o !== void 0 ? o : i, { owner: e }));
      }
  }
  for (const r in n) t[r] === void 0 && e.removeValue(r);
  return t;
}
const Dl = { current: null },
  Pg = { current: !1 },
  Vw = typeof window < "u";
function Bw() {
  if (((Pg.current = !0), !!Vw))
    if (window.matchMedia) {
      const e = window.matchMedia("(prefers-reduced-motion)"),
        t = () => (Dl.current = e.matches);
      (e.addEventListener("change", t), t());
    } else Dl.current = !1;
}
const ef = [
  "AnimationStart",
  "AnimationComplete",
  "Update",
  "BeforeLayoutMeasure",
  "LayoutMeasure",
  "LayoutAnimationStart",
  "LayoutAnimationComplete",
];
let to = {};
function Ng(e) {
  to = e;
}
function Ow() {
  return to;
}
class Fw {
  scrapeMotionValuesFromProps(t, n, r) {
    return {};
  }
  constructor(
    {
      parent: t,
      props: n,
      presenceContext: r,
      reducedMotionConfig: i,
      skipAnimations: s,
      blockInitialAnimation: o,
      visualState: l,
    },
    u = {},
  ) {
    ((this.current = null),
      (this.children = new Set()),
      (this.isVariantNode = !1),
      (this.isControllingVariants = !1),
      (this.shouldReduceMotion = null),
      (this.shouldSkipAnimations = !1),
      (this.values = new Map()),
      (this.KeyframeResolver = Xu),
      (this.features = {}),
      (this.valueSubscriptions = new Map()),
      (this.prevMotionValues = {}),
      (this.hasBeenMounted = !1),
      (this.events = {}),
      (this.propEventSubscriptions = {}),
      (this.notifyUpdate = () => this.notify("Update", this.latestValues)),
      (this.render = () => {
        this.current &&
          (this.triggerBuild(),
          this.renderInstance(
            this.current,
            this.renderState,
            this.props.style,
            this.projection,
          ));
      }),
      (this.renderScheduledAt = 0),
      (this.scheduleRender = () => {
        const m = Ce.now();
        this.renderScheduledAt < m &&
          ((this.renderScheduledAt = m), U.render(this.render, !1, !0));
      }));
    const { latestValues: c, renderState: d } = l;
    ((this.latestValues = c),
      (this.baseTarget = { ...c }),
      (this.initialValues = n.initial ? { ...c } : {}),
      (this.renderState = d),
      (this.parent = t),
      (this.props = n),
      (this.presenceContext = r),
      (this.depth = t ? t.depth + 1 : 0),
      (this.reducedMotionConfig = i),
      (this.skipAnimationsConfig = s),
      (this.options = u),
      (this.blockInitialAnimation = !!o),
      (this.isControllingVariants = No(n)),
      (this.isVariantNode = Tg(n)),
      this.isVariantNode && (this.variantChildren = new Set()),
      (this.manuallyAnimateOnMount = !!(t && t.current)));
    const { willChange: f, ...h } = this.scrapeMotionValuesFromProps(
      n,
      {},
      this,
    );
    for (const m in h) {
      const v = h[m];
      c[m] !== void 0 && me(v) && v.set(c[m]);
    }
  }
  mount(t) {
    var n, r;
    if (this.hasBeenMounted)
      for (const i in this.initialValues)
        ((n = this.values.get(i)) == null || n.jump(this.initialValues[i]),
          (this.latestValues[i] = this.initialValues[i]));
    ((this.current = t),
      Dw.set(t, this),
      this.projection && !this.projection.instance && this.projection.mount(t),
      this.parent &&
        this.isVariantNode &&
        !this.isControllingVariants &&
        (this.removeFromVariantTree = this.parent.addVariantChild(this)),
      this.values.forEach((i, s) => this.bindToMotionValue(s, i)),
      this.reducedMotionConfig === "never"
        ? (this.shouldReduceMotion = !1)
        : this.reducedMotionConfig === "always"
          ? (this.shouldReduceMotion = !0)
          : (Pg.current || Bw(), (this.shouldReduceMotion = Dl.current)),
      (this.shouldSkipAnimations = this.skipAnimationsConfig ?? !1),
      (r = this.parent) == null || r.addChild(this),
      this.update(this.props, this.presenceContext),
      (this.hasBeenMounted = !0));
  }
  unmount() {
    var t;
    (this.projection && this.projection.unmount(),
      ln(this.notifyUpdate),
      ln(this.render),
      this.valueSubscriptions.forEach((n) => n()),
      this.valueSubscriptions.clear(),
      this.removeFromVariantTree && this.removeFromVariantTree(),
      (t = this.parent) == null || t.removeChild(this));
    for (const n in this.events) this.events[n].clear();
    for (const n in this.features) {
      const r = this.features[n];
      r && (r.unmount(), (r.isMounted = !1));
    }
    this.current = null;
  }
  addChild(t) {
    (this.children.add(t),
      this.enteringChildren ?? (this.enteringChildren = new Set()),
      this.enteringChildren.add(t));
  }
  removeChild(t) {
    (this.children.delete(t),
      this.enteringChildren && this.enteringChildren.delete(t));
  }
  bindToMotionValue(t, n) {
    if (
      (this.valueSubscriptions.has(t) && this.valueSubscriptions.get(t)(),
      n.accelerate && lg.has(t) && this.current instanceof HTMLElement)
    ) {
      const {
          factory: o,
          keyframes: l,
          times: u,
          ease: c,
          duration: d,
        } = n.accelerate,
        f = new og({
          element: this.current,
          name: t,
          keyframes: l,
          times: u,
          ease: c,
          duration: Ue(d),
        }),
        h = o(f);
      this.valueSubscriptions.set(t, () => {
        (h(), f.cancel());
      });
      return;
    }
    const r = Sr.has(t);
    r && this.onBindTransform && this.onBindTransform();
    const i = n.on("change", (o) => {
      ((this.latestValues[t] = o),
        this.props.onUpdate && U.preRender(this.notifyUpdate),
        r && this.projection && (this.projection.isTransformDirty = !0),
        this.scheduleRender());
    });
    let s;
    (typeof window < "u" &&
      window.MotionCheckAppearSync &&
      (s = window.MotionCheckAppearSync(this, t, n)),
      this.valueSubscriptions.set(t, () => {
        (i(), s && s(), n.owner && n.stop());
      }));
  }
  sortNodePosition(t) {
    return !this.current ||
      !this.sortInstanceNodePosition ||
      this.type !== t.type
      ? 0
      : this.sortInstanceNodePosition(this.current, t.current);
  }
  updateFeatures() {
    let t = "animation";
    for (t in to) {
      const n = to[t];
      if (!n) continue;
      const { isEnabled: r, Feature: i } = n;
      if (
        (!this.features[t] &&
          i &&
          r(this.props) &&
          (this.features[t] = new i(this)),
        this.features[t])
      ) {
        const s = this.features[t];
        s.isMounted ? s.update() : (s.mount(), (s.isMounted = !0));
      }
    }
  }
  triggerBuild() {
    this.build(this.renderState, this.latestValues, this.props);
  }
  measureViewportBox() {
    return this.current
      ? this.measureInstanceViewportBox(this.current, this.props)
      : oe();
  }
  getStaticValue(t) {
    return this.latestValues[t];
  }
  setStaticValue(t, n) {
    this.latestValues[t] = n;
  }
  update(t, n) {
    ((t.transformTemplate || this.props.transformTemplate) &&
      this.scheduleRender(),
      (this.prevProps = this.props),
      (this.props = t),
      (this.prevPresenceContext = this.presenceContext),
      (this.presenceContext = n));
    for (let r = 0; r < ef.length; r++) {
      const i = ef[r];
      this.propEventSubscriptions[i] &&
        (this.propEventSubscriptions[i](),
        delete this.propEventSubscriptions[i]);
      const s = "on" + i,
        o = t[s];
      o && (this.propEventSubscriptions[i] = this.on(i, o));
    }
    ((this.prevMotionValues = Iw(
      this,
      this.scrapeMotionValuesFromProps(t, this.prevProps || {}, this),
      this.prevMotionValues,
    )),
      this.handleChildMotionValue && this.handleChildMotionValue());
  }
  getProps() {
    return this.props;
  }
  getVariant(t) {
    return this.props.variants ? this.props.variants[t] : void 0;
  }
  getDefaultTransition() {
    return this.props.transition;
  }
  getTransformPagePoint() {
    return this.props.transformPagePoint;
  }
  getClosestVariantNode() {
    return this.isVariantNode
      ? this
      : this.parent
        ? this.parent.getClosestVariantNode()
        : void 0;
  }
  addVariantChild(t) {
    const n = this.getClosestVariantNode();
    if (n)
      return (
        n.variantChildren && n.variantChildren.add(t),
        () => n.variantChildren.delete(t)
      );
  }
  addValue(t, n) {
    const r = this.values.get(t);
    n !== r &&
      (r && this.removeValue(t),
      this.bindToMotionValue(t, n),
      this.values.set(t, n),
      (this.latestValues[t] = n.get()));
  }
  removeValue(t) {
    this.values.delete(t);
    const n = this.valueSubscriptions.get(t);
    (n && (n(), this.valueSubscriptions.delete(t)),
      delete this.latestValues[t],
      this.removeValueFromRenderState(t, this.renderState));
  }
  hasValue(t) {
    return this.values.has(t);
  }
  getValue(t, n) {
    if (this.props.values && this.props.values[t]) return this.props.values[t];
    let r = this.values.get(t);
    return (
      r === void 0 &&
        n !== void 0 &&
        ((r = gr(n === null ? void 0 : n, { owner: this })),
        this.addValue(t, r)),
      r
    );
  }
  readValue(t, n) {
    let r =
      this.latestValues[t] !== void 0 || !this.current
        ? this.latestValues[t]
        : (this.getBaseTargetFromProps(this.props, t) ??
          this.readValueFromInstance(this.current, t, this.options));
    return (
      r != null &&
        (typeof r == "string" && (Tm(r) || Nm(r))
          ? (r = parseFloat(r))
          : !Rw(r) && ht.test(n) && (r = xg(t, n)),
        this.setBaseTarget(t, me(r) ? r.get() : r)),
      me(r) ? r.get() : r
    );
  }
  setBaseTarget(t, n) {
    this.baseTarget[t] = n;
  }
  getBaseTarget(t) {
    var s;
    const { initial: n } = this.props;
    let r;
    if (typeof n == "string" || typeof n == "object") {
      const o = qu(
        this.props,
        n,
        (s = this.presenceContext) == null ? void 0 : s.custom,
      );
      o && (r = o[t]);
    }
    if (n && r !== void 0) return r;
    const i = this.getBaseTargetFromProps(this.props, t);
    return i !== void 0 && !me(i)
      ? i
      : this.initialValues[t] !== void 0 && r === void 0
        ? void 0
        : this.baseTarget[t];
  }
  on(t, n) {
    return (
      this.events[t] || (this.events[t] = new zu()),
      this.events[t].add(n)
    );
  }
  notify(t, ...n) {
    this.events[t] && this.events[t].notify(...n);
  }
  scheduleRenderMicrotask() {
    tc.render(this.render);
  }
}
class Eg extends Fw {
  constructor() {
    (super(...arguments), (this.KeyframeResolver = fw));
  }
  sortInstanceNodePosition(t, n) {
    return t.compareDocumentPosition(n) & 2 ? 1 : -1;
  }
  getBaseTargetFromProps(t, n) {
    const r = t.style;
    return r ? r[n] : void 0;
  }
  removeValueFromRenderState(t, { vars: n, style: r }) {
    (delete n[t], delete r[t]);
  }
  handleChildMotionValue() {
    this.childSubscription &&
      (this.childSubscription(), delete this.childSubscription);
    const { children: t } = this.props;
    me(t) &&
      (this.childSubscription = t.on("change", (n) => {
        this.current && (this.current.textContent = `${n}`);
      }));
  }
}
class hn {
  constructor(t) {
    ((this.isMounted = !1), (this.node = t));
  }
  update() {}
}
function Mg({ top: e, left: t, right: n, bottom: r }) {
  return { x: { min: t, max: n }, y: { min: e, max: r } };
}
function zw({ x: e, y: t }) {
  return { top: t.min, right: e.max, bottom: t.max, left: e.min };
}
function _w(e, t) {
  if (!t) return e;
  const n = t({ x: e.left, y: e.top }),
    r = t({ x: e.right, y: e.bottom });
  return { top: n.y, left: n.x, bottom: r.y, right: r.x };
}
function da(e) {
  return e === void 0 || e === 1;
}
function Il({ scale: e, scaleX: t, scaleY: n }) {
  return !da(e) || !da(t) || !da(n);
}
function xn(e) {
  return (
    Il(e) ||
    Ag(e) ||
    e.z ||
    e.rotate ||
    e.rotateX ||
    e.rotateY ||
    e.skewX ||
    e.skewY
  );
}
function Ag(e) {
  return tf(e.x) || tf(e.y);
}
function tf(e) {
  return e && e !== "0%";
}
function no(e, t, n) {
  const r = e - n,
    i = t * r;
  return n + i;
}
function nf(e, t, n, r, i) {
  return (i !== void 0 && (e = no(e, i, r)), no(e, n, r) + t);
}
function Vl(e, t = 0, n = 1, r, i) {
  ((e.min = nf(e.min, t, n, r, i)), (e.max = nf(e.max, t, n, r, i)));
}
function Lg(e, { x: t, y: n }) {
  (Vl(e.x, t.translate, t.scale, t.originPoint),
    Vl(e.y, n.translate, n.scale, n.originPoint));
}
const rf = 0.999999999999,
  sf = 1.0000000000001;
function Ww(e, t, n, r = !1) {
  var l;
  const i = n.length;
  if (!i) return;
  t.x = t.y = 1;
  let s, o;
  for (let u = 0; u < i; u++) {
    ((s = n[u]), (o = s.projectionDelta));
    const { visualElement: c } = s.options;
    (c && c.props.style && c.props.style.display === "contents") ||
      (r &&
        s.options.layoutScroll &&
        s.scroll &&
        s !== s.root &&
        (xt(e.x, -s.scroll.offset.x), xt(e.y, -s.scroll.offset.y)),
      o && ((t.x *= o.x.scale), (t.y *= o.y.scale), Lg(e, o)),
      r &&
        xn(s.latestValues) &&
        xs(e, s.latestValues, (l = s.layout) == null ? void 0 : l.layoutBox));
  }
  (t.x < sf && t.x > rf && (t.x = 1), t.y < sf && t.y > rf && (t.y = 1));
}
function xt(e, t) {
  ((e.min += t), (e.max += t));
}
function of(e, t, n, r, i = 0.5) {
  const s = K(e.min, e.max, i);
  Vl(e, t, n, s, r);
}
function af(e, t) {
  return typeof e == "string" ? (parseFloat(e) / 100) * (t.max - t.min) : e;
}
function xs(e, t, n) {
  const r = n ?? e;
  (of(e.x, af(t.x, r.x), t.scaleX, t.scale, t.originX),
    of(e.y, af(t.y, r.y), t.scaleY, t.scale, t.originY));
}
function Rg(e, t) {
  return Mg(_w(e.getBoundingClientRect(), t));
}
function Uw(e, t, n) {
  const r = Rg(e, n),
    { scroll: i } = t;
  return (i && (xt(r.x, i.offset.x), xt(r.y, i.offset.y)), r);
}
const Hw = {
    x: "translateX",
    y: "translateY",
    z: "translateZ",
    transformPerspective: "perspective",
  },
  $w = jr.length;
function Kw(e, t, n) {
  let r = "",
    i = !0;
  for (let s = 0; s < $w; s++) {
    const o = jr[s],
      l = e[o];
    if (l === void 0) continue;
    let u = !0;
    if (typeof l == "number") u = l === (o.startsWith("scale") ? 1 : 0);
    else {
      const c = parseFloat(l);
      u = o.startsWith("scale") ? c === 1 : c === 0;
    }
    if (!u || n) {
      const c = kg(l, ec[o]);
      if (!u) {
        i = !1;
        const d = Hw[o] || o;
        r += `${d}(${c}) `;
      }
      n && (t[o] = c);
    }
  }
  return ((r = r.trim()), n ? (r = n(t, i ? "" : r)) : i && (r = "none"), r);
}
function oc(e, t, n) {
  const { style: r, vars: i, transformOrigin: s } = e;
  let o = !1,
    l = !1;
  for (const u in t) {
    const c = t[u];
    if (Sr.has(u)) {
      o = !0;
      continue;
    } else if (Um(u)) {
      i[u] = c;
      continue;
    } else {
      const d = kg(c, ec[u]);
      u.startsWith("origin") ? ((l = !0), (s[u] = d)) : (r[u] = d);
    }
  }
  if (
    (t.transform ||
      (o || n
        ? (r.transform = Kw(t, e.transform, n))
        : r.transform && (r.transform = "none")),
    l)
  ) {
    const { originX: u = "50%", originY: c = "50%", originZ: d = 0 } = s;
    r.transformOrigin = `${u} ${c} ${d}`;
  }
}
function Dg(e, { style: t, vars: n }, r, i) {
  const s = e.style;
  let o;
  for (o in t) s[o] = t[o];
  i == null || i.applyProjectionStyles(s, r);
  for (o in n) s.setProperty(o, n[o]);
}
function lf(e, t) {
  return t.max === t.min ? 0 : (e / (t.max - t.min)) * 100;
}
const Lr = {
    correct: (e, t) => {
      if (!t.target) return e;
      if (typeof e == "string")
        if (A.test(e)) e = parseFloat(e);
        else return e;
      const n = lf(e, t.target.x),
        r = lf(e, t.target.y);
      return `${n}% ${r}%`;
    },
  },
  Gw = {
    correct: (e, { treeScale: t, projectionDelta: n }) => {
      const r = e,
        i = ht.parse(e);
      if (i.length > 5) return r;
      const s = ht.createTransformer(e),
        o = typeof i[0] != "number" ? 1 : 0,
        l = n.x.scale * t.x,
        u = n.y.scale * t.y;
      ((i[0 + o] /= l), (i[1 + o] /= u));
      const c = K(l, u, 0.5);
      return (
        typeof i[2 + o] == "number" && (i[2 + o] /= c),
        typeof i[3 + o] == "number" && (i[3 + o] /= c),
        s(i)
      );
    },
  },
  Bl = {
    borderRadius: {
      ...Lr,
      applyTo: [
        "borderTopLeftRadius",
        "borderTopRightRadius",
        "borderBottomLeftRadius",
        "borderBottomRightRadius",
      ],
    },
    borderTopLeftRadius: Lr,
    borderTopRightRadius: Lr,
    borderBottomLeftRadius: Lr,
    borderBottomRightRadius: Lr,
    boxShadow: Gw,
  };
function Ig(e, { layout: t, layoutId: n }) {
  return (
    Sr.has(e) ||
    e.startsWith("origin") ||
    ((t || n !== void 0) && (!!Bl[e] || e === "opacity"))
  );
}
function ac(e, t, n) {
  var o;
  const r = e.style,
    i = t == null ? void 0 : t.style,
    s = {};
  if (!r) return s;
  for (const l in r)
    (me(r[l]) ||
      (i && me(i[l])) ||
      Ig(l, e) ||
      ((o = n == null ? void 0 : n.getValue(l)) == null
        ? void 0
        : o.liveStyle) !== void 0) &&
      (s[l] = r[l]);
  return s;
}
function Yw(e) {
  return window.getComputedStyle(e);
}
class Xw extends Eg {
  constructor() {
    (super(...arguments), (this.type = "html"), (this.renderInstance = Dg));
  }
  readValueFromInstance(t, n) {
    var r;
    if (Sr.has(n))
      return (r = this.projection) != null && r.isProjecting ? Sl(n) : p2(t, n);
    {
      const i = Yw(t),
        s = (Um(n) ? i.getPropertyValue(n) : i[n]) || 0;
      return typeof s == "string" ? s.trim() : s;
    }
  }
  measureInstanceViewportBox(t, { transformPagePoint: n }) {
    return Rg(t, n);
  }
  build(t, n, r) {
    oc(t, n, r.transformTemplate);
  }
  scrapeMotionValuesFromProps(t, n, r) {
    return ac(t, n, r);
  }
}
const Qw = { offset: "stroke-dashoffset", array: "stroke-dasharray" },
  Zw = { offset: "strokeDashoffset", array: "strokeDasharray" };
function qw(e, t, n = 1, r = 0, i = !0) {
  e.pathLength = 1;
  const s = i ? Qw : Zw;
  ((e[s.offset] = `${-r}`), (e[s.array] = `${t} ${n}`));
}
const Jw = ["offsetDistance", "offsetPath", "offsetRotate", "offsetAnchor"];
function Vg(
  e,
  {
    attrX: t,
    attrY: n,
    attrScale: r,
    pathLength: i,
    pathSpacing: s = 1,
    pathOffset: o = 0,
    ...l
  },
  u,
  c,
  d,
) {
  if ((oc(e, l, c), u)) {
    e.style.viewBox && (e.attrs.viewBox = e.style.viewBox);
    return;
  }
  ((e.attrs = e.style), (e.style = {}));
  const { attrs: f, style: h } = e;
  (f.transform && ((h.transform = f.transform), delete f.transform),
    (h.transform || f.transformOrigin) &&
      ((h.transformOrigin = f.transformOrigin ?? "50% 50%"),
      delete f.transformOrigin),
    h.transform &&
      ((h.transformBox = (d == null ? void 0 : d.transformBox) ?? "fill-box"),
      delete f.transformBox));
  for (const m of Jw) f[m] !== void 0 && ((h[m] = f[m]), delete f[m]);
  (t !== void 0 && (f.x = t),
    n !== void 0 && (f.y = n),
    r !== void 0 && (f.scale = r),
    i !== void 0 && qw(f, i, s, o, !1));
}
const Bg = new Set([
    "baseFrequency",
    "diffuseConstant",
    "kernelMatrix",
    "kernelUnitLength",
    "keySplines",
    "keyTimes",
    "limitingConeAngle",
    "markerHeight",
    "markerWidth",
    "numOctaves",
    "targetX",
    "targetY",
    "surfaceScale",
    "specularConstant",
    "specularExponent",
    "stdDeviation",
    "tableValues",
    "viewBox",
    "gradientTransform",
    "pathLength",
    "startOffset",
    "textLength",
    "lengthAdjust",
  ]),
  Og = (e) => typeof e == "string" && e.toLowerCase() === "svg";
function e4(e, t, n, r) {
  Dg(e, t, void 0, r);
  for (const i in t.attrs) e.setAttribute(Bg.has(i) ? i : Ju(i), t.attrs[i]);
}
function Fg(e, t, n) {
  const r = ac(e, t, n);
  for (const i in e)
    if (me(e[i]) || me(t[i])) {
      const s =
        jr.indexOf(i) !== -1
          ? "attr" + i.charAt(0).toUpperCase() + i.substring(1)
          : i;
      r[s] = e[i];
    }
  return r;
}
class t4 extends Eg {
  constructor() {
    (super(...arguments),
      (this.type = "svg"),
      (this.isSVGTag = !1),
      (this.measureInstanceViewportBox = oe));
  }
  getBaseTargetFromProps(t, n) {
    return t[n];
  }
  readValueFromInstance(t, n) {
    if (Sr.has(n)) {
      const r = vg(n);
      return (r && r.default) || 0;
    }
    return ((n = Bg.has(n) ? n : Ju(n)), t.getAttribute(n));
  }
  scrapeMotionValuesFromProps(t, n, r) {
    return Fg(t, n, r);
  }
  build(t, n, r) {
    Vg(t, n, this.isSVGTag, r.transformTemplate, r.style);
  }
  renderInstance(t, n, r, i) {
    e4(t, n, r, i);
  }
  mount(t) {
    ((this.isSVGTag = Og(t.tagName)), super.mount(t));
  }
}
const n4 = sc.length;
function zg(e) {
  if (!e) return;
  if (!e.isControllingVariants) {
    const n = e.parent ? zg(e.parent) || {} : {};
    return (e.props.initial !== void 0 && (n.initial = e.props.initial), n);
  }
  const t = {};
  for (let n = 0; n < n4; n++) {
    const r = sc[n],
      i = e.props[r];
    (wi(i) || i === !1) && (t[r] = i);
  }
  return t;
}
function _g(e, t) {
  if (!Array.isArray(t)) return !1;
  const n = t.length;
  if (n !== e.length) return !1;
  for (let r = 0; r < n; r++) if (t[r] !== e[r]) return !1;
  return !0;
}
const r4 = [...ic].reverse(),
  i4 = ic.length;
function s4(e) {
  return (t) =>
    Promise.all(t.map(({ animation: n, options: r }) => tw(e, n, r)));
}
function o4(e) {
  let t = s4(e),
    n = uf(),
    r = !0,
    i = !1;
  const s = (c) => (d, f) => {
    var m;
    const h = Nn(
      e,
      f,
      c === "exit"
        ? (m = e.presenceContext) == null
          ? void 0
          : m.custom
        : void 0,
    );
    if (h) {
      const { transition: v, transitionEnd: x, ...k } = h;
      d = { ...d, ...k, ...x };
    }
    return d;
  };
  function o(c) {
    t = c(e);
  }
  function l(c) {
    const { props: d } = e,
      f = zg(e.parent) || {},
      h = [],
      m = new Set();
    let v = {},
      x = 1 / 0;
    for (let g = 0; g < i4; g++) {
      const p = r4[g],
        y = n[p],
        w = d[p] !== void 0 ? d[p] : f[p],
        S = wi(w),
        b = p === c ? y.isActive : null;
      b === !1 && (x = g);
      let P = w === f[p] && w !== d[p] && S;
      if (
        (P && (r || i) && e.manuallyAnimateOnMount && (P = !1),
        (y.protectedKeys = { ...v }),
        (!y.isActive && b === null) ||
          (!w && !y.prevProp) ||
          Po(w) ||
          typeof w == "boolean")
      )
        continue;
      if (p === "exit" && y.isActive && b !== !0) {
        y.prevResolvedValues && (v = { ...v, ...y.prevResolvedValues });
        continue;
      }
      const T = a4(y.prevProp, w);
      let V = T || (p === c && y.isActive && !P && S) || (g > x && S),
        N = !1;
      const O = Array.isArray(w) ? w : [w];
      let ne = O.reduce(s(p), {});
      b === !1 && (ne = {});
      const { prevResolvedValues: Be = {} } = y,
        Oe = { ...Be, ...ne },
        it = (E) => {
          ((V = !0),
            m.has(E) && ((N = !0), m.delete(E)),
            (y.needsAnimating[E] = !0));
          const L = e.getValue(E);
          L && (L.liveStyle = !1);
        };
      for (const E in Oe) {
        const L = ne[E],
          D = Be[E];
        if (v.hasOwnProperty(E)) continue;
        let _ = !1;
        (El(L) && El(D) ? (_ = !_g(L, D)) : (_ = L !== D),
          _
            ? L != null
              ? it(E)
              : m.add(E)
            : L !== void 0 && m.has(E)
              ? it(E)
              : (y.protectedKeys[E] = !0));
      }
      ((y.prevProp = w),
        (y.prevResolvedValues = ne),
        y.isActive && (v = { ...v, ...ne }),
        (r || i) && e.blockInitialAnimation && (V = !1));
      const Me = P && T;
      V &&
        (!Me || N) &&
        h.push(
          ...O.map((E) => {
            const L = { type: p };
            if (
              typeof E == "string" &&
              (r || i) &&
              !Me &&
              e.manuallyAnimateOnMount &&
              e.parent
            ) {
              const { parent: D } = e,
                _ = Nn(D, E);
              if (D.enteringChildren && _) {
                const { delayChildren: re } = _.transition || {};
                L.delay = ug(D.enteringChildren, e, re);
              }
            }
            return { animation: E, options: L };
          }),
        );
    }
    if (m.size) {
      const g = {};
      if (typeof d.initial != "boolean") {
        const p = Nn(e, Array.isArray(d.initial) ? d.initial[0] : d.initial);
        p && p.transition && (g.transition = p.transition);
      }
      (m.forEach((p) => {
        const y = e.getBaseTarget(p),
          w = e.getValue(p);
        (w && (w.liveStyle = !0), (g[p] = y ?? null));
      }),
        h.push({ animation: g }));
    }
    let k = !!h.length;
    return (
      r &&
        (d.initial === !1 || d.initial === d.animate) &&
        !e.manuallyAnimateOnMount &&
        (k = !1),
      (r = !1),
      (i = !1),
      k ? t(h) : Promise.resolve()
    );
  }
  function u(c, d) {
    var h;
    if (n[c].isActive === d) return Promise.resolve();
    ((h = e.variantChildren) == null ||
      h.forEach((m) => {
        var v;
        return (v = m.animationState) == null ? void 0 : v.setActive(c, d);
      }),
      (n[c].isActive = d));
    const f = l(c);
    for (const m in n) n[m].protectedKeys = {};
    return f;
  }
  return {
    animateChanges: l,
    setActive: u,
    setAnimateFunction: o,
    getState: () => n,
    reset: () => {
      ((n = uf()), (i = !0));
    },
  };
}
function a4(e, t) {
  return typeof t == "string" ? t !== e : Array.isArray(t) ? !_g(t, e) : !1;
}
function gn(e = !1) {
  return {
    isActive: e,
    protectedKeys: {},
    needsAnimating: {},
    prevResolvedValues: {},
  };
}
function uf() {
  return {
    animate: gn(!0),
    whileInView: gn(),
    whileHover: gn(),
    whileTap: gn(),
    whileDrag: gn(),
    whileFocus: gn(),
    exit: gn(),
  };
}
function Ol(e, t) {
  ((e.min = t.min), (e.max = t.max));
}
function ot(e, t) {
  (Ol(e.x, t.x), Ol(e.y, t.y));
}
function cf(e, t) {
  ((e.translate = t.translate),
    (e.scale = t.scale),
    (e.originPoint = t.originPoint),
    (e.origin = t.origin));
}
const Wg = 1e-4,
  l4 = 1 - Wg,
  u4 = 1 + Wg,
  Ug = 0.01,
  c4 = 0 - Ug,
  d4 = 0 + Ug;
function Te(e) {
  return e.max - e.min;
}
function f4(e, t, n) {
  return Math.abs(e - t) <= n;
}
function df(e, t, n, r = 0.5) {
  ((e.origin = r),
    (e.originPoint = K(t.min, t.max, e.origin)),
    (e.scale = Te(n) / Te(t)),
    (e.translate = K(n.min, n.max, e.origin) - e.originPoint),
    ((e.scale >= l4 && e.scale <= u4) || isNaN(e.scale)) && (e.scale = 1),
    ((e.translate >= c4 && e.translate <= d4) || isNaN(e.translate)) &&
      (e.translate = 0));
}
function Zr(e, t, n, r) {
  (df(e.x, t.x, n.x, r ? r.originX : void 0),
    df(e.y, t.y, n.y, r ? r.originY : void 0));
}
function ff(e, t, n, r = 0) {
  const i = r ? K(n.min, n.max, r) : n.min;
  ((e.min = i + t.min), (e.max = e.min + Te(t)));
}
function h4(e, t, n, r) {
  (ff(e.x, t.x, n.x, r == null ? void 0 : r.x),
    ff(e.y, t.y, n.y, r == null ? void 0 : r.y));
}
function hf(e, t, n, r = 0) {
  const i = r ? K(n.min, n.max, r) : n.min;
  ((e.min = t.min - i), (e.max = e.min + Te(t)));
}
function ro(e, t, n, r) {
  (hf(e.x, t.x, n.x, r == null ? void 0 : r.x),
    hf(e.y, t.y, n.y, r == null ? void 0 : r.y));
}
function pf(e, t, n, r, i) {
  return (
    (e -= t),
    (e = no(e, 1 / n, r)),
    i !== void 0 && (e = no(e, 1 / i, r)),
    e
  );
}
function p4(e, t = 0, n = 1, r = 0.5, i, s = e, o = e) {
  if (
    (St.test(t) &&
      ((t = parseFloat(t)), (t = K(o.min, o.max, t / 100) - o.min)),
    typeof t != "number")
  )
    return;
  let l = K(s.min, s.max, r);
  (e === s && (l -= t),
    (e.min = pf(e.min, t, n, l, i)),
    (e.max = pf(e.max, t, n, l, i)));
}
function mf(e, t, [n, r, i], s, o) {
  p4(e, t[n], t[r], t[i], t.scale, s, o);
}
const m4 = ["x", "scaleX", "originX"],
  g4 = ["y", "scaleY", "originY"];
function gf(e, t, n, r) {
  (mf(e.x, t, m4, n ? n.x : void 0, r ? r.x : void 0),
    mf(e.y, t, g4, n ? n.y : void 0, r ? r.y : void 0));
}
function yf(e) {
  return e.translate === 0 && e.scale === 1;
}
function Hg(e) {
  return yf(e.x) && yf(e.y);
}
function vf(e, t) {
  return e.min === t.min && e.max === t.max;
}
function y4(e, t) {
  return vf(e.x, t.x) && vf(e.y, t.y);
}
function xf(e, t) {
  return (
    Math.round(e.min) === Math.round(t.min) &&
    Math.round(e.max) === Math.round(t.max)
  );
}
function $g(e, t) {
  return xf(e.x, t.x) && xf(e.y, t.y);
}
function wf(e) {
  return Te(e.x) / Te(e.y);
}
function kf(e, t) {
  return (
    e.translate === t.translate &&
    e.scale === t.scale &&
    e.originPoint === t.originPoint
  );
}
function vt(e) {
  return [e("x"), e("y")];
}
function v4(e, t, n) {
  let r = "";
  const i = e.x.translate / t.x,
    s = e.y.translate / t.y,
    o = (n == null ? void 0 : n.z) || 0;
  if (
    ((i || s || o) && (r = `translate3d(${i}px, ${s}px, ${o}px) `),
    (t.x !== 1 || t.y !== 1) && (r += `scale(${1 / t.x}, ${1 / t.y}) `),
    n)
  ) {
    const {
      transformPerspective: c,
      rotate: d,
      rotateX: f,
      rotateY: h,
      skewX: m,
      skewY: v,
    } = n;
    (c && (r = `perspective(${c}px) ${r}`),
      d && (r += `rotate(${d}deg) `),
      f && (r += `rotateX(${f}deg) `),
      h && (r += `rotateY(${h}deg) `),
      m && (r += `skewX(${m}deg) `),
      v && (r += `skewY(${v}deg) `));
  }
  const l = e.x.scale * t.x,
    u = e.y.scale * t.y;
  return ((l !== 1 || u !== 1) && (r += `scale(${l}, ${u})`), r || "none");
}
const Kg = [
    "borderTopLeftRadius",
    "borderTopRightRadius",
    "borderBottomLeftRadius",
    "borderBottomRightRadius",
  ],
  x4 = Kg.length,
  jf = (e) => (typeof e == "string" ? parseFloat(e) : e),
  Sf = (e) => typeof e == "number" || A.test(e);
function w4(e, t, n, r, i, s) {
  i
    ? ((e.opacity = K(0, n.opacity ?? 1, k4(r))),
      (e.opacityExit = K(t.opacity ?? 1, 0, j4(r))))
    : s && (e.opacity = K(t.opacity ?? 1, n.opacity ?? 1, r));
  for (let o = 0; o < x4; o++) {
    const l = Kg[o];
    let u = bf(t, l),
      c = bf(n, l);
    if (u === void 0 && c === void 0) continue;
    (u || (u = 0),
      c || (c = 0),
      u === 0 || c === 0 || Sf(u) === Sf(c)
        ? ((e[l] = Math.max(K(jf(u), jf(c), r), 0)),
          (St.test(c) || St.test(u)) && (e[l] += "%"))
        : (e[l] = c));
  }
  (t.rotate || n.rotate) && (e.rotate = K(t.rotate || 0, n.rotate || 0, r));
}
function bf(e, t) {
  return e[t] !== void 0 ? e[t] : e.borderRadius;
}
const k4 = Gg(0, 0.5, Bm),
  j4 = Gg(0.5, 0.95, et);
function Gg(e, t, n) {
  return (r) => (r < e ? 0 : r > t ? 1 : n(vi(e, t, r)));
}
function S4(e, t, n) {
  const r = me(e) ? e : gr(e);
  return (r.start(Zu("", r, t, n)), r.animation);
}
function ki(e, t, n, r = { passive: !0 }) {
  return (e.addEventListener(t, n, r), () => e.removeEventListener(t, n));
}
const b4 = (e, t) => e.depth - t.depth;
class C4 {
  constructor() {
    ((this.children = []), (this.isDirty = !1));
  }
  add(t) {
    (Ou(this.children, t), (this.isDirty = !0));
  }
  remove(t) {
    (Qs(this.children, t), (this.isDirty = !0));
  }
  forEach(t) {
    (this.isDirty && this.children.sort(b4),
      (this.isDirty = !1),
      this.children.forEach(t));
  }
}
function T4(e, t) {
  const n = Ce.now(),
    r = ({ timestamp: i }) => {
      const s = i - n;
      s >= t && (ln(r), e(s - t));
    };
  return (U.setup(r, !0), () => ln(r));
}
function ws(e) {
  return me(e) ? e.get() : e;
}
class P4 {
  constructor() {
    this.members = [];
  }
  add(t) {
    Ou(this.members, t);
    for (let n = this.members.length - 1; n >= 0; n--) {
      const r = this.members[n];
      if (r === t || r === this.lead || r === this.prevLead) continue;
      const i = r.instance;
      (!i || i.isConnected === !1) &&
        !r.snapshot &&
        (Qs(this.members, r), r.unmount());
    }
    t.scheduleRender();
  }
  remove(t) {
    if (
      (Qs(this.members, t),
      t === this.prevLead && (this.prevLead = void 0),
      t === this.lead)
    ) {
      const n = this.members[this.members.length - 1];
      n && this.promote(n);
    }
  }
  relegate(t) {
    var n;
    for (let r = this.members.indexOf(t) - 1; r >= 0; r--) {
      const i = this.members[r];
      if (
        i.isPresent !== !1 &&
        ((n = i.instance) == null ? void 0 : n.isConnected) !== !1
      )
        return (this.promote(i), !0);
    }
    return !1;
  }
  promote(t, n) {
    var i;
    const r = this.lead;
    if (t !== r && ((this.prevLead = r), (this.lead = t), t.show(), r)) {
      (r.updateSnapshot(), t.scheduleRender());
      const { layoutDependency: s } = r.options,
        { layoutDependency: o } = t.options;
      ((s === void 0 || s !== o) &&
        ((t.resumeFrom = r),
        n && (r.preserveOpacity = !0),
        r.snapshot &&
          ((t.snapshot = r.snapshot),
          (t.snapshot.latestValues = r.animationValues || r.latestValues)),
        (i = t.root) != null && i.isUpdating && (t.isLayoutDirty = !0)),
        t.options.crossfade === !1 && r.hide());
    }
  }
  exitAnimationComplete() {
    this.members.forEach((t) => {
      var n, r, i, s, o;
      ((r = (n = t.options).onExitComplete) == null || r.call(n),
        (o =
          (i = t.resumingFrom) == null
            ? void 0
            : (s = i.options).onExitComplete) == null || o.call(s));
    });
  }
  scheduleRender() {
    this.members.forEach((t) => t.instance && t.scheduleRender(!1));
  }
  removeLeadSnapshot() {
    var t;
    (t = this.lead) != null && t.snapshot && (this.lead.snapshot = void 0);
  }
}
const ks = { hasAnimatedSinceResize: !0, hasEverUpdated: !1 },
  fa = ["", "X", "Y", "Z"],
  N4 = 1e3;
let E4 = 0;
function ha(e, t, n, r) {
  const { latestValues: i } = t;
  i[e] && ((n[e] = i[e]), t.setStaticValue(e, 0), r && (r[e] = 0));
}
function Yg(e) {
  if (((e.hasCheckedOptimisedAppear = !0), e.root === e)) return;
  const { visualElement: t } = e.options;
  if (!t) return;
  const n = pg(t);
  if (window.MotionHasOptimisedAnimation(n, "transform")) {
    const { layout: i, layoutId: s } = e.options;
    window.MotionCancelOptimisedAnimation(n, "transform", U, !(i || s));
  }
  const { parent: r } = e;
  r && !r.hasCheckedOptimisedAppear && Yg(r);
}
function Xg({
  attachResizeListener: e,
  defaultParent: t,
  measureScroll: n,
  checkIsScrollRoot: r,
  resetTransform: i,
}) {
  return class {
    constructor(o = {}, l = t == null ? void 0 : t()) {
      ((this.id = E4++),
        (this.animationId = 0),
        (this.animationCommitId = 0),
        (this.children = new Set()),
        (this.options = {}),
        (this.isTreeAnimating = !1),
        (this.isAnimationBlocked = !1),
        (this.isLayoutDirty = !1),
        (this.isProjectionDirty = !1),
        (this.isSharedProjectionDirty = !1),
        (this.isTransformDirty = !1),
        (this.updateManuallyBlocked = !1),
        (this.updateBlockedByResize = !1),
        (this.isUpdating = !1),
        (this.isSVG = !1),
        (this.needsReset = !1),
        (this.shouldResetTransform = !1),
        (this.hasCheckedOptimisedAppear = !1),
        (this.treeScale = { x: 1, y: 1 }),
        (this.eventHandlers = new Map()),
        (this.hasTreeAnimated = !1),
        (this.layoutVersion = 0),
        (this.updateScheduled = !1),
        (this.scheduleUpdate = () => this.update()),
        (this.projectionUpdateScheduled = !1),
        (this.checkUpdateFailed = () => {
          this.isUpdating && ((this.isUpdating = !1), this.clearAllSnapshots());
        }),
        (this.updateProjection = () => {
          ((this.projectionUpdateScheduled = !1),
            this.nodes.forEach(L4),
            this.nodes.forEach(O4),
            this.nodes.forEach(F4),
            this.nodes.forEach(R4));
        }),
        (this.resolvedRelativeTargetAt = 0),
        (this.linkedParentVersion = 0),
        (this.hasProjected = !1),
        (this.isVisible = !0),
        (this.animationProgress = 0),
        (this.sharedNodes = new Map()),
        (this.latestValues = o),
        (this.root = l ? l.root || l : this),
        (this.path = l ? [...l.path, l] : []),
        (this.parent = l),
        (this.depth = l ? l.depth + 1 : 0));
      for (let u = 0; u < this.path.length; u++)
        this.path[u].shouldResetTransform = !0;
      this.root === this && (this.nodes = new C4());
    }
    addEventListener(o, l) {
      return (
        this.eventHandlers.has(o) || this.eventHandlers.set(o, new zu()),
        this.eventHandlers.get(o).add(l)
      );
    }
    notifyListeners(o, ...l) {
      const u = this.eventHandlers.get(o);
      u && u.notify(...l);
    }
    hasListeners(o) {
      return this.eventHandlers.has(o);
    }
    mount(o) {
      if (this.instance) return;
      ((this.isSVG = rc(o) && !Aw(o)), (this.instance = o));
      const { layoutId: l, layout: u, visualElement: c } = this.options;
      if (
        (c && !c.current && c.mount(o),
        this.root.nodes.add(this),
        this.parent && this.parent.children.add(this),
        this.root.hasTreeAnimated && (u || l) && (this.isLayoutDirty = !0),
        e)
      ) {
        let d,
          f = 0;
        const h = () => (this.root.updateBlockedByResize = !1);
        (U.read(() => {
          f = window.innerWidth;
        }),
          e(o, () => {
            const m = window.innerWidth;
            m !== f &&
              ((f = m),
              (this.root.updateBlockedByResize = !0),
              d && d(),
              (d = T4(h, 250)),
              ks.hasAnimatedSinceResize &&
                ((ks.hasAnimatedSinceResize = !1), this.nodes.forEach(Pf)));
          }));
      }
      (l && this.root.registerSharedNode(l, this),
        this.options.animate !== !1 &&
          c &&
          (l || u) &&
          this.addEventListener(
            "didUpdate",
            ({
              delta: d,
              hasLayoutChanged: f,
              hasRelativeLayoutChanged: h,
              layout: m,
            }) => {
              if (this.isTreeAnimationBlocked()) {
                ((this.target = void 0), (this.relativeTarget = void 0));
                return;
              }
              const v =
                  this.options.transition || c.getDefaultTransition() || H4,
                { onLayoutAnimationStart: x, onLayoutAnimationComplete: k } =
                  c.getProps(),
                g = !this.targetLayout || !$g(this.targetLayout, m),
                p = !f && h;
              if (
                this.options.layoutRoot ||
                this.resumeFrom ||
                p ||
                (f && (g || !this.currentAnimation))
              ) {
                this.resumeFrom &&
                  ((this.resumingFrom = this.resumeFrom),
                  (this.resumingFrom.resumingFrom = void 0));
                const y = { ...Qu(v, "layout"), onPlay: x, onComplete: k };
                ((c.shouldReduceMotion || this.options.layoutRoot) &&
                  ((y.delay = 0), (y.type = !1)),
                  this.startAnimation(y),
                  this.setAnimationOrigin(d, p));
              } else
                (f || Pf(this),
                  this.isLead() &&
                    this.options.onExitComplete &&
                    this.options.onExitComplete());
              this.targetLayout = m;
            },
          ));
    }
    unmount() {
      (this.options.layoutId && this.willUpdate(),
        this.root.nodes.remove(this));
      const o = this.getStack();
      (o && o.remove(this),
        this.parent && this.parent.children.delete(this),
        (this.instance = void 0),
        this.eventHandlers.clear(),
        ln(this.updateProjection));
    }
    blockUpdate() {
      this.updateManuallyBlocked = !0;
    }
    unblockUpdate() {
      this.updateManuallyBlocked = !1;
    }
    isUpdateBlocked() {
      return this.updateManuallyBlocked || this.updateBlockedByResize;
    }
    isTreeAnimationBlocked() {
      return (
        this.isAnimationBlocked ||
        (this.parent && this.parent.isTreeAnimationBlocked()) ||
        !1
      );
    }
    startUpdate() {
      this.isUpdateBlocked() ||
        ((this.isUpdating = !0),
        this.nodes && this.nodes.forEach(z4),
        this.animationId++);
    }
    getTransformTemplate() {
      const { visualElement: o } = this.options;
      return o && o.getProps().transformTemplate;
    }
    willUpdate(o = !0) {
      if (((this.root.hasTreeAnimated = !0), this.root.isUpdateBlocked())) {
        this.options.onExitComplete && this.options.onExitComplete();
        return;
      }
      if (
        (window.MotionCancelOptimisedAnimation &&
          !this.hasCheckedOptimisedAppear &&
          Yg(this),
        !this.root.isUpdating && this.root.startUpdate(),
        this.isLayoutDirty)
      )
        return;
      this.isLayoutDirty = !0;
      for (let d = 0; d < this.path.length; d++) {
        const f = this.path[d];
        ((f.shouldResetTransform = !0),
          (typeof f.latestValues.x == "string" ||
            typeof f.latestValues.y == "string") &&
            (f.isLayoutDirty = !0),
          f.updateScroll("snapshot"),
          f.options.layoutRoot && f.willUpdate(!1));
      }
      const { layoutId: l, layout: u } = this.options;
      if (l === void 0 && !u) return;
      const c = this.getTransformTemplate();
      ((this.prevTransformTemplateValue = c
        ? c(this.latestValues, "")
        : void 0),
        this.updateSnapshot(),
        o && this.notifyListeners("willUpdate"));
    }
    update() {
      if (((this.updateScheduled = !1), this.isUpdateBlocked())) {
        const u = this.updateBlockedByResize;
        (this.unblockUpdate(),
          (this.updateBlockedByResize = !1),
          this.clearAllSnapshots(),
          u && this.nodes.forEach(I4),
          this.nodes.forEach(Cf));
        return;
      }
      if (this.animationId <= this.animationCommitId) {
        this.nodes.forEach(Tf);
        return;
      }
      ((this.animationCommitId = this.animationId),
        this.isUpdating
          ? ((this.isUpdating = !1),
            this.nodes.forEach(V4),
            this.nodes.forEach(B4),
            this.nodes.forEach(M4),
            this.nodes.forEach(A4))
          : this.nodes.forEach(Tf),
        this.clearAllSnapshots());
      const l = Ce.now();
      ((pe.delta = bt(0, 1e3 / 60, l - pe.timestamp)),
        (pe.timestamp = l),
        (pe.isProcessing = !0),
        ia.update.process(pe),
        ia.preRender.process(pe),
        ia.render.process(pe),
        (pe.isProcessing = !1));
    }
    didUpdate() {
      this.updateScheduled ||
        ((this.updateScheduled = !0), tc.read(this.scheduleUpdate));
    }
    clearAllSnapshots() {
      (this.nodes.forEach(D4), this.sharedNodes.forEach(_4));
    }
    scheduleUpdateProjection() {
      this.projectionUpdateScheduled ||
        ((this.projectionUpdateScheduled = !0),
        U.preRender(this.updateProjection, !1, !0));
    }
    scheduleCheckAfterUnmount() {
      U.postRender(() => {
        this.isLayoutDirty
          ? this.root.didUpdate()
          : this.root.checkUpdateFailed();
      });
    }
    updateSnapshot() {
      this.snapshot ||
        !this.instance ||
        ((this.snapshot = this.measure()),
        this.snapshot &&
          !Te(this.snapshot.measuredBox.x) &&
          !Te(this.snapshot.measuredBox.y) &&
          (this.snapshot = void 0));
    }
    updateLayout() {
      if (
        !this.instance ||
        (this.updateScroll(),
        !(this.options.alwaysMeasureLayout && this.isLead()) &&
          !this.isLayoutDirty)
      )
        return;
      if (this.resumeFrom && !this.resumeFrom.instance)
        for (let u = 0; u < this.path.length; u++) this.path[u].updateScroll();
      const o = this.layout;
      ((this.layout = this.measure(!1)),
        this.layoutVersion++,
        this.layoutCorrected || (this.layoutCorrected = oe()),
        (this.isLayoutDirty = !1),
        (this.projectionDelta = void 0),
        this.notifyListeners("measure", this.layout.layoutBox));
      const { visualElement: l } = this.options;
      l &&
        l.notify(
          "LayoutMeasure",
          this.layout.layoutBox,
          o ? o.layoutBox : void 0,
        );
    }
    updateScroll(o = "measure") {
      let l = !!(this.options.layoutScroll && this.instance);
      if (
        (this.scroll &&
          this.scroll.animationId === this.root.animationId &&
          this.scroll.phase === o &&
          (l = !1),
        l && this.instance)
      ) {
        const u = r(this.instance);
        this.scroll = {
          animationId: this.root.animationId,
          phase: o,
          isRoot: u,
          offset: n(this.instance),
          wasRoot: this.scroll ? this.scroll.isRoot : u,
        };
      }
    }
    resetTransform() {
      if (!i) return;
      const o =
          this.isLayoutDirty ||
          this.shouldResetTransform ||
          this.options.alwaysMeasureLayout,
        l = this.projectionDelta && !Hg(this.projectionDelta),
        u = this.getTransformTemplate(),
        c = u ? u(this.latestValues, "") : void 0,
        d = c !== this.prevTransformTemplateValue;
      o &&
        this.instance &&
        (l || xn(this.latestValues) || d) &&
        (i(this.instance, c),
        (this.shouldResetTransform = !1),
        this.scheduleRender());
    }
    measure(o = !0) {
      const l = this.measurePageBox();
      let u = this.removeElementScroll(l);
      return (
        o && (u = this.removeTransform(u)),
        $4(u),
        {
          animationId: this.root.animationId,
          measuredBox: l,
          layoutBox: u,
          latestValues: {},
          source: this.id,
        }
      );
    }
    measurePageBox() {
      var c;
      const { visualElement: o } = this.options;
      if (!o) return oe();
      const l = o.measureViewportBox();
      if (!(
        ((c = this.scroll) == null ? void 0 : c.wasRoot) || this.path.some(K4)
      )) {
        const { scroll: d } = this.root;
        d && (xt(l.x, d.offset.x), xt(l.y, d.offset.y));
      }
      return l;
    }
    removeElementScroll(o) {
      var u;
      const l = oe();
      if ((ot(l, o), (u = this.scroll) != null && u.wasRoot)) return l;
      for (let c = 0; c < this.path.length; c++) {
        const d = this.path[c],
          { scroll: f, options: h } = d;
        d !== this.root &&
          f &&
          h.layoutScroll &&
          (f.wasRoot && ot(l, o), xt(l.x, f.offset.x), xt(l.y, f.offset.y));
      }
      return l;
    }
    applyTransform(o, l = !1, u) {
      var d, f;
      const c = u || oe();
      ot(c, o);
      for (let h = 0; h < this.path.length; h++) {
        const m = this.path[h];
        (!l &&
          m.options.layoutScroll &&
          m.scroll &&
          m !== m.root &&
          (xt(c.x, -m.scroll.offset.x), xt(c.y, -m.scroll.offset.y)),
          xn(m.latestValues) &&
            xs(
              c,
              m.latestValues,
              (d = m.layout) == null ? void 0 : d.layoutBox,
            ));
      }
      return (
        xn(this.latestValues) &&
          xs(
            c,
            this.latestValues,
            (f = this.layout) == null ? void 0 : f.layoutBox,
          ),
        c
      );
    }
    removeTransform(o) {
      var u;
      const l = oe();
      ot(l, o);
      for (let c = 0; c < this.path.length; c++) {
        const d = this.path[c];
        if (!xn(d.latestValues)) continue;
        let f;
        (d.instance &&
          (Il(d.latestValues) && d.updateSnapshot(),
          (f = oe()),
          ot(f, d.measurePageBox())),
          gf(
            l,
            d.latestValues,
            (u = d.snapshot) == null ? void 0 : u.layoutBox,
            f,
          ));
      }
      return (xn(this.latestValues) && gf(l, this.latestValues), l);
    }
    setTargetDelta(o) {
      ((this.targetDelta = o),
        this.root.scheduleUpdateProjection(),
        (this.isProjectionDirty = !0));
    }
    setOptions(o) {
      this.options = {
        ...this.options,
        ...o,
        crossfade: o.crossfade !== void 0 ? o.crossfade : !0,
      };
    }
    clearMeasurements() {
      ((this.scroll = void 0),
        (this.layout = void 0),
        (this.snapshot = void 0),
        (this.prevTransformTemplateValue = void 0),
        (this.targetDelta = void 0),
        (this.target = void 0),
        (this.isLayoutDirty = !1));
    }
    forceRelativeParentToResolveTarget() {
      this.relativeParent &&
        this.relativeParent.resolvedRelativeTargetAt !== pe.timestamp &&
        this.relativeParent.resolveTargetDelta(!0);
    }
    resolveTargetDelta(o = !1) {
      var m;
      const l = this.getLead();
      (this.isProjectionDirty || (this.isProjectionDirty = l.isProjectionDirty),
        this.isTransformDirty || (this.isTransformDirty = l.isTransformDirty),
        this.isSharedProjectionDirty ||
          (this.isSharedProjectionDirty = l.isSharedProjectionDirty));
      const u = !!this.resumingFrom || this !== l;
      if (!(
        o ||
        (u && this.isSharedProjectionDirty) ||
        this.isProjectionDirty ||
        ((m = this.parent) != null && m.isProjectionDirty) ||
        this.attemptToResolveRelativeTarget ||
        this.root.updateBlockedByResize
      ))
        return;
      const { layout: d, layoutId: f } = this.options;
      if (!this.layout || !(d || f)) return;
      this.resolvedRelativeTargetAt = pe.timestamp;
      const h = this.getClosestProjectingParent();
      (h &&
        this.linkedParentVersion !== h.layoutVersion &&
        !h.options.layoutRoot &&
        this.removeRelativeTarget(),
        !this.targetDelta &&
          !this.relativeTarget &&
          (this.options.layoutAnchor !== !1 && h && h.layout
            ? this.createRelativeTarget(
                h,
                this.layout.layoutBox,
                h.layout.layoutBox,
              )
            : this.removeRelativeTarget()),
        !(!this.relativeTarget && !this.targetDelta) &&
          (this.target ||
            ((this.target = oe()), (this.targetWithTransforms = oe())),
          this.relativeTarget &&
          this.relativeTargetOrigin &&
          this.relativeParent &&
          this.relativeParent.target
            ? (this.forceRelativeParentToResolveTarget(),
              h4(
                this.target,
                this.relativeTarget,
                this.relativeParent.target,
                this.options.layoutAnchor || void 0,
              ))
            : this.targetDelta
              ? (this.resumingFrom
                  ? this.applyTransform(this.layout.layoutBox, !1, this.target)
                  : ot(this.target, this.layout.layoutBox),
                Lg(this.target, this.targetDelta))
              : ot(this.target, this.layout.layoutBox),
          this.attemptToResolveRelativeTarget &&
            ((this.attemptToResolveRelativeTarget = !1),
            this.options.layoutAnchor !== !1 &&
            h &&
            !!h.resumingFrom == !!this.resumingFrom &&
            !h.options.layoutScroll &&
            h.target &&
            this.animationProgress !== 1
              ? this.createRelativeTarget(h, this.target, h.target)
              : (this.relativeParent = this.relativeTarget = void 0))));
    }
    getClosestProjectingParent() {
      if (!(
        !this.parent ||
        Il(this.parent.latestValues) ||
        Ag(this.parent.latestValues)
      ))
        return this.parent.isProjecting()
          ? this.parent
          : this.parent.getClosestProjectingParent();
    }
    isProjecting() {
      return !!(
        (this.relativeTarget || this.targetDelta || this.options.layoutRoot) &&
        this.layout
      );
    }
    createRelativeTarget(o, l, u) {
      ((this.relativeParent = o),
        (this.linkedParentVersion = o.layoutVersion),
        this.forceRelativeParentToResolveTarget(),
        (this.relativeTarget = oe()),
        (this.relativeTargetOrigin = oe()),
        ro(
          this.relativeTargetOrigin,
          l,
          u,
          this.options.layoutAnchor || void 0,
        ),
        ot(this.relativeTarget, this.relativeTargetOrigin));
    }
    removeRelativeTarget() {
      this.relativeParent = this.relativeTarget = void 0;
    }
    calcProjection() {
      var v;
      const o = this.getLead(),
        l = !!this.resumingFrom || this !== o;
      let u = !0;
      if (
        ((this.isProjectionDirty ||
          ((v = this.parent) != null && v.isProjectionDirty)) &&
          (u = !1),
        l &&
          (this.isSharedProjectionDirty || this.isTransformDirty) &&
          (u = !1),
        this.resolvedRelativeTargetAt === pe.timestamp && (u = !1),
        u)
      )
        return;
      const { layout: c, layoutId: d } = this.options;
      if (
        ((this.isTreeAnimating = !!(
          (this.parent && this.parent.isTreeAnimating) ||
          this.currentAnimation ||
          this.pendingAnimation
        )),
        this.isTreeAnimating ||
          (this.targetDelta = this.relativeTarget = void 0),
        !this.layout || !(c || d))
      )
        return;
      ot(this.layoutCorrected, this.layout.layoutBox);
      const f = this.treeScale.x,
        h = this.treeScale.y;
      (Ww(this.layoutCorrected, this.treeScale, this.path, l),
        o.layout &&
          !o.target &&
          (this.treeScale.x !== 1 || this.treeScale.y !== 1) &&
          ((o.target = o.layout.layoutBox), (o.targetWithTransforms = oe())));
      const { target: m } = o;
      if (!m) {
        this.prevProjectionDelta &&
          (this.createProjectionDeltas(), this.scheduleRender());
        return;
      }
      (!this.projectionDelta || !this.prevProjectionDelta
        ? this.createProjectionDeltas()
        : (cf(this.prevProjectionDelta.x, this.projectionDelta.x),
          cf(this.prevProjectionDelta.y, this.projectionDelta.y)),
        Zr(this.projectionDelta, this.layoutCorrected, m, this.latestValues),
        (this.treeScale.x !== f ||
          this.treeScale.y !== h ||
          !kf(this.projectionDelta.x, this.prevProjectionDelta.x) ||
          !kf(this.projectionDelta.y, this.prevProjectionDelta.y)) &&
          ((this.hasProjected = !0),
          this.scheduleRender(),
          this.notifyListeners("projectionUpdate", m)));
    }
    hide() {
      this.isVisible = !1;
    }
    show() {
      this.isVisible = !0;
    }
    scheduleRender(o = !0) {
      var l;
      if (((l = this.options.visualElement) == null || l.scheduleRender(), o)) {
        const u = this.getStack();
        u && u.scheduleRender();
      }
      this.resumingFrom &&
        !this.resumingFrom.instance &&
        (this.resumingFrom = void 0);
    }
    createProjectionDeltas() {
      ((this.prevProjectionDelta = er()),
        (this.projectionDelta = er()),
        (this.projectionDeltaWithTransform = er()));
    }
    setAnimationOrigin(o, l = !1) {
      const u = this.snapshot,
        c = u ? u.latestValues : {},
        d = { ...this.latestValues },
        f = er();
      ((!this.relativeParent || !this.relativeParent.options.layoutRoot) &&
        (this.relativeTarget = this.relativeTargetOrigin = void 0),
        (this.attemptToResolveRelativeTarget = !l));
      const h = oe(),
        m = u ? u.source : void 0,
        v = this.layout ? this.layout.source : void 0,
        x = m !== v,
        k = this.getStack(),
        g = !k || k.members.length <= 1,
        p = !!(x && !g && this.options.crossfade === !0 && !this.path.some(U4));
      this.animationProgress = 0;
      let y;
      ((this.mixTargetDelta = (w) => {
        const S = w / 1e3;
        (Nf(f.x, o.x, S),
          Nf(f.y, o.y, S),
          this.setTargetDelta(f),
          this.relativeTarget &&
            this.relativeTargetOrigin &&
            this.layout &&
            this.relativeParent &&
            this.relativeParent.layout &&
            (ro(
              h,
              this.layout.layoutBox,
              this.relativeParent.layout.layoutBox,
              this.options.layoutAnchor || void 0,
            ),
            W4(this.relativeTarget, this.relativeTargetOrigin, h, S),
            y && y4(this.relativeTarget, y) && (this.isProjectionDirty = !1),
            y || (y = oe()),
            ot(y, this.relativeTarget)),
          x &&
            ((this.animationValues = d), w4(d, c, this.latestValues, S, p, g)),
          this.root.scheduleUpdateProjection(),
          this.scheduleRender(),
          (this.animationProgress = S));
      }),
        this.mixTargetDelta(this.options.layoutRoot ? 1e3 : 0));
    }
    startAnimation(o) {
      var l, u, c;
      (this.notifyListeners("animationStart"),
        (l = this.currentAnimation) == null || l.stop(),
        (c = (u = this.resumingFrom) == null ? void 0 : u.currentAnimation) ==
          null || c.stop(),
        this.pendingAnimation &&
          (ln(this.pendingAnimation), (this.pendingAnimation = void 0)),
        (this.pendingAnimation = U.update(() => {
          ((ks.hasAnimatedSinceResize = !0),
            this.motionValue || (this.motionValue = gr(0)),
            this.motionValue.jump(0, !1),
            (this.currentAnimation = S4(this.motionValue, [0, 1e3], {
              ...o,
              velocity: 0,
              isSync: !0,
              onUpdate: (d) => {
                (this.mixTargetDelta(d), o.onUpdate && o.onUpdate(d));
              },
              onStop: () => {},
              onComplete: () => {
                (o.onComplete && o.onComplete(), this.completeAnimation());
              },
            })),
            this.resumingFrom &&
              (this.resumingFrom.currentAnimation = this.currentAnimation),
            (this.pendingAnimation = void 0));
        })));
    }
    completeAnimation() {
      this.resumingFrom &&
        ((this.resumingFrom.currentAnimation = void 0),
        (this.resumingFrom.preserveOpacity = void 0));
      const o = this.getStack();
      (o && o.exitAnimationComplete(),
        (this.resumingFrom =
          this.currentAnimation =
          this.animationValues =
            void 0),
        this.notifyListeners("animationComplete"));
    }
    finishAnimation() {
      (this.currentAnimation &&
        (this.mixTargetDelta && this.mixTargetDelta(N4),
        this.currentAnimation.stop()),
        this.completeAnimation());
    }
    applyTransformsToTarget() {
      const o = this.getLead();
      let {
        targetWithTransforms: l,
        target: u,
        layout: c,
        latestValues: d,
      } = o;
      if (!(!l || !u || !c)) {
        if (
          this !== o &&
          this.layout &&
          c &&
          Qg(this.options.animationType, this.layout.layoutBox, c.layoutBox)
        ) {
          u = this.target || oe();
          const f = Te(this.layout.layoutBox.x);
          ((u.x.min = o.target.x.min), (u.x.max = u.x.min + f));
          const h = Te(this.layout.layoutBox.y);
          ((u.y.min = o.target.y.min), (u.y.max = u.y.min + h));
        }
        (ot(l, u),
          xs(l, d),
          Zr(this.projectionDeltaWithTransform, this.layoutCorrected, l, d));
      }
    }
    registerSharedNode(o, l) {
      (this.sharedNodes.has(o) || this.sharedNodes.set(o, new P4()),
        this.sharedNodes.get(o).add(l));
      const c = l.options.initialPromotionConfig;
      l.promote({
        transition: c ? c.transition : void 0,
        preserveFollowOpacity:
          c && c.shouldPreserveFollowOpacity
            ? c.shouldPreserveFollowOpacity(l)
            : void 0,
      });
    }
    isLead() {
      const o = this.getStack();
      return o ? o.lead === this : !0;
    }
    getLead() {
      var l;
      const { layoutId: o } = this.options;
      return o
        ? ((l = this.getStack()) == null ? void 0 : l.lead) || this
        : this;
    }
    getPrevLead() {
      var l;
      const { layoutId: o } = this.options;
      return o ? ((l = this.getStack()) == null ? void 0 : l.prevLead) : void 0;
    }
    getStack() {
      const { layoutId: o } = this.options;
      if (o) return this.root.sharedNodes.get(o);
    }
    promote({ needsReset: o, transition: l, preserveFollowOpacity: u } = {}) {
      const c = this.getStack();
      (c && c.promote(this, u),
        o && ((this.projectionDelta = void 0), (this.needsReset = !0)),
        l && this.setOptions({ transition: l }));
    }
    relegate() {
      const o = this.getStack();
      return o ? o.relegate(this) : !1;
    }
    resetSkewAndRotation() {
      const { visualElement: o } = this.options;
      if (!o) return;
      let l = !1;
      const { latestValues: u } = o;
      if (
        ((u.z ||
          u.rotate ||
          u.rotateX ||
          u.rotateY ||
          u.rotateZ ||
          u.skewX ||
          u.skewY) &&
          (l = !0),
        !l)
      )
        return;
      const c = {};
      u.z && ha("z", o, c, this.animationValues);
      for (let d = 0; d < fa.length; d++)
        (ha(`rotate${fa[d]}`, o, c, this.animationValues),
          ha(`skew${fa[d]}`, o, c, this.animationValues));
      o.render();
      for (const d in c)
        (o.setStaticValue(d, c[d]),
          this.animationValues && (this.animationValues[d] = c[d]));
      o.scheduleRender();
    }
    applyProjectionStyles(o, l) {
      if (!this.instance || this.isSVG) return;
      if (!this.isVisible) {
        o.visibility = "hidden";
        return;
      }
      const u = this.getTransformTemplate();
      if (this.needsReset) {
        ((this.needsReset = !1),
          (o.visibility = ""),
          (o.opacity = ""),
          (o.pointerEvents = ws(l == null ? void 0 : l.pointerEvents) || ""),
          (o.transform = u ? u(this.latestValues, "") : "none"));
        return;
      }
      const c = this.getLead();
      if (!this.projectionDelta || !this.layout || !c.target) {
        (this.options.layoutId &&
          ((o.opacity =
            this.latestValues.opacity !== void 0
              ? this.latestValues.opacity
              : 1),
          (o.pointerEvents = ws(l == null ? void 0 : l.pointerEvents) || "")),
          this.hasProjected &&
            !xn(this.latestValues) &&
            ((o.transform = u ? u({}, "") : "none"), (this.hasProjected = !1)));
        return;
      }
      o.visibility = "";
      const d = c.animationValues || c.latestValues;
      this.applyTransformsToTarget();
      let f = v4(this.projectionDeltaWithTransform, this.treeScale, d);
      (u && (f = u(d, f)), (o.transform = f));
      const { x: h, y: m } = this.projectionDelta;
      ((o.transformOrigin = `${h.origin * 100}% ${m.origin * 100}% 0`),
        c.animationValues
          ? (o.opacity =
              c === this
                ? (d.opacity ?? this.latestValues.opacity ?? 1)
                : this.preserveOpacity
                  ? this.latestValues.opacity
                  : d.opacityExit)
          : (o.opacity =
              c === this
                ? d.opacity !== void 0
                  ? d.opacity
                  : ""
                : d.opacityExit !== void 0
                  ? d.opacityExit
                  : 0));
      for (const v in Bl) {
        if (d[v] === void 0) continue;
        const { correct: x, applyTo: k, isCSSVariable: g } = Bl[v],
          p = f === "none" ? d[v] : x(d[v], c);
        if (k) {
          const y = k.length;
          for (let w = 0; w < y; w++) o[k[w]] = p;
        } else
          g ? (this.options.visualElement.renderState.vars[v] = p) : (o[v] = p);
      }
      this.options.layoutId &&
        (o.pointerEvents =
          c === this ? ws(l == null ? void 0 : l.pointerEvents) || "" : "none");
    }
    clearSnapshot() {
      this.resumeFrom = this.snapshot = void 0;
    }
    resetTree() {
      (this.root.nodes.forEach((o) => {
        var l;
        return (l = o.currentAnimation) == null ? void 0 : l.stop();
      }),
        this.root.nodes.forEach(Cf),
        this.root.sharedNodes.clear());
    }
  };
}
function M4(e) {
  e.updateLayout();
}
function A4(e) {
  var n;
  const t = ((n = e.resumeFrom) == null ? void 0 : n.snapshot) || e.snapshot;
  if (e.isLead() && e.layout && t && e.hasListeners("didUpdate")) {
    const { layoutBox: r, measuredBox: i } = e.layout,
      { animationType: s } = e.options,
      o = t.source !== e.layout.source;
    if (s === "size")
      vt((f) => {
        const h = o ? t.measuredBox[f] : t.layoutBox[f],
          m = Te(h);
        ((h.min = r[f].min), (h.max = h.min + m));
      });
    else if (s === "x" || s === "y") {
      const f = s === "x" ? "y" : "x";
      Ol(o ? t.measuredBox[f] : t.layoutBox[f], r[f]);
    } else
      Qg(s, t.layoutBox, r) &&
        vt((f) => {
          const h = o ? t.measuredBox[f] : t.layoutBox[f],
            m = Te(r[f]);
          ((h.max = h.min + m),
            e.relativeTarget &&
              !e.currentAnimation &&
              ((e.isProjectionDirty = !0),
              (e.relativeTarget[f].max = e.relativeTarget[f].min + m)));
        });
    const l = er();
    Zr(l, r, t.layoutBox);
    const u = er();
    o ? Zr(u, e.applyTransform(i, !0), t.measuredBox) : Zr(u, r, t.layoutBox);
    const c = !Hg(l);
    let d = !1;
    if (!e.resumeFrom) {
      const f = e.getClosestProjectingParent();
      if (f && !f.resumeFrom) {
        const { snapshot: h, layout: m } = f;
        if (h && m) {
          const v = e.options.layoutAnchor || void 0,
            x = oe();
          ro(x, t.layoutBox, h.layoutBox, v);
          const k = oe();
          (ro(k, r, m.layoutBox, v),
            $g(x, k) || (d = !0),
            f.options.layoutRoot &&
              ((e.relativeTarget = k),
              (e.relativeTargetOrigin = x),
              (e.relativeParent = f)));
        }
      }
    }
    e.notifyListeners("didUpdate", {
      layout: r,
      snapshot: t,
      delta: u,
      layoutDelta: l,
      hasLayoutChanged: c,
      hasRelativeLayoutChanged: d,
    });
  } else if (e.isLead()) {
    const { onExitComplete: r } = e.options;
    r && r();
  }
  e.options.transition = void 0;
}
function L4(e) {
  e.parent &&
    (e.isProjecting() || (e.isProjectionDirty = e.parent.isProjectionDirty),
    e.isSharedProjectionDirty ||
      (e.isSharedProjectionDirty = !!(
        e.isProjectionDirty ||
        e.parent.isProjectionDirty ||
        e.parent.isSharedProjectionDirty
      )),
    e.isTransformDirty || (e.isTransformDirty = e.parent.isTransformDirty));
}
function R4(e) {
  e.isProjectionDirty = e.isSharedProjectionDirty = e.isTransformDirty = !1;
}
function D4(e) {
  e.clearSnapshot();
}
function Cf(e) {
  e.clearMeasurements();
}
function I4(e) {
  ((e.isLayoutDirty = !0), e.updateLayout());
}
function Tf(e) {
  e.isLayoutDirty = !1;
}
function V4(e) {
  e.isAnimationBlocked &&
    e.layout &&
    !e.isLayoutDirty &&
    ((e.snapshot = e.layout), (e.isLayoutDirty = !0));
}
function B4(e) {
  const { visualElement: t } = e.options;
  (t && t.getProps().onBeforeLayoutMeasure && t.notify("BeforeLayoutMeasure"),
    e.resetTransform());
}
function Pf(e) {
  (e.finishAnimation(),
    (e.targetDelta = e.relativeTarget = e.target = void 0),
    (e.isProjectionDirty = !0));
}
function O4(e) {
  e.resolveTargetDelta();
}
function F4(e) {
  e.calcProjection();
}
function z4(e) {
  e.resetSkewAndRotation();
}
function _4(e) {
  e.removeLeadSnapshot();
}
function Nf(e, t, n) {
  ((e.translate = K(t.translate, 0, n)),
    (e.scale = K(t.scale, 1, n)),
    (e.origin = t.origin),
    (e.originPoint = t.originPoint));
}
function Ef(e, t, n, r) {
  ((e.min = K(t.min, n.min, r)), (e.max = K(t.max, n.max, r)));
}
function W4(e, t, n, r) {
  (Ef(e.x, t.x, n.x, r), Ef(e.y, t.y, n.y, r));
}
function U4(e) {
  return e.animationValues && e.animationValues.opacityExit !== void 0;
}
const H4 = { duration: 0.45, ease: [0.4, 0, 0.1, 1] },
  Mf = (e) =>
    typeof navigator < "u" &&
    navigator.userAgent &&
    navigator.userAgent.toLowerCase().includes(e),
  Af = Mf("applewebkit/") && !Mf("chrome/") ? Math.round : et;
function Lf(e) {
  ((e.min = Af(e.min)), (e.max = Af(e.max)));
}
function $4(e) {
  (Lf(e.x), Lf(e.y));
}
function Qg(e, t, n) {
  return (
    e === "position" || (e === "preserve-aspect" && !f4(wf(t), wf(n), 0.2))
  );
}
function K4(e) {
  var t;
  return e !== e.root && ((t = e.scroll) == null ? void 0 : t.wasRoot);
}
const G4 = Xg({
    attachResizeListener: (e, t) => ki(e, "resize", t),
    measureScroll: () => {
      var e, t;
      return {
        x:
          document.documentElement.scrollLeft ||
          ((e = document.body) == null ? void 0 : e.scrollLeft) ||
          0,
        y:
          document.documentElement.scrollTop ||
          ((t = document.body) == null ? void 0 : t.scrollTop) ||
          0,
      };
    },
    checkIsScrollRoot: () => !0,
  }),
  pa = { current: void 0 },
  Zg = Xg({
    measureScroll: (e) => ({ x: e.scrollLeft, y: e.scrollTop }),
    defaultParent: () => {
      if (!pa.current) {
        const e = new G4({});
        (e.mount(window), e.setOptions({ layoutScroll: !0 }), (pa.current = e));
      }
      return pa.current;
    },
    resetTransform: (e, t) => {
      e.style.transform = t !== void 0 ? t : "none";
    },
    checkIsScrollRoot: (e) => window.getComputedStyle(e).position === "fixed",
  }),
  qg = j.createContext({
    transformPagePoint: (e) => e,
    isStatic: !1,
    reducedMotion: "never",
  });
function Y4(e = !0) {
  const t = j.useContext(Bu);
  if (t === null) return [!0, null];
  const { isPresent: n, onExitComplete: r, register: i } = t,
    s = j.useId();
  j.useEffect(() => {
    if (e) return i(s);
  }, [e]);
  const o = j.useCallback(() => e && r && r(s), [s, r, e]);
  return !n && r ? [!1, o] : [!0];
}
const Jg = j.createContext({ strict: !1 }),
  Rf = {
    animation: [
      "animate",
      "variants",
      "whileHover",
      "whileTap",
      "exit",
      "whileInView",
      "whileFocus",
      "whileDrag",
    ],
    exit: ["exit"],
    drag: ["drag", "dragControls"],
    focus: ["whileFocus"],
    hover: ["whileHover", "onHoverStart", "onHoverEnd"],
    tap: ["whileTap", "onTap", "onTapStart", "onTapCancel"],
    pan: ["onPan", "onPanStart", "onPanSessionStart", "onPanEnd"],
    inView: ["whileInView", "onViewportEnter", "onViewportLeave"],
    layout: ["layout", "layoutId"],
  };
let Df = !1;
function X4() {
  if (Df) return;
  const e = {};
  for (const t in Rf) e[t] = { isEnabled: (n) => Rf[t].some((r) => !!n[r]) };
  (Ng(e), (Df = !0));
}
function ey() {
  return (X4(), Ow());
}
function Q4(e) {
  const t = ey();
  for (const n in e) t[n] = { ...t[n], ...e[n] };
  Ng(t);
}
const Z4 = new Set([
  "animate",
  "exit",
  "variants",
  "initial",
  "style",
  "values",
  "variants",
  "transition",
  "transformTemplate",
  "custom",
  "inherit",
  "onBeforeLayoutMeasure",
  "onAnimationStart",
  "onAnimationComplete",
  "onUpdate",
  "onDragStart",
  "onDrag",
  "onDragEnd",
  "onMeasureDragConstraints",
  "onDirectionLock",
  "onDragTransitionEnd",
  "_dragX",
  "_dragY",
  "onHoverStart",
  "onHoverEnd",
  "onViewportEnter",
  "onViewportLeave",
  "globalTapTarget",
  "propagate",
  "ignoreStrict",
  "viewport",
]);
function io(e) {
  return (
    e.startsWith("while") ||
    (e.startsWith("drag") && e !== "draggable") ||
    e.startsWith("layout") ||
    e.startsWith("onTap") ||
    e.startsWith("onPan") ||
    e.startsWith("onLayout") ||
    Z4.has(e)
  );
}
let ty = (e) => !io(e);
function q4(e) {
  typeof e == "function" && (ty = (t) => (t.startsWith("on") ? !io(t) : e(t)));
}
try {
  q4(require("@emotion/is-prop-valid").default);
} catch {}
function J4(e, t, n) {
  const r = {};
  for (const i in e)
    (i === "values" && typeof e.values == "object") ||
      me(e[i]) ||
      ((ty(i) ||
        (n === !0 && io(i)) ||
        (!t && !io(i)) ||
        (e.draggable && i.startsWith("onDrag"))) &&
        (r[i] = e[i]));
  return r;
}
const Eo = j.createContext({});
function e3(e, t) {
  if (No(e)) {
    const { initial: n, animate: r } = e;
    return {
      initial: n === !1 || wi(n) ? n : void 0,
      animate: wi(r) ? r : void 0,
    };
  }
  return e.inherit !== !1 ? t : {};
}
function t3(e) {
  const { initial: t, animate: n } = e3(e, j.useContext(Eo));
  return j.useMemo(() => ({ initial: t, animate: n }), [If(t), If(n)]);
}
function If(e) {
  return Array.isArray(e) ? e.join(" ") : e;
}
const lc = () => ({ style: {}, transform: {}, transformOrigin: {}, vars: {} });
function ny(e, t, n) {
  for (const r in t) !me(t[r]) && !Ig(r, n) && (e[r] = t[r]);
}
function n3({ transformTemplate: e }, t) {
  return j.useMemo(() => {
    const n = lc();
    return (oc(n, t, e), Object.assign({}, n.vars, n.style));
  }, [t]);
}
function r3(e, t) {
  const n = e.style || {},
    r = {};
  return (ny(r, n, e), Object.assign(r, n3(e, t)), r);
}
function i3(e, t) {
  const n = {},
    r = r3(e, t);
  return (
    e.drag &&
      e.dragListener !== !1 &&
      ((n.draggable = !1),
      (r.userSelect = r.WebkitUserSelect = r.WebkitTouchCallout = "none"),
      (r.touchAction =
        e.drag === !0 ? "none" : `pan-${e.drag === "x" ? "y" : "x"}`)),
    e.tabIndex === void 0 &&
      (e.onTap || e.onTapStart || e.whileTap) &&
      (n.tabIndex = 0),
    (n.style = r),
    n
  );
}
const ry = () => ({ ...lc(), attrs: {} });
function s3(e, t, n, r) {
  const i = j.useMemo(() => {
    const s = ry();
    return (
      Vg(s, t, Og(r), e.transformTemplate, e.style),
      { ...s.attrs, style: { ...s.style } }
    );
  }, [t]);
  if (e.style) {
    const s = {};
    (ny(s, e.style, e), (i.style = { ...s, ...i.style }));
  }
  return i;
}
const o3 = [
  "animate",
  "circle",
  "defs",
  "desc",
  "ellipse",
  "g",
  "image",
  "line",
  "filter",
  "marker",
  "mask",
  "metadata",
  "path",
  "pattern",
  "polygon",
  "polyline",
  "rect",
  "stop",
  "switch",
  "symbol",
  "svg",
  "text",
  "tspan",
  "use",
  "view",
];
function uc(e) {
  return typeof e != "string" || e.includes("-")
    ? !1
    : !!(o3.indexOf(e) > -1 || /[A-Z]/u.test(e));
}
function a3(e, t, n, { latestValues: r }, i, s = !1, o) {
  const u = ((o ?? uc(e)) ? s3 : i3)(t, r, i, e),
    c = J4(t, typeof e == "string", s),
    d = e !== j.Fragment ? { ...c, ...u, ref: n } : {},
    { children: f } = t,
    h = j.useMemo(() => (me(f) ? f.get() : f), [f]);
  return j.createElement(e, { ...d, children: h });
}
function l3({ scrapeMotionValuesFromProps: e, createRenderState: t }, n, r, i) {
  return { latestValues: u3(n, r, i, e), renderState: t() };
}
function u3(e, t, n, r) {
  const i = {},
    s = r(e, {});
  for (const h in s) i[h] = ws(s[h]);
  let { initial: o, animate: l } = e;
  const u = No(e),
    c = Tg(e);
  t &&
    c &&
    !u &&
    e.inherit !== !1 &&
    (o === void 0 && (o = t.initial), l === void 0 && (l = t.animate));
  let d = n ? n.initial === !1 : !1;
  d = d || o === !1;
  const f = d ? l : o;
  if (f && typeof f != "boolean" && !Po(f)) {
    const h = Array.isArray(f) ? f : [f];
    for (let m = 0; m < h.length; m++) {
      const v = qu(e, h[m]);
      if (v) {
        const { transitionEnd: x, transition: k, ...g } = v;
        for (const p in g) {
          let y = g[p];
          if (Array.isArray(y)) {
            const w = d ? y.length - 1 : 0;
            y = y[w];
          }
          y !== null && (i[p] = y);
        }
        for (const p in x) i[p] = x[p];
      }
    }
  }
  return i;
}
const iy = (e) => (t, n) => {
    const r = j.useContext(Eo),
      i = j.useContext(Bu),
      s = () => l3(e, t, r, i);
    return n ? s() : ox(s);
  },
  c3 = iy({ scrapeMotionValuesFromProps: ac, createRenderState: lc }),
  d3 = iy({ scrapeMotionValuesFromProps: Fg, createRenderState: ry }),
  f3 = Symbol.for("motionComponentSymbol");
function h3(e, t, n) {
  const r = j.useRef(n);
  j.useInsertionEffect(() => {
    r.current = n;
  });
  const i = j.useRef(null);
  return j.useCallback(
    (s) => {
      var l;
      s && ((l = e.onMount) == null || l.call(e, s));
      const o = r.current;
      if (typeof o == "function")
        if (s) {
          const u = o(s);
          typeof u == "function" && (i.current = u);
        } else i.current ? (i.current(), (i.current = null)) : o(s);
      else o && (o.current = s);
      t && (s ? t.mount(s) : t.unmount());
    },
    [t],
  );
}
const sy = j.createContext({});
function Fn(e) {
  return (
    e &&
    typeof e == "object" &&
    Object.prototype.hasOwnProperty.call(e, "current")
  );
}
function p3(e, t, n, r, i, s) {
  var y, w;
  const { visualElement: o } = j.useContext(Eo),
    l = j.useContext(Jg),
    u = j.useContext(Bu),
    c = j.useContext(qg),
    d = c.reducedMotion,
    f = c.skipAnimations,
    h = j.useRef(null),
    m = j.useRef(!1);
  ((r = r || l.renderer),
    !h.current &&
      r &&
      ((h.current = r(e, {
        visualState: t,
        parent: o,
        props: n,
        presenceContext: u,
        blockInitialAnimation: u ? u.initial === !1 : !1,
        reducedMotionConfig: d,
        skipAnimations: f,
        isSVG: s,
      })),
      m.current && h.current && (h.current.manuallyAnimateOnMount = !0)));
  const v = h.current,
    x = j.useContext(sy);
  v &&
    !v.projection &&
    i &&
    (v.type === "html" || v.type === "svg") &&
    m3(h.current, n, i, x);
  const k = j.useRef(!1);
  j.useInsertionEffect(() => {
    v && k.current && v.update(n, u);
  });
  const g = n[hg],
    p = j.useRef(
      !!g &&
        typeof window < "u" &&
        !((y = window.MotionHandoffIsComplete) != null && y.call(window, g)) &&
        ((w = window.MotionHasOptimisedAnimation) == null
          ? void 0
          : w.call(window, g)),
    );
  return (
    lx(() => {
      ((m.current = !0),
        v &&
          ((k.current = !0),
          (window.MotionIsMounted = !0),
          v.updateFeatures(),
          v.scheduleRenderMicrotask(),
          p.current && v.animationState && v.animationState.animateChanges()));
    }),
    j.useEffect(() => {
      v &&
        (!p.current && v.animationState && v.animationState.animateChanges(),
        p.current &&
          (queueMicrotask(() => {
            var S;
            (S = window.MotionHandoffMarkAsComplete) == null ||
              S.call(window, g);
          }),
          (p.current = !1)),
        (v.enteringChildren = void 0));
    }),
    v
  );
}
function m3(e, t, n, r) {
  const {
    layoutId: i,
    layout: s,
    drag: o,
    dragConstraints: l,
    layoutScroll: u,
    layoutRoot: c,
    layoutAnchor: d,
    layoutCrossfade: f,
  } = t;
  ((e.projection = new n(
    e.latestValues,
    t["data-framer-portal-id"] ? void 0 : oy(e.parent),
  )),
    e.projection.setOptions({
      layoutId: i,
      layout: s,
      alwaysMeasureLayout: !!o || (l && Fn(l)),
      visualElement: e,
      animationType: typeof s == "string" ? s : "both",
      initialPromotionConfig: r,
      crossfade: f,
      layoutScroll: u,
      layoutRoot: c,
      layoutAnchor: d,
    }));
}
function oy(e) {
  if (e) return e.options.allowProjection !== !1 ? e.projection : oy(e.parent);
}
function ma(e, { forwardMotionProps: t = !1, type: n } = {}, r, i) {
  r && Q4(r);
  const s = n ? n === "svg" : uc(e),
    o = s ? d3 : c3;
  function l(c, d) {
    let f;
    const h = { ...j.useContext(qg), ...c, layoutId: g3(c) },
      { isStatic: m } = h,
      v = t3(c),
      x = o(c, m);
    if (!m && typeof window < "u") {
      y3();
      const k = v3(h);
      ((f = k.MeasureLayout),
        (v.visualElement = p3(e, x, h, i, k.ProjectionNode, s)));
    }
    return a.jsxs(Eo.Provider, {
      value: v,
      children: [
        f && v.visualElement
          ? a.jsx(f, { visualElement: v.visualElement, ...h })
          : null,
        a3(e, c, h3(x, v.visualElement, d), x, m, t, s),
      ],
    });
  }
  l.displayName = `motion.${typeof e == "string" ? e : `create(${e.displayName ?? e.name ?? ""})`}`;
  const u = j.forwardRef(l);
  return ((u[f3] = e), u);
}
function g3({ layoutId: e }) {
  const t = j.useContext(Cm).id;
  return t && e !== void 0 ? t + "-" + e : e;
}
function y3(e, t) {
  j.useContext(Jg).strict;
}
function v3(e) {
  const t = ey(),
    { drag: n, layout: r } = t;
  if (!n && !r) return {};
  const i = { ...n, ...r };
  return {
    MeasureLayout:
      (n != null && n.isEnabled(e)) || (r != null && r.isEnabled(e))
        ? i.MeasureLayout
        : void 0,
    ProjectionNode: i.ProjectionNode,
  };
}
function x3(e, t) {
  if (typeof Proxy > "u") return ma;
  const n = new Map(),
    r = (s, o) => ma(s, o, e, t),
    i = (s, o) => r(s, o);
  return new Proxy(i, {
    get: (s, o) =>
      o === "create"
        ? r
        : (n.has(o) || n.set(o, ma(o, void 0, e, t)), n.get(o)),
  });
}
const w3 = (e, t) =>
  (t.isSVG ?? uc(e))
    ? new t4(t)
    : new Xw(t, { allowProjection: e !== j.Fragment });
class k3 extends hn {
  constructor(t) {
    (super(t), t.animationState || (t.animationState = o4(t)));
  }
  updateAnimationControlsSubscription() {
    const { animate: t } = this.node.getProps();
    Po(t) && (this.unmountControls = t.subscribe(this.node));
  }
  mount() {
    this.updateAnimationControlsSubscription();
  }
  update() {
    const { animate: t } = this.node.getProps(),
      { animate: n } = this.node.prevProps || {};
    t !== n && this.updateAnimationControlsSubscription();
  }
  unmount() {
    var t;
    (this.node.animationState.reset(),
      (t = this.unmountControls) == null || t.call(this));
  }
}
let j3 = 0;
class S3 extends hn {
  constructor() {
    (super(...arguments), (this.id = j3++), (this.isExitComplete = !1));
  }
  update() {
    var s;
    if (!this.node.presenceContext) return;
    const { isPresent: t, onExitComplete: n } = this.node.presenceContext,
      { isPresent: r } = this.node.prevPresenceContext || {};
    if (!this.node.animationState || t === r) return;
    if (t && r === !1) {
      if (this.isExitComplete) {
        const { initial: o, custom: l } = this.node.getProps();
        if (typeof o == "string") {
          const u = Nn(this.node, o, l);
          if (u) {
            const { transition: c, transitionEnd: d, ...f } = u;
            for (const h in f)
              (s = this.node.getValue(h)) == null || s.jump(f[h]);
          }
        }
        (this.node.animationState.reset(),
          this.node.animationState.animateChanges());
      } else this.node.animationState.setActive("exit", !1);
      this.isExitComplete = !1;
      return;
    }
    const i = this.node.animationState.setActive("exit", !t);
    n &&
      !t &&
      i.then(() => {
        ((this.isExitComplete = !0), n(this.id));
      });
  }
  mount() {
    const { register: t, onExitComplete: n } = this.node.presenceContext || {};
    (n && n(this.id), t && (this.unmount = t(this.id)));
  }
  unmount() {}
}
const b3 = { animation: { Feature: k3 }, exit: { Feature: S3 } };
function Ai(e) {
  return { point: { x: e.pageX, y: e.pageY } };
}
const C3 = (e) => (t) => nc(t) && e(t, Ai(t));
function qr(e, t, n, r) {
  return ki(e, t, C3(n), r);
}
const ay = ({ current: e }) => (e ? e.ownerDocument.defaultView : null),
  Vf = (e, t) => Math.abs(e - t);
function T3(e, t) {
  const n = Vf(e.x, t.x),
    r = Vf(e.y, t.y);
  return Math.sqrt(n ** 2 + r ** 2);
}
const Bf = new Set(["auto", "scroll"]);
class ly {
  constructor(
    t,
    n,
    {
      transformPagePoint: r,
      contextWindow: i = window,
      dragSnapToOrigin: s = !1,
      distanceThreshold: o = 3,
      element: l,
    } = {},
  ) {
    if (
      ((this.startEvent = null),
      (this.lastMoveEvent = null),
      (this.lastMoveEventInfo = null),
      (this.lastRawMoveEventInfo = null),
      (this.handlers = {}),
      (this.contextWindow = window),
      (this.scrollPositions = new Map()),
      (this.removeScrollListeners = null),
      (this.onElementScroll = (m) => {
        this.handleScroll(m.target);
      }),
      (this.onWindowScroll = () => {
        this.handleScroll(window);
      }),
      (this.updatePoint = () => {
        if (!(this.lastMoveEvent && this.lastMoveEventInfo)) return;
        this.lastRawMoveEventInfo &&
          (this.lastMoveEventInfo = es(
            this.lastRawMoveEventInfo,
            this.transformPagePoint,
          ));
        const m = ga(this.lastMoveEventInfo, this.history),
          v = this.startEvent !== null,
          x = T3(m.offset, { x: 0, y: 0 }) >= this.distanceThreshold;
        if (!v && !x) return;
        const { point: k } = m,
          { timestamp: g } = pe;
        this.history.push({ ...k, timestamp: g });
        const { onStart: p, onMove: y } = this.handlers;
        (v ||
          (p && p(this.lastMoveEvent, m),
          (this.startEvent = this.lastMoveEvent)),
          y && y(this.lastMoveEvent, m));
      }),
      (this.handlePointerMove = (m, v) => {
        ((this.lastMoveEvent = m),
          (this.lastRawMoveEventInfo = v),
          (this.lastMoveEventInfo = es(v, this.transformPagePoint)),
          U.update(this.updatePoint, !0));
      }),
      (this.handlePointerUp = (m, v) => {
        this.end();
        const { onEnd: x, onSessionEnd: k, resumeAnimation: g } = this.handlers;
        if (
          ((this.dragSnapToOrigin || !this.startEvent) && g && g(),
          !(this.lastMoveEvent && this.lastMoveEventInfo))
        )
          return;
        const p = ga(
          m.type === "pointercancel"
            ? this.lastMoveEventInfo
            : es(v, this.transformPagePoint),
          this.history,
        );
        (this.startEvent && x && x(m, p), k && k(m, p));
      }),
      !nc(t))
    )
      return;
    ((this.dragSnapToOrigin = s),
      (this.handlers = n),
      (this.transformPagePoint = r),
      (this.distanceThreshold = o),
      (this.contextWindow = i || window));
    const u = Ai(t),
      c = es(u, this.transformPagePoint),
      { point: d } = c,
      { timestamp: f } = pe;
    this.history = [{ ...d, timestamp: f }];
    const { onSessionStart: h } = n;
    (h && h(t, ga(c, this.history)),
      (this.removeListeners = Ni(
        qr(this.contextWindow, "pointermove", this.handlePointerMove),
        qr(this.contextWindow, "pointerup", this.handlePointerUp),
        qr(this.contextWindow, "pointercancel", this.handlePointerUp),
      )),
      l && this.startScrollTracking(l));
  }
  startScrollTracking(t) {
    let n = t.parentElement;
    for (; n;) {
      const r = getComputedStyle(n);
      ((Bf.has(r.overflowX) || Bf.has(r.overflowY)) &&
        this.scrollPositions.set(n, { x: n.scrollLeft, y: n.scrollTop }),
        (n = n.parentElement));
    }
    (this.scrollPositions.set(window, { x: window.scrollX, y: window.scrollY }),
      window.addEventListener("scroll", this.onElementScroll, { capture: !0 }),
      window.addEventListener("scroll", this.onWindowScroll),
      (this.removeScrollListeners = () => {
        (window.removeEventListener("scroll", this.onElementScroll, {
          capture: !0,
        }),
          window.removeEventListener("scroll", this.onWindowScroll));
      }));
  }
  handleScroll(t) {
    const n = this.scrollPositions.get(t);
    if (!n) return;
    const r = t === window,
      i = r
        ? { x: window.scrollX, y: window.scrollY }
        : { x: t.scrollLeft, y: t.scrollTop },
      s = { x: i.x - n.x, y: i.y - n.y };
    (s.x === 0 && s.y === 0) ||
      (r
        ? this.lastMoveEventInfo &&
          ((this.lastMoveEventInfo.point.x += s.x),
          (this.lastMoveEventInfo.point.y += s.y))
        : this.history.length > 0 &&
          ((this.history[0].x -= s.x), (this.history[0].y -= s.y)),
      this.scrollPositions.set(t, i),
      U.update(this.updatePoint, !0));
  }
  updateHandlers(t) {
    this.handlers = t;
  }
  end() {
    (this.removeListeners && this.removeListeners(),
      this.removeScrollListeners && this.removeScrollListeners(),
      this.scrollPositions.clear(),
      ln(this.updatePoint));
  }
}
function es(e, t) {
  return t ? { point: t(e.point) } : e;
}
function Of(e, t) {
  return { x: e.x - t.x, y: e.y - t.y };
}
function ga({ point: e }, t) {
  return {
    point: e,
    delta: Of(e, uy(t)),
    offset: Of(e, P3(t)),
    velocity: N3(t, 0.1),
  };
}
function P3(e) {
  return e[0];
}
function uy(e) {
  return e[e.length - 1];
}
function N3(e, t) {
  if (e.length < 2) return { x: 0, y: 0 };
  let n = e.length - 1,
    r = null;
  const i = uy(e);
  for (; n >= 0 && ((r = e[n]), !(i.timestamp - r.timestamp > Ue(t)));) n--;
  if (!r) return { x: 0, y: 0 };
  r === e[0] &&
    e.length > 2 &&
    i.timestamp - r.timestamp > Ue(t) * 2 &&
    (r = e[1]);
  const s = qe(i.timestamp - r.timestamp);
  if (s === 0) return { x: 0, y: 0 };
  const o = { x: (i.x - r.x) / s, y: (i.y - r.y) / s };
  return (o.x === 1 / 0 && (o.x = 0), o.y === 1 / 0 && (o.y = 0), o);
}
function E3(e, { min: t, max: n }, r) {
  return (
    t !== void 0 && e < t
      ? (e = r ? K(t, e, r.min) : Math.max(e, t))
      : n !== void 0 && e > n && (e = r ? K(n, e, r.max) : Math.min(e, n)),
    e
  );
}
function Ff(e, t, n) {
  return {
    min: t !== void 0 ? e.min + t : void 0,
    max: n !== void 0 ? e.max + n - (e.max - e.min) : void 0,
  };
}
function M3(e, { top: t, left: n, bottom: r, right: i }) {
  return { x: Ff(e.x, n, i), y: Ff(e.y, t, r) };
}
function zf(e, t) {
  let n = t.min - e.min,
    r = t.max - e.max;
  return (
    t.max - t.min < e.max - e.min && ([n, r] = [r, n]),
    { min: n, max: r }
  );
}
function A3(e, t) {
  return { x: zf(e.x, t.x), y: zf(e.y, t.y) };
}
function L3(e, t) {
  let n = 0.5;
  const r = Te(e),
    i = Te(t);
  return (
    i > r
      ? (n = vi(t.min, t.max - r, e.min))
      : r > i && (n = vi(e.min, e.max - i, t.min)),
    bt(0, 1, n)
  );
}
function R3(e, t) {
  const n = {};
  return (
    t.min !== void 0 && (n.min = t.min - e.min),
    t.max !== void 0 && (n.max = t.max - e.min),
    n
  );
}
const Fl = 0.35;
function D3(e = Fl) {
  return (
    e === !1 ? (e = 0) : e === !0 && (e = Fl),
    { x: _f(e, "left", "right"), y: _f(e, "top", "bottom") }
  );
}
function _f(e, t, n) {
  return { min: Wf(e, t), max: Wf(e, n) };
}
function Wf(e, t) {
  return typeof e == "number" ? e : e[t] || 0;
}
const I3 = new WeakMap();
class V3 {
  constructor(t) {
    ((this.openDragLock = null),
      (this.isDragging = !1),
      (this.currentDirection = null),
      (this.originPoint = { x: 0, y: 0 }),
      (this.constraints = !1),
      (this.hasMutatedConstraints = !1),
      (this.elastic = oe()),
      (this.latestPointerEvent = null),
      (this.latestPanInfo = null),
      (this.visualElement = t));
  }
  start(t, { snapToCursor: n = !1, distanceThreshold: r } = {}) {
    const { presenceContext: i } = this.visualElement;
    if (i && i.isPresent === !1) return;
    const s = (f) => {
        (n && this.snapToCursor(Ai(f).point), this.stopAnimation());
      },
      o = (f, h) => {
        const { drag: m, dragPropagation: v, onDragStart: x } = this.getProps();
        if (
          m &&
          !v &&
          (this.openDragLock && this.openDragLock(),
          (this.openDragLock = pw(m)),
          !this.openDragLock)
        )
          return;
        ((this.latestPointerEvent = f),
          (this.latestPanInfo = h),
          (this.isDragging = !0),
          (this.currentDirection = null),
          this.resolveConstraints(),
          this.visualElement.projection &&
            ((this.visualElement.projection.isAnimationBlocked = !0),
            (this.visualElement.projection.target = void 0)),
          vt((g) => {
            let p = this.getAxisMotionValue(g).get() || 0;
            if (St.test(p)) {
              const { projection: y } = this.visualElement;
              if (y && y.layout) {
                const w = y.layout.layoutBox[g];
                w && (p = Te(w) * (parseFloat(p) / 100));
              }
            }
            this.originPoint[g] = p;
          }),
          x && U.update(() => x(f, h), !1, !0),
          Ml(this.visualElement, "transform"));
        const { animationState: k } = this.visualElement;
        k && k.setActive("whileDrag", !0);
      },
      l = (f, h) => {
        ((this.latestPointerEvent = f), (this.latestPanInfo = h));
        const {
          dragPropagation: m,
          dragDirectionLock: v,
          onDirectionLock: x,
          onDrag: k,
        } = this.getProps();
        if (!m && !this.openDragLock) return;
        const { offset: g } = h;
        if (v && this.currentDirection === null) {
          ((this.currentDirection = O3(g)),
            this.currentDirection !== null && x && x(this.currentDirection));
          return;
        }
        (this.updateAxis("x", h.point, g),
          this.updateAxis("y", h.point, g),
          this.visualElement.render(),
          k && U.update(() => k(f, h), !1, !0));
      },
      u = (f, h) => {
        ((this.latestPointerEvent = f),
          (this.latestPanInfo = h),
          this.stop(f, h),
          (this.latestPointerEvent = null),
          (this.latestPanInfo = null));
      },
      c = () => {
        const { dragSnapToOrigin: f } = this.getProps();
        (f || this.constraints) && this.startAnimation({ x: 0, y: 0 });
      },
      { dragSnapToOrigin: d } = this.getProps();
    this.panSession = new ly(
      t,
      {
        onSessionStart: s,
        onStart: o,
        onMove: l,
        onSessionEnd: u,
        resumeAnimation: c,
      },
      {
        transformPagePoint: this.visualElement.getTransformPagePoint(),
        dragSnapToOrigin: d,
        distanceThreshold: r,
        contextWindow: ay(this.visualElement),
        element: this.visualElement.current,
      },
    );
  }
  stop(t, n) {
    const r = t || this.latestPointerEvent,
      i = n || this.latestPanInfo,
      s = this.isDragging;
    if ((this.cancel(), !s || !i || !r)) return;
    const { velocity: o } = i;
    this.startAnimation(o);
    const { onDragEnd: l } = this.getProps();
    l && U.postRender(() => l(r, i));
  }
  cancel() {
    this.isDragging = !1;
    const { projection: t, animationState: n } = this.visualElement;
    (t && (t.isAnimationBlocked = !1), this.endPanSession());
    const { dragPropagation: r } = this.getProps();
    (!r &&
      this.openDragLock &&
      (this.openDragLock(), (this.openDragLock = null)),
      n && n.setActive("whileDrag", !1));
  }
  endPanSession() {
    (this.panSession && this.panSession.end(), (this.panSession = void 0));
  }
  updateAxis(t, n, r) {
    const { drag: i } = this.getProps();
    if (!r || !ts(t, i, this.currentDirection)) return;
    const s = this.getAxisMotionValue(t);
    let o = this.originPoint[t] + r[t];
    (this.constraints &&
      this.constraints[t] &&
      (o = E3(o, this.constraints[t], this.elastic[t])),
      s.set(o));
  }
  resolveConstraints() {
    var s;
    const { dragConstraints: t, dragElastic: n } = this.getProps(),
      r =
        this.visualElement.projection && !this.visualElement.projection.layout
          ? this.visualElement.projection.measure(!1)
          : (s = this.visualElement.projection) == null
            ? void 0
            : s.layout,
      i = this.constraints;
    (t && Fn(t)
      ? this.constraints || (this.constraints = this.resolveRefConstraints())
      : t && r
        ? (this.constraints = M3(r.layoutBox, t))
        : (this.constraints = !1),
      (this.elastic = D3(n)),
      i !== this.constraints &&
        !Fn(t) &&
        r &&
        this.constraints &&
        !this.hasMutatedConstraints &&
        vt((o) => {
          this.constraints !== !1 &&
            this.getAxisMotionValue(o) &&
            (this.constraints[o] = R3(r.layoutBox[o], this.constraints[o]));
        }));
  }
  resolveRefConstraints() {
    const { dragConstraints: t, onMeasureDragConstraints: n } = this.getProps();
    if (!t || !Fn(t)) return !1;
    const r = t.current,
      { projection: i } = this.visualElement;
    if (!i || !i.layout) return !1;
    const s = Uw(r, i.root, this.visualElement.getTransformPagePoint());
    let o = A3(i.layout.layoutBox, s);
    if (n) {
      const l = n(zw(o));
      ((this.hasMutatedConstraints = !!l), l && (o = Mg(l)));
    }
    return o;
  }
  startAnimation(t) {
    const {
        drag: n,
        dragMomentum: r,
        dragElastic: i,
        dragTransition: s,
        dragSnapToOrigin: o,
        onDragTransitionEnd: l,
      } = this.getProps(),
      u = this.constraints || {},
      c = vt((d) => {
        if (!ts(d, n, this.currentDirection)) return;
        let f = (u && u[d]) || {};
        (o === !0 || o === d) && (f = { min: 0, max: 0 });
        const h = i ? 200 : 1e6,
          m = i ? 40 : 1e7,
          v = {
            type: "inertia",
            velocity: r ? t[d] : 0,
            bounceStiffness: h,
            bounceDamping: m,
            timeConstant: 750,
            restDelta: 1,
            restSpeed: 10,
            ...s,
            ...f,
          };
        return this.startAxisValueAnimation(d, v);
      });
    return Promise.all(c).then(l);
  }
  startAxisValueAnimation(t, n) {
    const r = this.getAxisMotionValue(t);
    return (
      Ml(this.visualElement, t),
      r.start(Zu(t, r, 0, n, this.visualElement, !1))
    );
  }
  stopAnimation() {
    vt((t) => this.getAxisMotionValue(t).stop());
  }
  getAxisMotionValue(t) {
    const n = `_drag${t.toUpperCase()}`,
      r = this.visualElement.getProps(),
      i = r[n];
    return (
      i ||
      this.visualElement.getValue(t, (r.initial ? r.initial[t] : void 0) || 0)
    );
  }
  snapToCursor(t) {
    vt((n) => {
      const { drag: r } = this.getProps();
      if (!ts(n, r, this.currentDirection)) return;
      const { projection: i } = this.visualElement,
        s = this.getAxisMotionValue(n);
      if (i && i.layout) {
        const { min: o, max: l } = i.layout.layoutBox[n],
          u = s.get() || 0;
        s.set(t[n] - K(o, l, 0.5) + u);
      }
    });
  }
  scalePositionWithinConstraints() {
    if (!this.visualElement.current) return;
    const { drag: t, dragConstraints: n } = this.getProps(),
      { projection: r } = this.visualElement;
    if (!Fn(n) || !r || !this.constraints) return;
    this.stopAnimation();
    const i = { x: 0, y: 0 };
    vt((o) => {
      const l = this.getAxisMotionValue(o);
      if (l && this.constraints !== !1) {
        const u = l.get();
        i[o] = L3({ min: u, max: u }, this.constraints[o]);
      }
    });
    const { transformTemplate: s } = this.visualElement.getProps();
    ((this.visualElement.current.style.transform = s ? s({}, "") : "none"),
      r.root && r.root.updateScroll(),
      r.updateLayout(),
      (this.constraints = !1),
      this.resolveConstraints(),
      vt((o) => {
        if (!ts(o, t, null)) return;
        const l = this.getAxisMotionValue(o),
          { min: u, max: c } = this.constraints[o];
        l.set(K(u, c, i[o]));
      }),
      this.visualElement.render());
  }
  addListeners() {
    if (!this.visualElement.current) return;
    I3.set(this.visualElement, this);
    const t = this.visualElement.current,
      n = qr(t, "pointerdown", (c) => {
        const { drag: d, dragListener: f = !0 } = this.getProps(),
          h = c.target,
          m = h !== t && ww(h);
        d && f && !m && this.start(c);
      });
    let r;
    const i = () => {
        const { dragConstraints: c } = this.getProps();
        Fn(c) &&
          c.current &&
          ((this.constraints = this.resolveRefConstraints()),
          r ||
            (r = B3(t, c.current, () =>
              this.scalePositionWithinConstraints(),
            )));
      },
      { projection: s } = this.visualElement,
      o = s.addEventListener("measure", i);
    (s && !s.layout && (s.root && s.root.updateScroll(), s.updateLayout()),
      U.read(i));
    const l = ki(window, "resize", () => this.scalePositionWithinConstraints()),
      u = s.addEventListener(
        "didUpdate",
        ({ delta: c, hasLayoutChanged: d }) => {
          this.isDragging &&
            d &&
            (vt((f) => {
              const h = this.getAxisMotionValue(f);
              h &&
                ((this.originPoint[f] += c[f].translate),
                h.set(h.get() + c[f].translate));
            }),
            this.visualElement.render());
        },
      );
    return () => {
      (l(), n(), o(), u && u(), r && r());
    };
  }
  getProps() {
    const t = this.visualElement.getProps(),
      {
        drag: n = !1,
        dragDirectionLock: r = !1,
        dragPropagation: i = !1,
        dragConstraints: s = !1,
        dragElastic: o = Fl,
        dragMomentum: l = !0,
      } = t;
    return {
      ...t,
      drag: n,
      dragDirectionLock: r,
      dragPropagation: i,
      dragConstraints: s,
      dragElastic: o,
      dragMomentum: l,
    };
  }
}
function Uf(e) {
  let t = !0;
  return () => {
    if (t) {
      t = !1;
      return;
    }
    e();
  };
}
function B3(e, t, n) {
  const r = Zd(e, Uf(n)),
    i = Zd(t, Uf(n));
  return () => {
    (r(), i());
  };
}
function ts(e, t, n) {
  return (t === !0 || t === e) && (n === null || n === e);
}
function O3(e, t = 10) {
  let n = null;
  return (Math.abs(e.y) > t ? (n = "y") : Math.abs(e.x) > t && (n = "x"), n);
}
class F3 extends hn {
  constructor(t) {
    (super(t),
      (this.removeGroupControls = et),
      (this.removeListeners = et),
      (this.controls = new V3(t)));
  }
  mount() {
    const { dragControls: t } = this.node.getProps();
    (t && (this.removeGroupControls = t.subscribe(this.controls)),
      (this.removeListeners = this.controls.addListeners() || et));
  }
  update() {
    const { dragControls: t } = this.node.getProps(),
      { dragControls: n } = this.node.prevProps || {};
    t !== n &&
      (this.removeGroupControls(),
      t && (this.removeGroupControls = t.subscribe(this.controls)));
  }
  unmount() {
    (this.removeGroupControls(),
      this.removeListeners(),
      this.controls.isDragging || this.controls.endPanSession());
  }
}
const ya = (e) => (t, n) => {
  e && U.update(() => e(t, n), !1, !0);
};
class z3 extends hn {
  constructor() {
    (super(...arguments), (this.removePointerDownListener = et));
  }
  onPointerDown(t) {
    this.session = new ly(t, this.createPanHandlers(), {
      transformPagePoint: this.node.getTransformPagePoint(),
      contextWindow: ay(this.node),
    });
  }
  createPanHandlers() {
    const {
      onPanSessionStart: t,
      onPanStart: n,
      onPan: r,
      onPanEnd: i,
    } = this.node.getProps();
    return {
      onSessionStart: ya(t),
      onStart: ya(n),
      onMove: ya(r),
      onEnd: (s, o) => {
        (delete this.session, i && U.postRender(() => i(s, o)));
      },
    };
  }
  mount() {
    this.removePointerDownListener = qr(this.node.current, "pointerdown", (t) =>
      this.onPointerDown(t),
    );
  }
  update() {
    this.session && this.session.updateHandlers(this.createPanHandlers());
  }
  unmount() {
    (this.removePointerDownListener(), this.session && this.session.end());
  }
}
let va = !1;
class _3 extends j.Component {
  componentDidMount() {
    const {
        visualElement: t,
        layoutGroup: n,
        switchLayoutGroup: r,
        layoutId: i,
      } = this.props,
      { projection: s } = t;
    (s &&
      (n.group && n.group.add(s),
      r && r.register && i && r.register(s),
      va && s.root.didUpdate(),
      s.addEventListener("animationComplete", () => {
        this.safeToRemove();
      }),
      s.setOptions({
        ...s.options,
        layoutDependency: this.props.layoutDependency,
        onExitComplete: () => this.safeToRemove(),
      })),
      (ks.hasEverUpdated = !0));
  }
  getSnapshotBeforeUpdate(t) {
    const {
        layoutDependency: n,
        visualElement: r,
        drag: i,
        isPresent: s,
      } = this.props,
      { projection: o } = r;
    return (
      o &&
        ((o.isPresent = s),
        t.layoutDependency !== n &&
          o.setOptions({ ...o.options, layoutDependency: n }),
        (va = !0),
        i || t.layoutDependency !== n || n === void 0 || t.isPresent !== s
          ? o.willUpdate()
          : this.safeToRemove(),
        t.isPresent !== s &&
          (s
            ? o.promote()
            : o.relegate() ||
              U.postRender(() => {
                const l = o.getStack();
                (!l || !l.members.length) && this.safeToRemove();
              }))),
      null
    );
  }
  componentDidUpdate() {
    const { visualElement: t, layoutAnchor: n } = this.props,
      { projection: r } = t;
    r &&
      ((r.options.layoutAnchor = n),
      r.root.didUpdate(),
      tc.postRender(() => {
        !r.currentAnimation && r.isLead() && this.safeToRemove();
      }));
  }
  componentWillUnmount() {
    const {
        visualElement: t,
        layoutGroup: n,
        switchLayoutGroup: r,
      } = this.props,
      { projection: i } = t;
    ((va = !0),
      i &&
        (i.scheduleCheckAfterUnmount(),
        n && n.group && n.group.remove(i),
        r && r.deregister && r.deregister(i)));
  }
  safeToRemove() {
    const { safeToRemove: t } = this.props;
    t && t();
  }
  render() {
    return null;
  }
}
function cy(e) {
  const [t, n] = Y4(),
    r = j.useContext(Cm);
  return a.jsx(_3, {
    ...e,
    layoutGroup: r,
    switchLayoutGroup: j.useContext(sy),
    isPresent: t,
    safeToRemove: n,
  });
}
const W3 = {
  pan: { Feature: z3 },
  drag: { Feature: F3, ProjectionNode: Zg, MeasureLayout: cy },
};
function Hf(e, t, n) {
  const { props: r } = e;
  e.animationState &&
    r.whileHover &&
    e.animationState.setActive("whileHover", n === "Start");
  const i = "onHover" + n,
    s = r[i];
  s && U.postRender(() => s(t, Ai(t)));
}
class U3 extends hn {
  mount() {
    const { current: t } = this.node;
    t &&
      (this.unmount = gw(
        t,
        (n, r) => (Hf(this.node, r, "Start"), (i) => Hf(this.node, i, "End")),
      ));
  }
  unmount() {}
}
class H3 extends hn {
  constructor() {
    (super(...arguments), (this.isActive = !1));
  }
  onFocus() {
    let t = !1;
    try {
      t = this.node.current.matches(":focus-visible");
    } catch {
      t = !0;
    }
    !t ||
      !this.node.animationState ||
      (this.node.animationState.setActive("whileFocus", !0),
      (this.isActive = !0));
  }
  onBlur() {
    !this.isActive ||
      !this.node.animationState ||
      (this.node.animationState.setActive("whileFocus", !1),
      (this.isActive = !1));
  }
  mount() {
    this.unmount = Ni(
      ki(this.node.current, "focus", () => this.onFocus()),
      ki(this.node.current, "blur", () => this.onBlur()),
    );
  }
  unmount() {}
}
function $f(e, t, n) {
  const { props: r } = e;
  if (e.current instanceof HTMLButtonElement && e.current.disabled) return;
  e.animationState &&
    r.whileTap &&
    e.animationState.setActive("whileTap", n === "Start");
  const i = "onTap" + (n === "End" ? "" : n),
    s = r[i];
  s && U.postRender(() => s(t, Ai(t)));
}
class $3 extends hn {
  mount() {
    const { current: t } = this.node;
    if (!t) return;
    const { globalTapTarget: n, propagate: r } = this.node.props;
    this.unmount = jw(
      t,
      (i, s) => (
        $f(this.node, s, "Start"),
        (o, { success: l }) => $f(this.node, o, l ? "End" : "Cancel")
      ),
      {
        useGlobalTarget: n,
        stopPropagation: (r == null ? void 0 : r.tap) === !1,
      },
    );
  }
  unmount() {}
}
const zl = new WeakMap(),
  xa = new WeakMap(),
  K3 = (e) => {
    const t = zl.get(e.target);
    t && t(e);
  },
  G3 = (e) => {
    e.forEach(K3);
  };
function Y3({ root: e, ...t }) {
  const n = e || document;
  xa.has(n) || xa.set(n, {});
  const r = xa.get(n),
    i = JSON.stringify(t);
  return (
    r[i] || (r[i] = new IntersectionObserver(G3, { root: e, ...t })),
    r[i]
  );
}
function X3(e, t, n) {
  const r = Y3(t);
  return (
    zl.set(e, n),
    r.observe(e),
    () => {
      (zl.delete(e), r.unobserve(e));
    }
  );
}
const Q3 = { some: 0, all: 1 };
class Z3 extends hn {
  constructor() {
    (super(...arguments), (this.hasEnteredView = !1), (this.isInView = !1));
  }
  startObserver() {
    var u;
    (u = this.stopObserver) == null || u.call(this);
    const { viewport: t = {} } = this.node.getProps(),
      { root: n, margin: r, amount: i = "some", once: s } = t,
      o = {
        root: n ? n.current : void 0,
        rootMargin: r,
        threshold: typeof i == "number" ? i : Q3[i],
      },
      l = (c) => {
        const { isIntersecting: d } = c;
        if (
          this.isInView === d ||
          ((this.isInView = d), s && !d && this.hasEnteredView)
        )
          return;
        (d && (this.hasEnteredView = !0),
          this.node.animationState &&
            this.node.animationState.setActive("whileInView", d));
        const { onViewportEnter: f, onViewportLeave: h } = this.node.getProps(),
          m = d ? f : h;
        m && m(c);
      };
    this.stopObserver = X3(this.node.current, o, l);
  }
  mount() {
    this.startObserver();
  }
  update() {
    if (typeof IntersectionObserver > "u") return;
    const { props: t, prevProps: n } = this.node;
    ["amount", "margin", "root"].some(q3(t, n)) && this.startObserver();
  }
  unmount() {
    var t;
    ((t = this.stopObserver) == null || t.call(this),
      (this.hasEnteredView = !1),
      (this.isInView = !1));
  }
}
function q3({ viewport: e = {} }, { viewport: t = {} } = {}) {
  return (n) => e[n] !== t[n];
}
const J3 = {
    inView: { Feature: Z3 },
    tap: { Feature: $3 },
    focus: { Feature: H3 },
    hover: { Feature: U3 },
  },
  ek = { layout: { ProjectionNode: Zg, MeasureLayout: cy } },
  tk = { ...b3, ...J3, ...W3, ...ek },
  R = x3(tk, w3);
function I({
  children: e,
  className: t,
  style: n,
  delayMs: r = 0,
  variant: i = "fadeUp",
}) {
  const s = j.useRef(null),
    [o, l] = j.useState(!1);
  j.useEffect(() => {
    const d = s.current;
    if (!d) return;
    const f = new IntersectionObserver(
      (h) => {
        h.forEach((m) => {
          m.isIntersecting && l(!0);
        });
      },
      { threshold: 0.12 },
    );
    return (f.observe(d), () => f.disconnect());
  }, []);
  const u = i === "fadeUp" ? "opacity-0 translate-y-4" : "opacity-0",
    c = i === "fadeUp" ? "opacity-100 translate-y-0" : "opacity-100";
  return a.jsx("div", {
    ref: s,
    className: Yr(
      "transition duration-700 ease-out will-change-transform",
      o ? c : u,
      t,
    ),
    style: { transitionDelay: `${r}ms`, ...n },
    children: e,
  });
}
const ue = "#000000",
  tt = "#e26991",
  nk = [
    "/assets/images/Home/our partners images/WhatsApp Image 2026-01-24 at 14.36.28.jpeg",
    "/assets/images/Home/our partners images/Image4.jpeg",
    "/assets/images/Home/our partners images/WhatsApp Image 2026-01-24 at 14.34.44.jpeg",
    "/assets/images/Home/our partners images/WhatsApp Image 2026-01-24 at 14.36.10.jpeg",
    "/assets/images/Home/our partners images/WhatsApp Image 2026-01-24 at 14.35.54.jpeg",
    "/assets/images/Home/our partners images/WhatsApp Image 2026-01-24 at 14.35.56.jpeg",
    "/assets/images/Home/our partners images/WhatsApp Image 2026-01-24 at 14.36.04.jpeg",
  ];
function rk({ size: e = 64, color: t = tt }) {
  return a.jsxs(R.svg, {
    width: e,
    height: e,
    viewBox: "0 0 64 64",
    fill: "none",
    initial: "rest",
    whileHover: "hover",
    children: [
      a.jsx(R.rect, {
        x: "22",
        y: "10",
        width: "20",
        height: "10",
        rx: "4",
        stroke: t,
        strokeWidth: "3",
        fill: "none",
        variants: { rest: { scaleY: 1 }, hover: { scaleY: 1.15 } },
        style: { originY: "100%" },
        transition: { type: "spring", stiffness: 300, damping: 18 },
      }),
      a.jsx(R.rect, {
        x: "8",
        y: "20",
        width: "48",
        height: "34",
        rx: "4",
        stroke: t,
        strokeWidth: "3",
        fill: "none",
        variants: { rest: { y: 0 }, hover: { y: -3 } },
        transition: { type: "spring", stiffness: 260, damping: 20 },
      }),
      a.jsx(R.line, {
        x1: "32",
        y1: "20",
        x2: "32",
        y2: "54",
        stroke: t,
        strokeWidth: "2.5",
        strokeLinecap: "round",
        variants: {
          rest: { scaleY: 1, opacity: 0.4 },
          hover: { scaleY: 1, opacity: 1 },
        },
        transition: { duration: 0.25 },
      }),
      a.jsx(R.line, {
        x1: "8",
        y1: "37",
        x2: "56",
        y2: "37",
        stroke: t,
        strokeWidth: "2.5",
        strokeLinecap: "round",
        variants: { rest: { opacity: 0.3 }, hover: { opacity: 1 } },
        transition: { duration: 0.25 },
      }),
    ],
  });
}
function ik({ size: e = 64, color: t = tt }) {
  const n = [
    { x: 10, h: 28, delay: 0 },
    { x: 24, h: 40, delay: 0.06 },
    { x: 38, h: 20, delay: 0.12 },
    { x: 52, h: 34, delay: 0.18 },
  ];
  return a.jsxs(R.svg, {
    width: e,
    height: e,
    viewBox: "0 0 64 64",
    fill: "none",
    initial: "rest",
    whileHover: "hover",
    children: [
      n.map((r) =>
        a.jsx(
          R.rect,
          {
            x: r.x,
            y: 54 - r.h,
            width: "10",
            height: r.h,
            rx: "2",
            fill: t,
            variants: {
              rest: { scaleY: 1, opacity: 0.7 },
              hover: { scaleY: 1.08, opacity: 1 },
            },
            style: { originY: "100%" },
            transition: {
              type: "spring",
              stiffness: 280,
              damping: 16,
              delay: r.delay,
            },
          },
          r.x,
        ),
      ),
      a.jsx(R.line, {
        x1: "6",
        y1: "54",
        x2: "62",
        y2: "54",
        stroke: t,
        strokeWidth: "2.5",
        strokeLinecap: "round",
      }),
      a.jsx(R.polyline, {
        points: "15,46 29,34 43,42 57,28",
        stroke: t,
        strokeWidth: "2.5",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        fill: "none",
        strokeDasharray: "60",
        variants: {
          rest: { strokeDashoffset: 60 },
          hover: { strokeDashoffset: 0 },
        },
        transition: { duration: 0.5, ease: "easeOut" },
      }),
    ],
  });
}
function sk({ size: e = 64, color: t = tt }) {
  return a.jsxs(R.svg, {
    width: e,
    height: e,
    viewBox: "0 0 64 64",
    fill: "none",
    initial: "rest",
    whileHover: "hover",
    children: [
      a.jsx(R.path, {
        d: "M32 6 L54 16 L54 34 C54 46 43 55 32 58 C21 55 10 46 10 34 L10 16 Z",
        stroke: t,
        strokeWidth: "3",
        fill: "none",
        strokeLinejoin: "round",
        variants: { rest: { scale: 1 }, hover: { scale: 1.06 } },
        style: { originX: "50%", originY: "50%" },
        transition: { type: "spring", stiffness: 260, damping: 18 },
      }),
      a.jsx(R.path, {
        d: "M22 32 L29 39 L42 26",
        stroke: t,
        strokeWidth: "3",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeDasharray: "30",
        variants: {
          rest: { strokeDashoffset: 30 },
          hover: { strokeDashoffset: 0 },
        },
        transition: { duration: 0.4, ease: "easeOut", delay: 0.1 },
      }),
    ],
  });
}
function ok({ color: e = tt }) {
  return a.jsx(R.svg, {
    width: "32",
    height: "32",
    viewBox: "0 0 32 32",
    fill: "none",
    initial: "rest",
    whileHover: "hover",
    children: a.jsx(R.path, {
      d: "M16 28 C16 28 4 20 4 12 C4 8 7.6 5 12 6.4 C13.6 7 15 8.2 16 9.6 C17 8.2 18.4 7 20 6.4 C24.4 5 28 8 28 12 C28 20 16 28 16 28Z",
      stroke: e,
      strokeWidth: "2.2",
      fill: "none",
      strokeLinejoin: "round",
      variants: { rest: { scale: 1 }, hover: { scale: 1.15 } },
      style: { originX: "50%", originY: "50%" },
      transition: { type: "spring", stiffness: 300, damping: 14 },
    }),
  });
}
function ak({ color: e = tt }) {
  return a.jsxs(R.svg, {
    width: "32",
    height: "32",
    viewBox: "0 0 32 32",
    fill: "none",
    initial: "rest",
    whileHover: "hover",
    children: [
      a.jsx(R.rect, {
        x: "4",
        y: "10",
        width: "24",
        height: "18",
        rx: "2",
        stroke: e,
        strokeWidth: "2.2",
        fill: "none",
        variants: { rest: { y: 0 }, hover: { y: -2 } },
        transition: { type: "spring", stiffness: 260, damping: 18 },
      }),
      a.jsx(R.path, {
        d: "M11 10 V7 C11 5.9 11.9 5 13 5 H19 C20.1 5 21 5.9 21 7 V10",
        stroke: e,
        strokeWidth: "2.2",
        fill: "none",
        strokeLinecap: "round",
      }),
      a.jsx(R.line, {
        x1: "4",
        y1: "19",
        x2: "28",
        y2: "19",
        stroke: e,
        strokeWidth: "2",
        strokeLinecap: "round",
        variants: { rest: { opacity: 0.3 }, hover: { opacity: 1 } },
        transition: { duration: 0.2 },
      }),
      a.jsx(R.line, {
        x1: "16",
        y1: "16",
        x2: "16",
        y2: "22",
        stroke: e,
        strokeWidth: "2",
        strokeLinecap: "round",
      }),
    ],
  });
}
function lk({ color: e = tt }) {
  return a.jsxs(R.svg, {
    width: "32",
    height: "32",
    viewBox: "0 0 32 32",
    fill: "none",
    initial: "rest",
    whileHover: "hover",
    children: [
      a.jsx(R.path, {
        d: "M16 28 C16 28 5 21 5 13 C5 9.7 7.7 7 11 7 C12.9 7 14.6 7.9 16 9.4 C17.4 7.9 19.1 7 21 7 C24.3 7 27 9.7 27 13 C27 21 16 28 16 28Z",
        stroke: e,
        strokeWidth: "2.2",
        fill: "none",
        variants: { rest: { scale: 1 }, hover: { scale: 1.12 } },
        style: { originX: "50%", originY: "50%" },
        transition: { type: "spring", stiffness: 300, damping: 14 },
      }),
      a.jsx(R.path, {
        d: "M13 13 H19 M16 10 V16",
        stroke: e,
        strokeWidth: "2",
        strokeLinecap: "round",
        variants: { rest: { opacity: 0 }, hover: { opacity: 1 } },
        transition: { duration: 0.25, delay: 0.1 },
      }),
    ],
  });
}
function uk({ color: e = tt }) {
  return a.jsxs(R.svg, {
    width: "32",
    height: "32",
    viewBox: "0 0 32 32",
    fill: "none",
    initial: "rest",
    whileHover: "hover",
    children: [
      a.jsx(R.path, {
        d: "M5 20 L8 12 C8.5 10.8 9.7 10 11 10 H21 C22.3 10 23.5 10.8 24 12 L27 20",
        stroke: e,
        strokeWidth: "2.2",
        fill: "none",
        strokeLinecap: "round",
        variants: { rest: { y: 0 }, hover: { y: -2 } },
        transition: { type: "spring", stiffness: 240, damping: 16 },
      }),
      a.jsx(R.rect, {
        x: "3",
        y: "18",
        width: "26",
        height: "8",
        rx: "2",
        stroke: e,
        strokeWidth: "2.2",
        fill: "none",
        variants: { rest: { y: 0 }, hover: { y: -2 } },
        transition: { type: "spring", stiffness: 240, damping: 16 },
      }),
      a.jsx(R.circle, {
        cx: "9",
        cy: "27",
        r: "2.5",
        stroke: e,
        strokeWidth: "2",
        fill: "none",
        variants: { rest: { rotate: 0 }, hover: { rotate: 180 } },
        transition: { duration: 0.5 },
      }),
      a.jsx(R.circle, {
        cx: "23",
        cy: "27",
        r: "2.5",
        stroke: e,
        strokeWidth: "2",
        fill: "none",
        variants: { rest: { rotate: 0 }, hover: { rotate: 180 } },
        transition: { duration: 0.5 },
      }),
    ],
  });
}
function ck({ color: e = tt }) {
  return a.jsxs(R.svg, {
    width: "32",
    height: "32",
    viewBox: "0 0 32 32",
    fill: "none",
    initial: "rest",
    whileHover: "hover",
    children: [
      a.jsx(R.path, {
        d: "M8 20 C8 14.5 11.6 10 16 10 C20.4 10 24 14.5 24 20 C24 23.3 22.3 26.2 19.7 27.6 L19.7 29 L12.3 29 L12.3 27.6 C9.7 26.2 8 23.3 8 20Z",
        stroke: e,
        strokeWidth: "2.2",
        fill: "none",
        variants: { rest: { scale: 1 }, hover: { scale: 1.08 } },
        style: { originX: "50%", originY: "50%" },
        transition: { type: "spring", stiffness: 280, damping: 16 },
      }),
      a.jsx(R.path, {
        d: "M24 17 L28 15 L27 20",
        stroke: e,
        strokeWidth: "2",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        fill: "none",
      }),
      a.jsx(R.circle, {
        cx: "19",
        cy: "18",
        r: "1.2",
        fill: e,
        variants: { rest: { opacity: 0.5 }, hover: { opacity: 1 } },
      }),
      a.jsx(R.line, {
        x1: "14",
        y1: "10",
        x2: "18",
        y2: "10",
        stroke: e,
        strokeWidth: "2",
        strokeLinecap: "round",
      }),
      a.jsx(R.path, {
        d: "M16 3 L16 8",
        stroke: e,
        strokeWidth: "2",
        strokeLinecap: "round",
        variants: { rest: { y: 0, opacity: 0 }, hover: { y: 3, opacity: 1 } },
        transition: { type: "spring", stiffness: 200, damping: 12 },
      }),
    ],
  });
}
function dk({ color: e = tt }) {
  return a.jsxs(R.svg, {
    width: "32",
    height: "32",
    viewBox: "0 0 32 32",
    fill: "none",
    initial: "rest",
    whileHover: "hover",
    children: [
      [0, 1, 2].map((t) =>
        a.jsx(
          R.ellipse,
          {
            cx: "14",
            cy: 24 - t * 5,
            rx: "9",
            ry: "3.5",
            stroke: e,
            strokeWidth: "2.2",
            fill: "none",
            variants: { rest: { y: 0 }, hover: { y: -t * 1.5 } },
            transition: {
              type: "spring",
              stiffness: 300,
              damping: 16,
              delay: t * 0.05,
            },
          },
          t,
        ),
      ),
      [0, 1, 2].map((t) =>
        a.jsx(
          R.line,
          {
            x1: "5",
            y1: 24 - t * 5,
            x2: "5",
            y2: 27.5 - t * 5,
            stroke: e,
            strokeWidth: "2.2",
            strokeLinecap: "round",
            variants: { rest: { y: 0 }, hover: { y: -t * 1.5 } },
            transition: {
              type: "spring",
              stiffness: 300,
              damping: 16,
              delay: t * 0.05,
            },
          },
          `l${t}`,
        ),
      ),
      [0, 1, 2].map((t) =>
        a.jsx(
          R.line,
          {
            x1: "23",
            y1: 24 - t * 5,
            x2: "23",
            y2: 27.5 - t * 5,
            stroke: e,
            strokeWidth: "2.2",
            strokeLinecap: "round",
            variants: { rest: { y: 0 }, hover: { y: -t * 1.5 } },
            transition: {
              type: "spring",
              stiffness: 300,
              damping: 16,
              delay: t * 0.05,
            },
          },
          `r${t}`,
        ),
      ),
    ],
  });
}
function fk({ size: e = 40, color: t = "#ffffff" }) {
  return a.jsxs(R.svg, {
    width: e,
    height: e,
    viewBox: "0 0 40 40",
    fill: "none",
    initial: "rest",
    whileHover: "hover",
    children: [
      a.jsx(R.path, {
        d: "M20 4 L35 11 L35 23 C35 31 28 37 20 39 C12 37 5 31 5 23 L5 11 Z",
        stroke: t,
        strokeWidth: "2.5",
        fill: "none",
        strokeLinejoin: "round",
        variants: { rest: { scale: 1 }, hover: { scale: 1.08 } },
        style: { originX: "50%", originY: "50%" },
        transition: { type: "spring", stiffness: 260, damping: 18 },
      }),
      a.jsx(R.path, {
        d: "M13 21 L18 26 L27 17",
        stroke: t,
        strokeWidth: "2.5",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeDasharray: "24",
        variants: {
          rest: { strokeDashoffset: 24 },
          hover: { strokeDashoffset: 0 },
        },
        transition: { duration: 0.4, ease: "easeOut", delay: 0.1 },
      }),
    ],
  });
}
function hk({ size: e = 40, color: t = "#ffffff" }) {
  return a.jsxs(R.svg, {
    width: e,
    height: e,
    viewBox: "0 0 40 40",
    fill: "none",
    initial: "rest",
    whileHover: "hover",
    children: [
      a.jsx(R.ellipse, {
        cx: "20",
        cy: "20",
        rx: "14",
        ry: "8",
        stroke: t,
        strokeWidth: "2.5",
        fill: "none",
        variants: { rest: { scaleX: 1 }, hover: { scaleX: 1.1 } },
        style: { originX: "50%", originY: "50%" },
        transition: { type: "spring", stiffness: 260, damping: 16 },
      }),
      a.jsx(R.circle, {
        cx: "20",
        cy: "20",
        r: "4",
        stroke: t,
        strokeWidth: "2.5",
        fill: "none",
        variants: { rest: { scale: 1 }, hover: { scale: 1.3 } },
        style: { originX: "50%", originY: "50%" },
        transition: { type: "spring", stiffness: 300, damping: 14 },
      }),
      a.jsx(R.circle, {
        cx: "20",
        cy: "20",
        r: "1.5",
        fill: t,
        variants: { rest: { opacity: 0.4 }, hover: { opacity: 1 } },
        transition: { duration: 0.2 },
      }),
    ],
  });
}
function pk({ size: e = 40, color: t = "#ffffff" }) {
  return a.jsxs(R.svg, {
    width: e,
    height: e,
    viewBox: "0 0 40 40",
    fill: "none",
    initial: "rest",
    whileHover: "hover",
    children: [
      [14, 9, 4].map((n, r) =>
        a.jsx(
          R.circle,
          {
            cx: "20",
            cy: "20",
            r: n,
            stroke: t,
            strokeWidth: "2",
            fill: "none",
            strokeOpacity: 1 - r * 0.25,
            variants: {
              rest: { scale: 1, opacity: 1 - r * 0.25 },
              hover: { scale: 1 + r * 0.06, opacity: 1 },
            },
            style: { originX: "50%", originY: "50%" },
            transition: {
              type: "spring",
              stiffness: 260,
              damping: 16,
              delay: r * 0.06,
            },
          },
          n,
        ),
      ),
      a.jsx(R.circle, {
        cx: "20",
        cy: "20",
        r: "2.5",
        fill: t,
        variants: { rest: { scale: 1 }, hover: { scale: 1.4 } },
        style: { originX: "50%", originY: "50%" },
        transition: { type: "spring", stiffness: 300, damping: 12 },
      }),
      a.jsx(R.line, {
        x1: "20",
        y1: "4",
        x2: "20",
        y2: "8",
        stroke: t,
        strokeWidth: "2",
        strokeLinecap: "round",
      }),
      a.jsx(R.line, {
        x1: "20",
        y1: "32",
        x2: "20",
        y2: "36",
        stroke: t,
        strokeWidth: "2",
        strokeLinecap: "round",
      }),
      a.jsx(R.line, {
        x1: "4",
        y1: "20",
        x2: "8",
        y2: "20",
        stroke: t,
        strokeWidth: "2",
        strokeLinecap: "round",
      }),
      a.jsx(R.line, {
        x1: "32",
        y1: "20",
        x2: "36",
        y2: "20",
        stroke: t,
        strokeWidth: "2",
        strokeLinecap: "round",
      }),
    ],
  });
}
const mk = [
    {
      icon: a.jsx(rk, { size: 80 }),
      title: `Business Investment
 Solutions`,
      description:
        "Strategic investment solutions designed to help businesses grow sustainably and responsibly.",
      href: "/services/business-investment",
    },
    {
      icon: a.jsx(ik, { size: 80 }),
      title: `Financial Planning 
Solutions`,
      description:
        "Personalised financial planning that aligns your income, goals and long-term vision.",
      href: "/services/financial-planning",
    },
    {
      icon: a.jsx(sk, { size: 80 }),
      title: a.jsxs(a.Fragment, {
        children: ["Insurance & Risk ", a.jsx("br", {}), " Management"],
      }),
      description: a.jsxs(a.Fragment, {
        children: [
          "Protecting your assets and income through tailored insurance and ",
          a.jsx("br", {}),
          "risk solutions.",
        ],
      }),
      href: "/services/insurance",
    },
  ],
  gk = [
    {
      icon: a.jsx(ok, {}),
      title: a.jsxs(a.Fragment, {
        children: ["Comprehensive Life ", a.jsx("br", {}), " Cover"],
      }),
      desc: "Delivering financial protection for your loved ones through flexible and client-focused life insurance solutions.",
    },
    {
      icon: a.jsx(ak, {}),
      title: "Structured Business Assurance Solutions",
      desc: "Delivering peace of mind through strategic risk management and continuity planning for businesses and their critical team members.",
    },
    {
      icon: a.jsx(lk, {}),
      title: "Comprehensive Health Assurance",
      desc: "Delivering personalised advice on medical aid and healthcare cover to ensure your health and financial peace of mind.",
    },
    {
      icon: a.jsx(uk, {}),
      title: a.jsxs(a.Fragment, {
        children: ["Trusted Asset ", a.jsx("br", {}), " Protection"],
      }),
      desc: "Offering personalised short-term insurance solutions to keep your assets secure against unforeseen events.",
    },
    {
      icon: a.jsx(ck, {}),
      title: a.jsxs(a.Fragment, {
        children: ["Wealth Solutions for ", a.jsx("br", {}), " Growth"],
      }),
      desc: "Helping you achieve long-term financial growth through tailored investment planning and expert advice.",
    },
    {
      icon: a.jsx(dk, {}),
      title: "Investment Products for the Future",
      desc: "Delivering personalised solutions to build, safeguard and transfer wealth for you and your family.",
    },
  ],
  Ge = [
    {
      publication: "IOL News",
      logoBg: "#cc0000",
      logoText: `IOL
News`,
      logoColor: "#ffffff",
      title: "Golf is not a sport, it is business",
      age: "Published January 6, 2023",
      excerpt:
        "Golf days have largely been the forte of the mainstream (white) business, but it is pleasing that black business is getting on the bandwagon and reaping rewards.",
      href: "https://iol.co.za/sundayindependent/news/2023-01-06-golf-is-not-a-sport-it-is-business/",
    },
    {
      publication: "PressReader",
      logoBg: "#00b388",
      logoText: "PR",
      logoColor: "#ffffff",
      title: "Financial advisers are crucial to the economy",
      age: "Published May 1, 2022",
      excerpt:
        "In the era of Bitcoin and conspicuous consumption, many vulnerable investors lose their money at the hands of charlatans posing as financial advisers.",
      href: "https://www.pressreader.com/south-africa/the-sunday-independent/20220501/281792812599319",
    },
  ],
  yk = 7,
  Kf = 6;
function vk({ partners: e }) {
  const [t, n] = j.useState(0),
    r = j.useRef(null);
  j.useEffect(() => {
    const s = setInterval(() => {
      n((o) => (o + 1) % Kf);
    }, 3e3);
    return () => clearInterval(s);
  }, []);
  const i = [...e, ...e].slice(t, t + yk);
  return a.jsxs("section", {
    className: "w-full bg-white py-14 sm:py-16",
    children: [
      a.jsxs("div", {
        className: "container-shell",
        children: [
          a.jsxs(I, {
            children: [
              a.jsx("h3", {
                className:
                  "mbi-heading text-center text-3xl font-bold sm:text-4xl",
                style: { color: ue },
                children: "Our Partners",
              }),
              a.jsx("div", {
                className: "mx-auto mt-3 h-1 w-16 rounded-full",
                style: { backgroundColor: ue },
              }),
            ],
          }),
          a.jsx("div", {
            className: "mt-14 overflow-hidden",
            ref: r,
            children: a.jsx("div", {
              className: "flex items-center justify-center gap-10",
              children: i.map((s, o) =>
                a.jsx(
                  "img",
                  {
                    src: s,
                    alt: `Partner logo ${o + 1}`,
                    className:
                      "h-28 w-auto max-w-[180px] object-contain grayscale transition-all duration-500 ease-in-out hover:grayscale-0 hover:scale-110 shrink-0",
                    style: {
                      animation: "fadeSlideIn 0.6s ease both",
                      animationDelay: `${o * 80}ms`,
                    },
                    loading: "lazy",
                    onError: (l) => {
                      l.target.style.display = "none";
                    },
                  },
                  `${t}-${o}`,
                ),
              ),
            }),
          }),
          a.jsx("div", {
            className: "mt-10 flex items-center justify-center gap-2",
            children: Array.from({ length: Kf }).map((s, o) =>
              a.jsx(
                "button",
                {
                  onClick: () => n(o),
                  "aria-label": `Go to rotation ${o + 1}`,
                  className:
                    "h-3 w-3 rounded-full border-2 transition-all duration-300",
                  style: {
                    backgroundColor: o === t ? ue : "transparent",
                    borderColor: o === t ? ue : "#9ca3af",
                    transform: o === t ? "scale(1.25)" : "scale(1)",
                  },
                },
                o,
              ),
            ),
          }),
        ],
      }),
      a.jsx("style", {
        children:
          "@keyframes fadeSlideIn { from { opacity: 0; transform: translateX(30px); } to { opacity: 1; transform: translateX(0); } }",
      }),
    ],
  });
}
function xk() {
  const [e, t] = j.useState(!1),
    n = j.useRef(null),
    [r, i] = j.useState(0);
  return (
    j.useEffect(() => {
      n.current && i(n.current.scrollHeight);
    }, []),
    a.jsxs("div", {
      children: [
        a.jsx("style", {
          children: `
        @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&family=Playfair+Display:wght@400;700&family=Libre+Baskerville:wght@400;700&display=swap');
        .mbi-heading { font-family: 'Montserrat', sans-serif; font-weight: 600; }
        .mbi-body    { font-family: 'Montserrat', sans-serif; font-weight: 400; }
        .mbi-serif   { font-family: 'Playfair Display', serif; font-weight: 700; }
        .mbi-justify { text-align: justify; }
      `,
        }),
        a.jsxs("section", {
          className: "relative min-h-[85vh] bg-cover bg-center bg-no-repeat",
          style: { backgroundImage: "url('/assets/images/Home/hero.jpeg')" },
          children: [
            a.jsx("div", {
              className: "absolute inset-0",
              style: { backgroundColor: "rgba(0,0,0,0.52)" },
            }),
            a.jsx("div", {
              className:
                "container-shell relative flex min-h-[85vh] items-center justify-center pt-24 sm:pt-28 lg:pt-32 text-center",
              children: a.jsxs(I, {
                children: [
                  a.jsx("h1", {
                    className:
                      "mbi-heading text-3xl sm:text-4xl lg:text-5xl leading-tight text-white font-bold mx-auto max-w-[1000px]",
                    children:
                      "Trusted financial guidance for confident decisions and long-term success",
                  }),
                  a.jsx("p", {
                    className:
                      "mbi-body mt-6 mx-auto max-w-2xl text-base sm:text-lg text-white/90 text-center",
                    children:
                      "Helping you navigate financial decisions with clarity, expertise, and a focus on what matters most to you.",
                  }),
                  a.jsx("div", {
                    className:
                      "mt-8 flex flex-col items-center gap-3 sm:flex-row sm:justify-center",
                    children: a.jsx(ye, {
                      to: "/contact#contact-form",
                      children: a.jsx("button", {
                        className:
                          "mbi-heading rounded-none px-8 py-4 text-base font-bold text-white hover:opacity-80 transition-opacity w-full sm:w-auto",
                        style: { backgroundColor: tt, minWidth: "220px" },
                        children: "Book a Consultation",
                      }),
                    }),
                  }),
                ],
              }),
            }),
          ],
        }),
        a.jsx("div", {
          className: "bg-white border-b border-gray-100",
          children: a.jsxs("div", {
            className: "container-shell py-16",
            children: [
              a.jsx("div", {
                className:
                  "grid grid-cols-1 divide-y divide-gray-100 sm:grid-cols-3 sm:divide-x sm:divide-y-0",
                children: mk.map((s) =>
                  a.jsxs(
                    "div",
                    {
                      className:
                        "flex flex-col items-center px-8 py-10 text-center transition-transform duration-300 ease-out hover:scale-105 hover:shadow-lg rounded-none",
                      children: [
                        a.jsx("div", {
                          className: "flex items-center justify-center",
                          style: { height: "140px" },
                          children: a.jsx("div", {
                            className:
                              "flex items-center justify-center rounded-lg",
                            style: {
                              width: "100px",
                              height: "100px",
                              backgroundColor: "#e2699120",
                            },
                            children: a.jsx("div", {
                              style: { color: "#e26991" },
                              children: s.icon,
                            }),
                          }),
                        }),
                        a.jsx("h3", {
                          className:
                            "mbi-heading mt-6 text-lg font-bold leading-snug whitespace-pre-line min-h-[3.5rem] text-center",
                          style: { color: ue },
                          children: s.title,
                        }),
                        a.jsx("p", {
                          className:
                            "mbi-body mt-3 text-base leading-relaxed text-black/60 w-full",
                          style: { textAlign: "justify" },
                          children: s.description,
                        }),
                      ],
                    },
                    s.href,
                  ),
                ),
              }),
              a.jsx("div", {
                className: "mt-12 flex justify-center",
                children: a.jsx(ye, {
                  to: "/contact#contact-form",
                  children: a.jsx("button", {
                    className:
                      "mbi-heading rounded-none px-8 py-4 text-base font-bold uppercase tracking-wide text-white hover:opacity-80 transition-opacity",
                    style: { backgroundColor: ue },
                    children: "GET IN TOUCH",
                  }),
                }),
              }),
            ],
          }),
        }),
        a.jsxs("section", {
          className: "relative py-20 sm:py-24 bg-cover bg-center bg-no-repeat",
          style: { backgroundImage: "url('/assets/images/Home/2ndHero.jpeg')" },
          children: [
            a.jsx("div", {
              className: "absolute inset-0",
              style: { backgroundColor: "rgba(0,0,0,0.55)" },
            }),
            a.jsx("div", {
              className: "container-shell relative text-center",
              children: a.jsxs(I, {
                children: [
                  a.jsx("h2", {
                    className:
                      "mbi-heading text-3xl sm:text-4xl lg:text-[42px] font-bold text-white text-left w-full max-w-[1100px]",
                    children:
                      "Trusted Investment Guidance & Financial Services",
                  }),
                  a.jsx("p", {
                    className:
                      "mbi-body mt-6 text-sm text-white/80 sm:text-base",
                    style: { textAlign: "justify" },
                    children:
                      "Matseke Business Investment is an FSCA-authorised Financial Services Provider offering expert financial planning, business assurance, retirement planning, and medical aid solutions. We help individuals and businesses protect their wealth and achieve sustainable financial growth through trusted, personalised advice.",
                  }),
                ],
              }),
            }),
          ],
        }),
        a.jsx("section", {
          id: "about",
          className: "bg-white py-16 sm:py-20",
          children: a.jsx("div", {
            className: "container-shell",
            children: a.jsxs("div", {
              className: "grid items-center gap-12 lg:grid-cols-2",
              children: [
                a.jsxs(I, {
                  children: [
                    a.jsx("h2", {
                      className:
                        "mbi-heading text-4xl font-bold sm:text-5xl text-left",
                      style: { color: ue },
                      children: "About Us",
                    }),
                    a.jsxs("p", {
                      className:
                        "mbi-body mt-6 text-sm leading-relaxed sm:text-base text-left",
                      style: { color: ue },
                      children: [
                        "At Matseke Business Investment (MBI), we believe that the client is the main ingredient of our process. Every financial solution we provide is tailored around your unique goals, circumstances and aspirations.",
                        a.jsx("br", {}),
                        a.jsx("br", {}),
                        "As an FSCA-authorised Financial Services Provider (FSP No. 48618) in South Africa, we deliver expert financial planning, business assurance, retirement planning and medical aid solutions.",
                      ],
                    }),
                    a.jsx("div", {
                      ref: n,
                      style: {
                        overflow: "hidden",
                        maxHeight: e ? `${r}px` : "0px",
                        opacity: e ? 1 : 0,
                        transition:
                          "max-height 0.7s cubic-bezier(0.645, 0.045, 0.355, 1.000), opacity 0.5s ease",
                      },
                      children: a.jsxs("p", {
                        className:
                          "mbi-body mt-4 text-sm leading-relaxed sm:text-base text-left",
                        style: { color: ue },
                        children: [
                          "Our approach combines regulatory compliance, industry expertise and a client-first mindset, ensuring advice is transparent, ethical and aligned with your long-term financial wellbeing.",
                          a.jsx("br", {}),
                          a.jsx("br", {}),
                          "We are committed to building lasting relationships with individuals and businesses by protecting wealth, enabling sustainable growth and securing a strong financial future. At MBI, your financial goals are at the heart of everything we do.",
                        ],
                      }),
                    }),
                    a.jsx("div", {
                      className: "mt-8",
                      children: a.jsx("button", {
                        onClick: () => t(!e),
                        className:
                          "mbi-heading rounded-none px-8 py-3 text-sm font-bold uppercase tracking-wide text-white hover:opacity-80 transition-opacity",
                        style: { backgroundColor: ue },
                        children: e ? "SHOW LESS" : "READ MORE",
                      }),
                    }),
                  ],
                }),
                a.jsx(I, {
                  delayMs: 120,
                  children: a.jsx("div", {
                    className: "overflow-hidden shadow-soft",
                    children: a.jsx("img", {
                      src: "/assets/images/Home/3rdHero.jpeg",
                      alt: "Matseke Business Investment team",
                      className:
                        "h-[320px] w-full object-cover object-top sm:h-[420px]",
                      loading: "lazy",
                    }),
                  }),
                }),
              ],
            }),
          }),
        }),
        a.jsx("section", {
          className: "py-16 sm:py-20",
          style: { backgroundColor: ue },
          children: a.jsxs("div", {
            className: "container-shell",
            children: [
              a.jsx(I, {
                children: a.jsxs("div", {
                  className: "flex items-start gap-5 mb-12",
                  children: [
                    a.jsx("div", {
                      className: "mt-1 shrink-0",
                      children: a.jsx(fk, { size: 40, color: "#ffffff" }),
                    }),
                    a.jsxs("div", {
                      className: "w-full",
                      children: [
                        a.jsx("h3", {
                          className:
                            "mbi-heading text-2xl font-bold text-white sm:text-3xl",
                          style: { textAlign: "justify" },
                          children: "Our Credentials",
                        }),
                        a.jsx("p", {
                          className:
                            "mbi-body mt-3 text-sm leading-relaxed text-white/90 sm:text-base w-full",
                          style: { textAlign: "justify" },
                          children:
                            "Matseke Business Investment (MBI) is an authorised Financial Services Provider in terms of Section 8 of the Financial Advisory and Intermediary Services Act, 2002 (FAIS Act 37 of 2002), regulated by the Financial Sector Conduct Authority (FSCA) under FSP No. 48618. We provide compliant financial and investment advisory services to individuals, professionals, and businesses across South Africa.",
                        }),
                      ],
                    }),
                  ],
                }),
              }),
              a.jsxs("div", {
                className: "grid gap-10 sm:grid-cols-2",
                children: [
                  a.jsx(I, {
                    children: a.jsxs("div", {
                      className: "flex items-start gap-5",
                      children: [
                        a.jsx("div", {
                          className: "mt-1 shrink-0",
                          children: a.jsx(hk, { size: 40, color: "#ffffff" }),
                        }),
                        a.jsxs("div", {
                          children: [
                            a.jsx("h3", {
                              className:
                                "mbi-heading text-2xl font-bold text-white sm:text-3xl",
                              style: { textAlign: "justify" },
                              children: "Our Vision",
                            }),
                            a.jsx("p", {
                              className:
                                "mbi-body mt-3 text-sm leading-relaxed text-white/90 sm:text-base",
                              style: { textAlign: "justify" },
                              children:
                                "To become a leading financial services provider recognised for integrity, excellence and personalised financial solutions that create lasting value for our clients.",
                            }),
                          ],
                        }),
                      ],
                    }),
                  }),
                  a.jsx(I, {
                    delayMs: 80,
                    children: a.jsxs("div", {
                      className: "flex items-start gap-5",
                      children: [
                        a.jsx("div", {
                          className: "mt-1 shrink-0",
                          children: a.jsx(pk, { size: 40, color: "#ffffff" }),
                        }),
                        a.jsxs("div", {
                          children: [
                            a.jsx("h3", {
                              className:
                                "mbi-heading text-2xl font-bold text-white sm:text-3xl",
                              style: { textAlign: "justify" },
                              children: "Our Mission",
                            }),
                            a.jsx("p", {
                              className:
                                "mbi-body mt-3 text-sm leading-relaxed text-white/90 sm:text-base",
                              style: { textAlign: "justify" },
                              children:
                                "Our mission is to support our clients with trusted financial guidance, meaningful relationships and tailored solutions that help them protect, grow and sustain their wealth.",
                            }),
                          ],
                        }),
                      ],
                    }),
                  }),
                ],
              }),
            ],
          }),
        }),
        a.jsx("section", {
          id: "services",
          className: "bg-white py-16 sm:py-20",
          children: a.jsxs("div", {
            className: "container-shell",
            children: [
              a.jsxs(I, {
                children: [
                  a.jsx("h2", {
                    className:
                      "mbi-heading text-center text-4xl font-bold sm:text-5xl",
                    style: { color: ue },
                    children: "Services",
                  }),
                  a.jsx("p", {
                    className: "mbi-body mt-6 text-xs text-black/60",
                    style: { textAlign: "justify" },
                    children:
                      "We deliver professional financial guidance rooted in integrity, expertise and regulatory excellence. We partner with individuals and businesses to protect wealth, enable sustainable growth and build long-term financial security through personalised financial planning, business assurance and retirement solutions. Our client-first approach ensures every recommendation is transparent, compliant and aligned with your financial goals.",
                  }),
                ],
              }),
              a.jsx("div", {
                className:
                  "mt-12 grid gap-x-16 gap-y-12 sm:grid-cols-2 lg:grid-cols-3 items-start",
                children: gk.map((s, o) =>
                  a.jsx(
                    I,
                    {
                      delayMs: o * 60,
                      children: a.jsxs("div", {
                        className: "flex flex-col",
                        children: [
                          a.jsxs("div", {
                            className: "flex items-center gap-4",
                            children: [
                              a.jsx("div", {
                                className:
                                  "flex shrink-0 items-center justify-center rounded-lg",
                                style: {
                                  width: "56px",
                                  height: "56px",
                                  backgroundColor: "#e2699120",
                                },
                                children: a.jsx("div", {
                                  style: { color: "#e26991" },
                                  children: s.icon,
                                }),
                              }),
                              a.jsx("h3", {
                                className:
                                  "mbi-heading text-base font-bold leading-snug text-left",
                                style: { color: ue },
                                children: s.title,
                              }),
                            ],
                          }),
                          a.jsx("p", {
                            className:
                              "mbi-body mt-3 text-xs leading-relaxed text-black/60 pl-[72px]",
                            style: { textAlign: "justify" },
                            children: s.desc,
                          }),
                        ],
                      }),
                    },
                    o,
                  ),
                ),
              }),
            ],
          }),
        }),
        a.jsx("section", {
          id: "news",
          className: "bg-white py-16 sm:py-20",
          style: { borderTop: "1px solid #f3f4f6" },
          children: a.jsxs("div", {
            className: "container-shell",
            children: [
              a.jsx(I, {
                children: a.jsxs("div", {
                  className: "flex items-end justify-between pb-6 mb-10",
                  children: [
                    a.jsx("p", {
                      className: "mbi-body text-xs uppercase tracking-widest",
                      style: { color: "#4b5563" },
                      children: "Press & Media",
                    }),
                    a.jsxs("span", {
                      className: "mbi-body text-xs pb-1",
                      style: { color: "#4b5563" },
                      children: [
                        Ge.length,
                        " ",
                        Ge.length === 1 ? "article" : "articles",
                      ],
                    }),
                  ],
                }),
              }),
              Ge.length > 0 &&
                a.jsx(I, {
                  children: a.jsx("a", {
                    href: Ge[0].href,
                    target: "_blank",
                    rel: "noopener noreferrer",
                    className: "group block pb-10 mb-10",
                    children: a.jsxs("div", {
                      className:
                        "grid gap-6 sm:grid-cols-[auto_1fr] sm:items-start",
                      children: [
                        a.jsx("div", {
                          className:
                            "flex shrink-0 items-center justify-center",
                          style: {
                            width: "56px",
                            height: "56px",
                            backgroundColor: Ge[0].logoBg,
                            padding: "6px",
                          },
                          children: a.jsx("span", {
                            className: "mbi-heading",
                            style: {
                              fontSize: "10px",
                              fontWeight: 700,
                              color: Ge[0].logoColor,
                              textAlign: "center",
                              whiteSpace: "pre-line",
                              lineHeight: 1.2,
                            },
                            children: Ge[0].logoText,
                          }),
                        }),
                        a.jsxs("div", {
                          children: [
                            a.jsxs("div", {
                              className: "flex items-center gap-3 mb-3",
                              children: [
                                a.jsx("p", {
                                  className: "mbi-heading text-xs font-bold",
                                  style: { color: ue },
                                  children: Ge[0].publication,
                                }),
                                a.jsx("span", {
                                  style: { color: "#9ca3af" },
                                  children: "·",
                                }),
                                a.jsx("p", {
                                  className: "mbi-body text-xs",
                                  style: { color: "#4b5563" },
                                  children: Ge[0].age,
                                }),
                              ],
                            }),
                            a.jsx("h3", {
                              className:
                                "mbi-serif text-xl font-bold leading-snug sm:text-2xl group-hover:opacity-70 transition-opacity",
                              style: { color: ue, textAlign: "justify" },
                              children: Ge[0].title,
                            }),
                            a.jsx("p", {
                              className:
                                "mbi-body mt-3 text-sm leading-relaxed italic",
                              style: { color: "#374151", textAlign: "justify" },
                              children: Ge[0].excerpt,
                            }),
                            a.jsxs("span", {
                              className:
                                "mbi-heading mt-5 inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider transition-opacity group-hover:opacity-70",
                              style: { color: tt },
                              children: [
                                "Read Article",
                                a.jsx("svg", {
                                  width: "12",
                                  height: "12",
                                  viewBox: "0 0 12 12",
                                  fill: "none",
                                  children: a.jsx("path", {
                                    d: "M2 10L10 2M10 2H4M10 2V8",
                                    stroke: "currentColor",
                                    strokeWidth: "1.8",
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round",
                                  }),
                                }),
                              ],
                            }),
                          ],
                        }),
                      ],
                    }),
                  }),
                }),
              Ge.slice(1).map((s, o) =>
                a.jsx(
                  I,
                  {
                    delayMs: o * 80,
                    children: a.jsx("a", {
                      href: s.href,
                      target: "_blank",
                      rel: "noopener noreferrer",
                      className: "group block pb-10 mb-10",
                      children: a.jsxs("div", {
                        className:
                          "grid gap-6 sm:grid-cols-[auto_1fr] sm:items-start",
                        children: [
                          a.jsx("div", {
                            className:
                              "flex shrink-0 items-center justify-center",
                            style: {
                              width: "56px",
                              height: "56px",
                              backgroundColor: s.logoBg,
                              padding: "6px",
                            },
                            children: a.jsx("span", {
                              className: "mbi-heading",
                              style: {
                                fontSize: "10px",
                                fontWeight: 700,
                                color: s.logoColor,
                                textAlign: "center",
                                whiteSpace: "pre-line",
                                lineHeight: 1.2,
                              },
                              children: s.logoText,
                            }),
                          }),
                          a.jsxs("div", {
                            children: [
                              a.jsxs("div", {
                                className: "flex items-center gap-3 mb-3",
                                children: [
                                  a.jsx("p", {
                                    className: "mbi-heading text-xs font-bold",
                                    style: { color: ue },
                                    children: s.publication,
                                  }),
                                  a.jsx("span", {
                                    style: { color: "#9ca3af" },
                                    children: "·",
                                  }),
                                  a.jsx("p", {
                                    className: "mbi-body text-xs",
                                    style: { color: "#4b5563" },
                                    children: s.age,
                                  }),
                                ],
                              }),
                              a.jsx("h3", {
                                className:
                                  "mbi-serif text-xl font-bold leading-snug sm:text-2xl group-hover:opacity-70 transition-opacity",
                                style: { color: ue, textAlign: "justify" },
                                children: s.title,
                              }),
                              a.jsx("p", {
                                className:
                                  "mbi-body mt-3 text-sm leading-relaxed italic",
                                style: {
                                  color: "#374151",
                                  textAlign: "justify",
                                },
                                children: s.excerpt,
                              }),
                              a.jsxs("span", {
                                className:
                                  "mbi-heading mt-5 inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider transition-opacity group-hover:opacity-70",
                                style: { color: tt },
                                children: [
                                  "Read Article",
                                  a.jsx("svg", {
                                    width: "12",
                                    height: "12",
                                    viewBox: "0 0 12 12",
                                    fill: "none",
                                    children: a.jsx("path", {
                                      d: "M2 10L10 2M10 2H4M10 2V8",
                                      stroke: "currentColor",
                                      strokeWidth: "1.8",
                                      strokeLinecap: "round",
                                      strokeLinejoin: "round",
                                    }),
                                  }),
                                ],
                              }),
                            ],
                          }),
                        ],
                      }),
                    }),
                  },
                  `${s.title}-${o}`,
                ),
              ),
            ],
          }),
        }),
        a.jsx(vk, { partners: nk }),
        a.jsxs("section", {
          className:
            "relative overflow-hidden py-36 sm:py-44 bg-cover bg-center bg-no-repeat",
          style: { backgroundImage: "url('/assets/images/Home/lp.jpeg')" },
          children: [
            a.jsx("div", {
              className: "absolute inset-0",
              style: { backgroundColor: "rgba(0,0,0,0.35)" },
            }),
            a.jsxs("div", {
              className:
                "container-shell relative flex flex-col items-center gap-8 text-center",
              children: [
                a.jsx(I, {
                  children: a.jsx("h2", {
                    className:
                      "mbi-heading text-4xl font-bold text-white sm:text-5xl lg:text-6xl",
                    children: "Empower Your Financial Decisions",
                  }),
                }),
                a.jsx(I, {
                  delayMs: 100,
                  children: a.jsx(ye, {
                    to: "/contact#contact-form",
                    children: a.jsx("button", {
                      className:
                        "mbi-heading rounded-none px-8 py-4 text-sm font-bold uppercase tracking-wide text-white hover:opacity-80 transition-opacity",
                      style: { backgroundColor: ue },
                      children: "Book a meeting with our trusted advisory team",
                    }),
                  }),
                }),
              ],
            }),
          ],
        }),
      ],
    })
  );
}
const wk =
    "inline-flex items-center justify-center gap-2 rounded-none font-semibold transition active:scale-[0.99] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black/40 [font-family:'Montserrat',sans-serif]",
  kk = {
    primary: "bg-black text-white hover:bg-black/80",
    light: "bg-white text-black hover:bg-black/5",
    outline: "border border-black text-black hover:bg-black/10",
  },
  jk = {
    sm: "h-9 px-4 text-sm",
    md: "h-11 px-5 text-sm",
    lg: "h-12 px-6 text-base",
  };
function dy({ className: e, variant: t = "primary", size: n = "md", ...r }) {
  return a.jsx("button", { className: Yr(wk, kk[t], jk[n], e), ...r });
}
function Sk(e) {
  return Se({
    attr: { viewBox: "0 0 640 512" },
    child: [
      {
        tag: "path",
        attr: {
          d: "M622.3 271.1l-115.2-45c-4.1-1.6-12.6-3.7-22.2 0l-115.2 45c-10.7 4.2-17.7 14-17.7 24.9 0 111.6 68.7 188.8 132.9 213.9 9.6 3.7 18 1.6 22.2 0C558.4 489.9 640 420.5 640 296c0-10.9-7-20.7-17.7-24.9zM496 462.4V273.3l95.5 37.3c-5.6 87.1-60.9 135.4-95.5 151.8zM224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm96 40c0-2.5.8-4.8 1.1-7.2-2.5-.1-4.9-.8-7.5-.8h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c6.8 0 13.3-1.5 19.2-4-54-42.9-99.2-116.7-99.2-212z",
        },
        child: [],
      },
    ],
  })(e);
}
function _l(e) {
  return Se({
    attr: { viewBox: "0 0 512 512" },
    child: [
      {
        tag: "path",
        attr: {
          d: "M466.5 83.7l-192-80a48.15 48.15 0 0 0-36.9 0l-192 80C27.7 91.1 16 108.6 16 128c0 198.5 114.5 335.7 221.5 380.3 11.8 4.9 25.1 4.9 36.9 0C360.1 472.6 496 349.3 496 128c0-19.4-11.7-36.9-29.5-44.3zM256.1 446.3l-.1-381 175.9 73.3c-3.3 151.4-82.1 261.1-175.8 307.7z",
        },
        child: [],
      },
    ],
  })(e);
}
function bk(e) {
  return Se({
    attr: { viewBox: "0 0 512 512" },
    child: [
      {
        tag: "path",
        attr: {
          d: "M320.2 243.8l-49.7 99.4c-6 12.1-23.4 11.7-28.9-.6l-56.9-126.3-30 71.7H60.6l182.5 186.5c7.1 7.3 18.6 7.3 25.7 0L451.4 288H342.3l-22.1-44.2zM473.7 73.9l-2.4-2.5c-51.5-52.6-135.8-52.6-187.4 0L256 100l-27.9-28.5c-51.5-52.7-135.9-52.7-187.4 0l-2.4 2.4C-10.4 123.7-12.5 203 31 256h102.4l35.9-86.2c5.4-12.9 23.6-13.2 29.4-.4l58.2 129.3 49-97.9c5.9-11.8 22.7-11.8 28.6 0l27.6 55.2H481c43.5-53 41.4-132.3-7.3-182.1z",
        },
        child: [],
      },
    ],
  })(e);
}
function Ck(e) {
  return Se({
    attr: { viewBox: "0 0 640 512" },
    child: [
      {
        tag: "path",
        attr: {
          d: "M434.7 64h-85.9c-8 0-15.7 3-21.6 8.4l-98.3 90c-.1.1-.2.3-.3.4-16.6 15.6-16.3 40.5-2.1 56 12.7 13.9 39.4 17.6 56.1 2.7.1-.1.3-.1.4-.2l79.9-73.2c6.5-5.9 16.7-5.5 22.6 1 6 6.5 5.5 16.6-1 22.6l-26.1 23.9L504 313.8c2.9 2.4 5.5 5 7.9 7.7V128l-54.6-54.6c-5.9-6-14.1-9.4-22.6-9.4zM544 128.2v223.9c0 17.7 14.3 32 32 32h64V128.2h-96zm48 223.9c-8.8 0-16-7.2-16-16s7.2-16 16-16 16 7.2 16 16-7.2 16-16 16zM0 384h64c17.7 0 32-14.3 32-32V128.2H0V384zm48-63.9c8.8 0 16 7.2 16 16s-7.2 16-16 16-16-7.2-16-16c0-8.9 7.2-16 16-16zm435.9 18.6L334.6 217.5l-30 27.5c-29.7 27.1-75.2 24.5-101.7-4.4-26.9-29.4-24.8-74.9 4.4-101.7L289.1 64h-83.8c-8.5 0-16.6 3.4-22.6 9.4L128 128v223.9h18.3l90.5 81.9c27.4 22.3 67.7 18.1 90-9.3l.2-.2 17.9 15.5c15.9 13 39.4 10.5 52.3-5.4l31.4-38.6 5.4 4.4c13.7 11.1 33.9 9.1 45-4.7l9.5-11.7c11.2-13.8 9.1-33.9-4.6-45.1z",
        },
        child: [],
      },
    ],
  })(e);
}
function Tk(e) {
  return Se({
    attr: { viewBox: "0 0 576 512" },
    child: [
      {
        tag: "path",
        attr: {
          d: "M572.52 241.4C518.29 135.59 410.93 64 288 64S57.68 135.64 3.48 241.41a32.35 32.35 0 0 0 0 29.19C57.71 376.41 165.07 448 288 448s230.32-71.64 284.52-177.41a32.35 32.35 0 0 0 0-29.19zM288 400a144 144 0 1 1 144-144 143.93 143.93 0 0 1-144 144zm0-240a95.31 95.31 0 0 0-25.31 3.79 47.85 47.85 0 0 1-66.9 66.9A95.78 95.78 0 1 0 288 160z",
        },
        child: [],
      },
    ],
  })(e);
}
function Pk(e) {
  return Se({
    attr: { viewBox: "0 0 512 512" },
    child: [
      {
        tag: "path",
        attr: {
          d: "M0 405.3V448c0 35.3 86 64 192 64s192-28.7 192-64v-42.7C342.7 434.4 267.2 448 192 448S41.3 434.4 0 405.3zM320 128c106 0 192-28.7 192-64S426 0 320 0 128 28.7 128 64s86 64 192 64zM0 300.4V352c0 35.3 86 64 192 64s192-28.7 192-64v-51.6c-41.3 34-116.9 51.6-192 51.6S41.3 334.4 0 300.4zm416 11c57.3-11.1 96-31.7 96-55.4v-42.7c-23.2 16.4-57.3 27.6-96 34.5v63.6zM192 160C86 160 0 195.8 0 240s86 80 192 80 192-35.8 192-80-86-80-192-80zm219.3 56.3c60-10.8 100.7-32 100.7-56.3v-42.7c-35.5 25.1-96.5 38.6-160.7 41.8 29.5 14.3 51.2 33.5 60 57.2z",
        },
        child: [],
      },
    ],
  })(e);
}
function Nk(e) {
  return Se({
    attr: { viewBox: "0 0 640 512" },
    child: [
      {
        tag: "path",
        attr: {
          d: "M512.1 191l-8.2 14.3c-3 5.3-9.4 7.5-15.1 5.4-11.8-4.4-22.6-10.7-32.1-18.6-4.6-3.8-5.8-10.5-2.8-15.7l8.2-14.3c-6.9-8-12.3-17.3-15.9-27.4h-16.5c-6 0-11.2-4.3-12.2-10.3-2-12-2.1-24.6 0-37.1 1-6 6.2-10.4 12.2-10.4h16.5c3.6-10.1 9-19.4 15.9-27.4l-8.2-14.3c-3-5.2-1.9-11.9 2.8-15.7 9.5-7.9 20.4-14.2 32.1-18.6 5.7-2.1 12.1.1 15.1 5.4l8.2 14.3c10.5-1.9 21.2-1.9 31.7 0L552 6.3c3-5.3 9.4-7.5 15.1-5.4 11.8 4.4 22.6 10.7 32.1 18.6 4.6 3.8 5.8 10.5 2.8 15.7l-8.2 14.3c6.9 8 12.3 17.3 15.9 27.4h16.5c6 0 11.2 4.3 12.2 10.3 2 12 2.1 24.6 0 37.1-1 6-6.2 10.4-12.2 10.4h-16.5c-3.6 10.1-9 19.4-15.9 27.4l8.2 14.3c3 5.2 1.9 11.9-2.8 15.7-9.5 7.9-20.4 14.2-32.1 18.6-5.7 2.1-12.1-.1-15.1-5.4l-8.2-14.3c-10.4 1.9-21.2 1.9-31.7 0zm-10.5-58.8c38.5 29.6 82.4-14.3 52.8-52.8-38.5-29.7-82.4 14.3-52.8 52.8zM386.3 286.1l33.7 16.8c10.1 5.8 14.5 18.1 10.5 29.1-8.9 24.2-26.4 46.4-42.6 65.8-7.4 8.9-20.2 11.1-30.3 5.3l-29.1-16.8c-16 13.7-34.6 24.6-54.9 31.7v33.6c0 11.6-8.3 21.6-19.7 23.6-24.6 4.2-50.4 4.4-75.9 0-11.5-2-20-11.9-20-23.6V418c-20.3-7.2-38.9-18-54.9-31.7L74 403c-10 5.8-22.9 3.6-30.3-5.3-16.2-19.4-33.3-41.6-42.2-65.7-4-10.9.4-23.2 10.5-29.1l33.3-16.8c-3.9-20.9-3.9-42.4 0-63.4L12 205.8c-10.1-5.8-14.6-18.1-10.5-29 8.9-24.2 26-46.4 42.2-65.8 7.4-8.9 20.2-11.1 30.3-5.3l29.1 16.8c16-13.7 34.6-24.6 54.9-31.7V57.1c0-11.5 8.2-21.5 19.6-23.5 24.6-4.2 50.5-4.4 76-.1 11.5 2 20 11.9 20 23.6v33.6c20.3 7.2 38.9 18 54.9 31.7l29.1-16.8c10-5.8 22.9-3.6 30.3 5.3 16.2 19.4 33.2 41.6 42.1 65.8 4 10.9.1 23.2-10 29.1l-33.7 16.8c3.9 21 3.9 42.5 0 63.5zm-117.6 21.1c59.2-77-28.7-164.9-105.7-105.7-59.2 77 28.7 164.9 105.7 105.7zm243.4 182.7l-8.2 14.3c-3 5.3-9.4 7.5-15.1 5.4-11.8-4.4-22.6-10.7-32.1-18.6-4.6-3.8-5.8-10.5-2.8-15.7l8.2-14.3c-6.9-8-12.3-17.3-15.9-27.4h-16.5c-6 0-11.2-4.3-12.2-10.3-2-12-2.1-24.6 0-37.1 1-6 6.2-10.4 12.2-10.4h16.5c3.6-10.1 9-19.4 15.9-27.4l-8.2-14.3c-3-5.2-1.9-11.9 2.8-15.7 9.5-7.9 20.4-14.2 32.1-18.6 5.7-2.1 12.1.1 15.1 5.4l8.2 14.3c10.5-1.9 21.2-1.9 31.7 0l8.2-14.3c3-5.3 9.4-7.5 15.1-5.4 11.8 4.4 22.6 10.7 32.1 18.6 4.6 3.8 5.8 10.5 2.8 15.7l-8.2 14.3c6.9 8 12.3 17.3 15.9 27.4h16.5c6 0 11.2 4.3 12.2 10.3 2 12 2.1 24.6 0 37.1-1 6-6.2 10.4-12.2 10.4h-16.5c-3.6 10.1-9 19.4-15.9 27.4l8.2 14.3c3 5.2 1.9 11.9-2.8 15.7-9.5 7.9-20.4 14.2-32.1 18.6-5.7 2.1-12.1-.1-15.1-5.4l-8.2-14.3c-10.4 1.9-21.2 1.9-31.7 0zM501.6 431c38.5 29.6 82.4-14.3 52.8-52.8-38.5-29.6-82.4 14.3-52.8 52.8z",
        },
        child: [],
      },
    ],
  })(e);
}
function fy(e) {
  return Se({
    attr: { viewBox: "0 0 512 512" },
    child: [
      {
        tag: "path",
        attr: {
          d: "M496 384H64V80c0-8.84-7.16-16-16-16H16C7.16 64 0 71.16 0 80v336c0 17.67 14.33 32 32 32h464c8.84 0 16-7.16 16-16v-32c0-8.84-7.16-16-16-16zM464 96H345.94c-21.38 0-32.09 25.85-16.97 40.97l32.4 32.4L288 242.75l-73.37-73.37c-12.5-12.5-32.76-12.5-45.25 0l-68.69 68.69c-6.25 6.25-6.25 16.38 0 22.63l22.62 22.62c6.25 6.25 16.38 6.25 22.63 0L192 237.25l73.37 73.37c12.5 12.5 32.76 12.5 45.25 0l96-96 32.4 32.4c15.12 15.12 40.97 4.41 40.97-16.97V112c.01-8.84-7.15-16-15.99-16z",
        },
        child: [],
      },
    ],
  })(e);
}
function Ek(e) {
  return Se({
    attr: { viewBox: "0 0 512 512" },
    child: [
      {
        tag: "path",
        attr: {
          d: "M499.99 176h-59.87l-16.64-41.6C406.38 91.63 365.57 64 319.5 64h-127c-46.06 0-86.88 27.63-103.99 70.4L71.87 176H12.01C4.2 176-1.53 183.34.37 190.91l6 24C7.7 220.25 12.5 224 18.01 224h20.07C24.65 235.73 16 252.78 16 272v48c0 16.12 6.16 30.67 16 41.93V416c0 17.67 14.33 32 32 32h32c17.67 0 32-14.33 32-32v-32h256v32c0 17.67 14.33 32 32 32h32c17.67 0 32-14.33 32-32v-54.07c9.84-11.25 16-25.8 16-41.93v-48c0-19.22-8.65-36.27-22.07-48H494c5.51 0 10.31-3.75 11.64-9.09l6-24c1.89-7.57-3.84-14.91-11.65-14.91zm-352.06-17.83c7.29-18.22 24.94-30.17 44.57-30.17h127c19.63 0 37.28 11.95 44.57 30.17L384 208H128l19.93-49.83zM96 319.8c-19.2 0-32-12.76-32-31.9S76.8 256 96 256s48 28.71 48 47.85-28.8 15.95-48 15.95zm320 0c-19.2 0-48 3.19-48-15.95S396.8 256 416 256s32 12.76 32 31.9-12.8 31.9-32 31.9z",
        },
        child: [],
      },
    ],
  })(e);
}
function Mk(e) {
  return Se({
    attr: { viewBox: "0 0 496 512" },
    child: [
      {
        tag: "path",
        attr: {
          d: "M248 8C111.03 8 0 119.03 0 256s111.03 248 248 248 248-111.03 248-248S384.97 8 248 8zm0 432c-101.69 0-184-82.29-184-184 0-101.69 82.29-184 184-184 101.69 0 184 82.29 184 184 0 101.69-82.29 184-184 184zm0-312c-70.69 0-128 57.31-128 128s57.31 128 128 128 128-57.31 128-128-57.31-128-128-128zm0 192c-35.29 0-64-28.71-64-64s28.71-64 64-64 64 28.71 64 64-28.71 64-64 64z",
        },
        child: [],
      },
    ],
  })(e);
}
function Ak(e) {
  return Se({
    attr: { viewBox: "0 0 448 512" },
    child: [
      {
        tag: "path",
        attr: {
          d: "M436 480h-20V24c0-13.255-10.745-24-24-24H56C42.745 0 32 10.745 32 24v456H12c-6.627 0-12 5.373-12 12v20h448v-20c0-6.627-5.373-12-12-12zM128 76c0-6.627 5.373-12 12-12h40c6.627 0 12 5.373 12 12v40c0 6.627-5.373 12-12 12h-40c-6.627 0-12-5.373-12-12V76zm0 96c0-6.627 5.373-12 12-12h40c6.627 0 12 5.373 12 12v40c0 6.627-5.373 12-12 12h-40c-6.627 0-12-5.373-12-12v-40zm52 148h-40c-6.627 0-12-5.373-12-12v-40c0-6.627 5.373-12 12-12h40c6.627 0 12 5.373 12 12v40c0 6.627-5.373 12-12 12zm76 160h-64v-84c0-6.627 5.373-12 12-12h40c6.627 0 12 5.373 12 12v84zm64-172c0 6.627-5.373 12-12 12h-40c-6.627 0-12-5.373-12-12v-40c0-6.627 5.373-12 12-12h40c6.627 0 12 5.373 12 12v40zm0-96c0 6.627-5.373 12-12 12h-40c-6.627 0-12-5.373-12-12v-40c0-6.627 5.373-12 12-12h40c6.627 0 12 5.373 12 12v40zm0-96c0 6.627-5.373 12-12 12h-40c-6.627 0-12-5.373-12-12V76c0-6.627 5.373-12 12-12h40c6.627 0 12 5.373 12 12v40z",
        },
        child: [],
      },
    ],
  })(e);
}
function Lk(e) {
  return Se({
    attr: { viewBox: "0 0 512 512" },
    child: [
      {
        tag: "path",
        attr: {
          d: "M320 336c0 8.84-7.16 16-16 16h-96c-8.84 0-16-7.16-16-16v-48H0v144c0 25.6 22.4 48 48 48h416c25.6 0 48-22.4 48-48V288H320v48zm144-208h-80V80c0-25.6-22.4-48-48-48H176c-25.6 0-48 22.4-48 48v48H48c-25.6 0-48 22.4-48 48v80h512v-80c0-25.6-22.4-48-48-48zm-144 0H192V96h128v32z",
        },
        child: [],
      },
    ],
  })(e);
}
function Rk() {
  return a.jsxs("div", {
    children: [
      a.jsx("style", {
        children: `
        .mbi-body {
          font-family: 'Montserrat', sans-serif;
          font-weight: 400;
          text-align: justify;
        }
        p {
          text-align: justify;
        }
      `,
      }),
      a.jsxs("section", {
        className: "relative",
        children: [
          a.jsx("div", {
            className: "absolute inset-0 -z-10 bg-cover bg-center",
            style: {
              backgroundImage:
                "url('/assets/images/about us/2nd background pic.png')",
            },
          }),
          a.jsx("div", { className: "absolute inset-0 -z-10 bg-black/40" }),
          a.jsx("div", {
            className: "container-shell py-16 sm:py-24",
            children: a.jsxs(I, {
              children: [
                a.jsxs("h1", {
                  className:
                    "font-display text-5xl text-white sm:text-6xl lg:text-7xl",
                  children: ["About", a.jsx("br", {}), "Us"],
                }),
                a.jsx("div", {
                  className: "mt-3 h-1 w-12 rounded-full bg-white",
                }),
              ],
            }),
          }),
        ],
      }),
      a.jsx("section", {
        className: "container-shell py-14 sm:py-16",
        children: a.jsxs("div", {
          className: "grid items-center gap-10 lg:grid-cols-2",
          children: [
            a.jsxs(I, {
              children: [
                a.jsx("h2", {
                  className:
                    "font-display text-3xl font-bold text-brand-pink sm:text-4xl",
                  children: "About Us",
                }),
                a.jsx("p", {
                  className:
                    "mbi-body mt-6 text-sm leading-relaxed text-brand-pink/80 sm:text-base",
                  children:
                    "Welcome to Matseke Business Investment, an FSCA-authorised Financial Services Provider in South Africa, offering financial planning, business assurance, retirement, medical aid, investment, and endowment fund solutions. We partner with individuals and businesses to provide trusted, personalised advice that helps secure, grow, and protect their financial future.",
                }),
                a.jsx("div", {
                  className: "mt-8",
                  children: a.jsx(ye, {
                    to: "/contact",
                    children: a.jsx(dy, {
                      size: "lg",
                      children: "GET IN TOUCH",
                    }),
                  }),
                }),
              ],
            }),
            a.jsx(I, {
              delayMs: 120,
              children: a.jsx("div", {
                className: "overflow-hidden rounded-2xl shadow-soft",
                children: a.jsx("img", {
                  src: "/assets/images/about us/1st image.jpeg",
                  alt: "Team and advisory services",
                  className: "h-[320px] w-full object-cover sm:h-[420px]",
                  loading: "lazy",
                }),
              }),
            }),
          ],
        }),
      }),
      a.jsx("section", {
        className: "bg-brand-pink py-12 sm:py-14",
        children: a.jsx("div", {
          className: "container-shell",
          children: a.jsxs(I, {
            children: [
              a.jsx("h3", {
                className:
                  "text-center font-display text-3xl font-bold text-white sm:text-4xl",
                children: "Trusted Investment Guidance and Services",
              }),
              a.jsx("p", {
                className:
                  "mx-auto mt-4 max-w-3xl text-center text-sm leading-relaxed text-white/90 sm:text-base",
                style: { textAlign: "center" },
                children:
                  "We are a trusted investment and financial advisory firm providing tailored solutions to individuals, entrepreneurs, and corporates.",
              }),
            ],
          }),
        }),
      }),
      a.jsxs("section", {
        className: "container-shell py-14 sm:py-16",
        children: [
          a.jsx(I, {
            children: a.jsx("h3", {
              className:
                "text-center font-display text-3xl font-bold text-brand-pink sm:text-4xl",
              children: "Our Team",
            }),
          }),
          a.jsx(I, {
            delayMs: 80,
            children: a.jsx("div", {
              className:
                "mx-auto mt-8 max-w-3xl overflow-hidden rounded-2xl shadow-soft",
              children: a.jsx("img", {
                src: "/assets/images/about us/3rd background pic.png",
                alt: "Our team",
                className: "h-[340px] w-full object-cover sm:h-[420px]",
                loading: "lazy",
              }),
            }),
          }),
          a.jsx(I, {
            delayMs: 120,
            children: a.jsx("p", {
              className:
                "mx-auto mt-8 max-w-3xl text-sm leading-relaxed text-brand-pink/80 sm:text-base mbi-body",
              children:
                "Our team is made up of experienced professionals who are experts in their respective fields, dedicated to delivering trusted financial advice and building long-term relationships that support sustainable wealth and financial security.",
            }),
          }),
        ],
      }),
      a.jsx("section", {
        className: "bg-brand-pink py-14 sm:py-16",
        children: a.jsx("div", {
          className: "container-shell",
          children: a.jsx("div", {
            className:
              "grid grid-cols-1 divide-y divide-white/20 sm:grid-cols-3 sm:divide-x sm:divide-y-0",
            children: [
              {
                icon: a.jsx(Ak, { className: "h-14 w-14 text-white" }),
                title: "Integrity & Trust",
                desc: "We operate with transparency, ethics and accountability.",
              },
              {
                icon: a.jsx(fy, { className: "h-14 w-14 text-white" }),
                title: "Client-Centric Approach",
                desc: "Every solution is tailored to our clients' unique needs and goals.",
              },
              {
                icon: a.jsx(_l, { className: "h-14 w-14 text-white" }),
                title: `Compliance &
Transparency`,
                desc: "Fully compliant advisory services aligned with regulatory standards.",
              },
            ].map((e, t) =>
              a.jsx(
                I,
                {
                  delayMs: t * 80,
                  children: a.jsxs("div", {
                    className:
                      "flex flex-col items-center px-8 py-10 text-center text-white",
                    children: [
                      a.jsx("div", {
                        className: "flex h-20 items-center justify-center",
                        children: e.icon,
                      }),
                      a.jsx("h4", {
                        className: "mt-6 text-lg font-bold whitespace-pre-line",
                        children: e.title,
                      }),
                      a.jsx("p", {
                        className:
                          "mt-3 text-sm leading-relaxed text-white/80 max-w-[200px]",
                        style: { textAlign: "center" },
                        children: e.desc,
                      }),
                    ],
                  }),
                },
                e.title,
              ),
            ),
          }),
        }),
      }),
      a.jsxs("section", {
        className: "container-shell py-14 sm:py-16",
        children: [
          a.jsx(I, {
            children: a.jsxs("div", {
              className: "flex items-start gap-5",
              children: [
                a.jsx(_l, {
                  className: "mt-1 h-10 w-10 shrink-0 text-brand-pink",
                }),
                a.jsxs("div", {
                  children: [
                    a.jsx("h3", {
                      className:
                        "font-display text-3xl font-bold text-brand-pink sm:text-4xl",
                      children: "Our Credentials",
                    }),
                    a.jsx("p", {
                      className:
                        "mbi-body mt-4 max-w-4xl text-sm leading-relaxed text-brand-pink/80 sm:text-base",
                      children:
                        "Matseke Business Investment is an FSCA-authorised Financial Services Provider, offering regulated and compliant financial and investment advisory services to individuals, professionals, and businesses across South Africa. Our team is qualified, experienced, and committed to delivering ethical, transparent, and client-focused financial solutions.",
                    }),
                  ],
                }),
              ],
            }),
          }),
          a.jsxs("div", {
            className: "mt-12 grid gap-6 md:grid-cols-2",
            children: [
              a.jsx(I, {
                children: a.jsxs("div", {
                  className: "card h-full p-8",
                  children: [
                    a.jsxs("div", {
                      className: "flex items-center gap-4 mb-4",
                      children: [
                        a.jsx(Tk, { className: "h-8 w-8 text-brand-pink" }),
                        a.jsx("h4", {
                          className:
                            "font-display text-2xl font-bold text-brand-pink",
                          children: "Our Vision",
                        }),
                      ],
                    }),
                    a.jsx("p", {
                      className:
                        "mbi-body text-sm leading-relaxed text-brand-pink/80 sm:text-base",
                      children:
                        "Matseke Business Investment is an FSCA-authorised Financial Services Provider in South Africa, offering expert guidance in financial planning, business assurance, retirement planning.",
                    }),
                  ],
                }),
              }),
              a.jsx(I, {
                delayMs: 120,
                children: a.jsxs("div", {
                  className: "card h-full p-8",
                  children: [
                    a.jsxs("div", {
                      className: "flex items-center gap-4 mb-4",
                      children: [
                        a.jsx(Mk, { className: "h-8 w-8 text-brand-pink" }),
                        a.jsx("h4", {
                          className:
                            "font-display text-2xl font-bold text-brand-pink",
                          children: "Our Mission",
                        }),
                      ],
                    }),
                    a.jsx("p", {
                      className:
                        "mbi-body text-sm leading-relaxed text-brand-pink/80 sm:text-base",
                      children:
                        "Matseke Business Investment is an FSCA-authorised Financial Services Provider in South Africa, offering expert guidance in financial planning, business assurance, retirement planning.",
                    }),
                  ],
                }),
              }),
            ],
          }),
        ],
      }),
    ],
  });
}
const Dk = [
    {
      icon: a.jsx(Sk, { className: "h-6 w-6 text-white" }),
      title: "Life Cover",
      desc: "Providing financial security for your loved ones through tailored life insurance solutions.",
    },
    {
      icon: a.jsx(Lk, { className: "h-6 w-6 text-white" }),
      title: "Business Assurance",
      desc: "Protecting businesses and key individuals with structured risk and continuity planning.",
    },
    {
      icon: a.jsx(bk, { className: "h-6 w-6 text-white" }),
      title: "Health Insurance",
      desc: "Advising on medical aid and healthcare cover to safeguard your well-being.",
    },
    {
      icon: a.jsx(Ek, { className: "h-6 w-6 text-white" }),
      title: "Short Term Insurance",
      desc: "Cover for assets such as vehicles, property, and business risks against unforeseen events.",
    },
    {
      icon: a.jsx(fy, { className: "h-6 w-6 text-white" }),
      title: "Wealth Management",
      desc: "Strategic investment solutions aligned to your goals, risk profile, and long-term growth.",
    },
    {
      icon: a.jsx(Pk, { className: "h-6 w-6 text-white" }),
      title: "Investment Products",
      desc: "Holistic wealth planning and management to build, preserve, and transfer wealth across generations.",
    },
  ],
  Ik = [
    {
      icon: a.jsx(Ck, { className: "h-14 w-14 text-white" }),
      title: "Value for Money",
      desc: "We operate in full alignment with regulatory standards and ethical practices, ensuring transparency, trust, and accountability in every engagement.",
    },
    {
      icon: a.jsx(Nk, { className: "h-14 w-14 text-white" }),
      title: "Expertise & Professionalism",
      desc: "We are committed to delivering cost-effective, high-quality financial solutions that provide meaningful value and long-term benefits for our clients.",
    },
    {
      icon: a.jsx(_l, { className: "h-14 w-14 text-white" }),
      title: "Compliance & Integrity",
      desc: "We offer knowledgeable, qualified, and experienced advisory services, delivering sound financial guidance with excellence and confidence.",
    },
  ],
  Vk = [
    {
      logo: "/assets/images/services/iol-logo.png",
      source: "IOL News",
      title: "Golf is not a sport, it is business",
      date: "Published 3 years ago",
      excerpt:
        "Golf days have largely been the forte of the mainstream (white) business, but it is pleasing that black business is getting on the bandwagon and reaping rewards.",
      href: "#",
    },
    {
      logo: "/assets/images/services/sentinel-logo.png",
      source: "The Sentinel",
      title: "Black firms leverage the business ....",
      date: "Published 3 years ago",
      excerpt:
        "It becomes challenging to fill up the field with such a high calibre of people. But we are excited because this year we are looking at more than 60 golfers ....",
      href: "#",
    },
    {
      logo: "/assets/images/services/pressreader-logo.png",
      source: "PressReader",
      title: "Financial advisers are crucial to the economy",
      date: "Published 3 years ago",
      excerpt:
        "In the era of Bitcoin and conspicuous consumption, many vulnerable investors lose their money at the hands of charlatans posing as financial advisers.",
      href: "#",
    },
  ];
function Bk() {
  return a.jsxs("div", {
    children: [
      a.jsx("style", {
        children: `
        .mbi-body {
          font-family: 'Montserrat', sans-serif;
          font-weight: 400;
          text-align: justify;
        }
        p {
          text-align: justify;
        }
      `,
      }),
      a.jsxs("section", {
        className: "relative",
        children: [
          a.jsx("div", {
            className: "absolute inset-0 -z-10 bg-cover bg-center",
            style: {
              backgroundImage:
                "url('/assets/images/services/last picture.jpg')",
            },
          }),
          a.jsx("div", { className: "absolute inset-0 -z-10 bg-black/30" }),
          a.jsx("div", {
            className: "container-shell py-16 sm:py-24",
            children: a.jsxs(I, {
              children: [
                a.jsxs("h1", {
                  className:
                    "font-display text-5xl text-white sm:text-6xl lg:text-7xl",
                  children: ["Our", a.jsx("br", {}), "Services"],
                }),
                a.jsx("div", {
                  className: "mt-3 h-1 w-12 rounded-full bg-white",
                }),
              ],
            }),
          }),
        ],
      }),
      a.jsx("section", {
        className: "container-shell py-14 sm:py-16",
        children: a.jsx("div", {
          className: "grid gap-6 sm:grid-cols-3",
          style: { alignItems: "stretch" },
          children: Ik.map((e, t) =>
            a.jsx(
              I,
              {
                delayMs: t * 80,
                style: { height: "100%" },
                children: a.jsxs("div", {
                  className:
                    "flex h-full flex-col items-center rounded-2xl bg-brand-pink p-8 text-center text-white shadow-soft",
                  children: [
                    a.jsx("div", {
                      className: "flex h-20 items-center justify-center mb-5",
                      children: e.icon,
                    }),
                    a.jsx("h3", {
                      className: "text-lg font-bold",
                      children: e.title,
                    }),
                    a.jsx("p", {
                      className: "mt-4 text-sm leading-relaxed text-white/85",
                      style: { textAlign: "center" },
                      children: e.desc,
                    }),
                  ],
                }),
              },
              e.title,
            ),
          ),
        }),
      }),
      a.jsxs("section", {
        className: "container-shell pb-14 sm:pb-16",
        children: [
          a.jsxs(I, {
            children: [
              a.jsx("h2", {
                className:
                  "text-center font-display text-3xl font-bold text-brand-pink sm:text-4xl",
                children: "Services",
              }),
              a.jsx("p", {
                className:
                  "mt-3 text-center text-sm text-brand-pink/70 sm:text-base",
                style: { textAlign: "center" },
                children:
                  "Trusted financial solutions for growth, protection, and long-term security.",
              }),
            ],
          }),
          a.jsx("div", {
            className:
              "mt-12 grid gap-x-10 gap-y-10 sm:grid-cols-2 lg:grid-cols-3",
            children: Dk.map((e, t) =>
              a.jsx(
                I,
                {
                  delayMs: t * 70,
                  children: a.jsxs("div", {
                    className: "flex items-start gap-4",
                    children: [
                      a.jsx("div", {
                        className:
                          "flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-brand-pink",
                        children: e.icon,
                      }),
                      a.jsxs("div", {
                        children: [
                          a.jsx("h4", {
                            className: "text-lg font-bold text-brand-pink",
                            children: e.title,
                          }),
                          a.jsx("p", {
                            className:
                              "mbi-body mt-2 text-sm leading-relaxed text-black/60",
                            children: e.desc,
                          }),
                        ],
                      }),
                    ],
                  }),
                },
                e.title,
              ),
            ),
          }),
        ],
      }),
      a.jsx("section", {
        className: "bg-brand-pink py-14 sm:py-16",
        children: a.jsxs("div", {
          className: "container-shell",
          children: [
            a.jsxs(I, {
              children: [
                a.jsx("h2", {
                  className:
                    "text-center font-display text-3xl font-bold text-white sm:text-4xl",
                  children: "News",
                }),
                a.jsx("div", {
                  className: "mx-auto mt-3 h-1 w-16 rounded-full bg-white",
                }),
              ],
            }),
            a.jsx("div", {
              className: "mt-10 grid gap-6 sm:grid-cols-3",
              style: { alignItems: "stretch" },
              children: Vk.map((e, t) =>
                a.jsx(
                  I,
                  {
                    delayMs: t * 80,
                    style: { height: "100%" },
                    children: a.jsxs("div", {
                      className:
                        "flex h-full flex-col rounded-2xl bg-white p-6 shadow-soft",
                      children: [
                        a.jsxs("div", {
                          className: "flex items-center gap-3 mb-4",
                          children: [
                            a.jsx("img", {
                              src: e.logo,
                              alt: e.source,
                              className: "h-10 w-10 rounded object-contain",
                              onError: (n) => {
                                n.target.style.display = "none";
                              },
                            }),
                            a.jsxs("div", {
                              children: [
                                a.jsx("p", {
                                  className: "text-sm font-bold text-black",
                                  children: e.title,
                                }),
                                a.jsx("p", {
                                  className: "text-xs text-black/50",
                                  style: { textAlign: "left" },
                                  children: e.date,
                                }),
                              ],
                            }),
                          ],
                        }),
                        a.jsx("p", {
                          className:
                            "mbi-body flex-1 text-sm italic leading-relaxed text-black/50",
                          children: e.excerpt,
                        }),
                        a.jsx("div", {
                          className: "mt-6",
                          children: a.jsx("a", {
                            href: e.href,
                            children: a.jsx(dy, {
                              size: "md",
                              children: "READ MORE",
                            }),
                          }),
                        }),
                      ],
                    }),
                  },
                  e.title,
                ),
              ),
            }),
          ],
        }),
      }),
      a.jsxs("section", {
        className: "relative overflow-hidden py-24 sm:py-28",
        style: {
          backgroundImage: "url('/assets/images/services/last picture.jpg')",
          backgroundSize: "cover",
          backgroundPosition: "center",
        },
        children: [
          a.jsx("div", { className: "absolute inset-0 bg-black/50" }),
          a.jsxs("div", {
            className:
              "container-shell relative flex flex-col items-center gap-8 text-center",
            children: [
              a.jsx(I, {
                children: a.jsx("h2", {
                  className:
                    "font-display text-3xl font-bold text-white sm:text-4xl lg:text-5xl",
                  children: "Partner with us, Now!",
                }),
              }),
              a.jsx(I, {
                delayMs: 100,
                children: a.jsx(ye, {
                  to: "/contact",
                  children: a.jsx("button", {
                    className:
                      "rounded-lg bg-brand-pink px-8 py-4 text-sm font-semibold tracking-wide text-white transition-opacity hover:opacity-90",
                    children: "Schedule a Strategy Session",
                  }),
                }),
              }),
            ],
          }),
        ],
      }),
    ],
  });
}
const ce = "#000000",
  Rr = "#e26991",
  ns = 3,
  Gf = 4e3,
  Yf = [
    {
      image: "/assets/images/events/businessCards/c1.jpeg",
      title: "2021 – Johannesburg Country Club",
      desc: "The inaugural MBI Golf Day was hosted in 2021 at the prestigious Country Club Johannesburg, marking the beginning of what has become a valued annual event for the firm and its professional network. The event brought together clients, partners and industry leaders in a relaxed environment where meaningful business connections could develop beyond the boardroom. This first edition laid the foundation for the MBI Golf Day as a platform for collaboration, partnership and the strengthening of long term professional relationships within the MBI community.",
    },
    {
      image: "/assets/images/events/businessCards/C2.jpg",
      title: "2022 – The Club at Steyn City",
      desc: "The second annual MBI Golf Day was hosted in 2022 at The Club at Steyn City, one of Johannesburg's most prestigious golf destinations. The event brought together executives, entrepreneurs and industry professionals for meaningful engagement and business networking on and off the course. The day concluded with a prize giving dinner and wine tasting experience. Supported by partners including Clinix Health Group and EasyDebit, the event continued to strengthen relationships within the MBI community.",
    },
    {
      image: "/assets/images/events/businessCards/C3.png",
      title: "2023 – Pretoria Country Club",
      desc: "The 2023 MBI Golf Day took place at the prestigious Pretoria Country Club, a venue renowned for its immaculate fairways and championship standard facilities. Hosted in partnership with Bonitas Medical Fund, the event brought together executives, entrepreneurs, decision makers and industry leaders. The day provided a premium environment where business conversations could flourish naturally, relationships were strengthened and new partnerships were explored.",
    },
    {
      image: "/assets/images/events/businessCards/C2.jpeg",
      title: "2024 – Kyalami Country Club",
      desc: "The 2024 MBI Golf Day took place at the prestigious Kyalami Country Club, providing the perfect setting for a day of meaningful connection and high level engagement. In partnership with leading industry players, the event welcomed executives, entrepreneurs and decision makers, with a stronger emphasis on interactive networking both on and off the course. The day celebrated milestones within the MBI community, reinforcing MBI's reputation for hosting events that bring together business growth, connection and collaboration.",
    },
    {
      image: "/assets/images/events/businessCards/C5.jpeg",
      title: "2025 – Country Club Johannesburg Woodmead",
      desc: "The 2025 MBI Golf Day was hosted at the esteemed Country Club Johannesburg Woodmead, a course known for its challenging layout and pristine fairways. The venue provided an ideal setting for a day focused on business engagement and relationship building. The event brought together executives, entrepreneurs and decision makers across industries, creating opportunities to connect in a relaxed yet professional environment and explore new partnerships.",
    },
  ],
  Ok = `
  .mbi-heading { font-family: 'Montserrat', sans-serif; font-weight: 600; }
  .mbi-body    { font-family: 'Montserrat', sans-serif; font-weight: 400; text-align: justify; }
  p            { text-align: justify; }
  .line-clamp-3 {
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    overflow: hidden;
  }
`,
  Fk = j.memo(function ({ card: t, onFlip: n }) {
    const [r, i] = j.useState(!1),
      s = j.useCallback(() => {
        const o = !r;
        (i(o), n(o));
      }, [r, n]);
    return a.jsx("div", {
      className: "cursor-pointer",
      style: { perspective: "1200px", height: "420px" },
      onClick: s,
      children: a.jsxs("div", {
        style: {
          position: "relative",
          width: "100%",
          height: "100%",
          transformStyle: "preserve-3d",
          transition: "transform 1.1s cubic-bezier(0.645, 0.045, 0.355, 1.000)",
          transform: r ? "rotateY(180deg)" : "rotateY(0deg)",
        },
        children: [
          a.jsxs("div", {
            style: {
              position: "absolute",
              inset: 0,
              backfaceVisibility: "hidden",
              WebkitBackfaceVisibility: "hidden",
              overflow: "hidden",
            },
            className: "bg-white shadow-soft",
            children: [
              a.jsx("img", {
                src: t.image,
                alt: t.title,
                className: "h-[220px] w-full object-cover object-top",
                loading: "lazy",
                decoding: "async",
                width: 400,
                height: 220,
              }),
              a.jsxs("div", {
                className: "p-5",
                children: [
                  a.jsx("h4", {
                    className: "mbi-heading font-bold text-sm",
                    style: { color: ce },
                    children: t.title,
                  }),
                  a.jsx("p", {
                    className:
                      "mbi-body mt-2 text-xs leading-relaxed text-gray-500 line-clamp-3",
                    children: t.desc,
                  }),
                  a.jsx("p", {
                    className:
                      "mbi-heading mt-4 text-xs font-semibold uppercase tracking-widest",
                    style: { color: ce, opacity: 0.5, textAlign: "left" },
                    children: "Click to read more ↗",
                  }),
                ],
              }),
            ],
          }),
          a.jsxs("div", {
            style: {
              position: "absolute",
              inset: 0,
              backfaceVisibility: "hidden",
              WebkitBackfaceVisibility: "hidden",
              transform: "rotateY(180deg)",
              backgroundColor: ce,
              padding: "1.75rem",
              display: "flex",
              flexDirection: "column",
              justifyContent: "space-between",
            },
            className: "shadow-soft",
            children: [
              a.jsxs("div", {
                children: [
                  a.jsx("h4", {
                    className: "mbi-heading font-bold text-sm text-white mb-3",
                    children: t.title,
                  }),
                  a.jsx("p", {
                    className: "mbi-body text-xs leading-relaxed text-white/90",
                    children: t.desc,
                  }),
                ],
              }),
              a.jsx("p", {
                className:
                  "mbi-heading mt-4 text-xs font-semibold uppercase tracking-widest text-white",
                style: { opacity: 0.5, textAlign: "left" },
                children: "Click to go back ↩",
              }),
            ],
          }),
        ],
      }),
    });
  });
j.memo(function ({ event: t, index: n }) {
  const [r, i] = j.useState(!1);
  return a.jsx(I, {
    delayMs: n * 100,
    children: a.jsx("div", {
      className: "cursor-pointer",
      style: { perspective: "1200px", height: "520px" },
      onClick: () => i((s) => !s),
      children: a.jsxs("div", {
        style: {
          position: "relative",
          width: "100%",
          height: "100%",
          transformStyle: "preserve-3d",
          transition: "transform 1.1s cubic-bezier(0.645, 0.045, 0.355, 1.000)",
          transform: r ? "rotateY(180deg)" : "rotateY(0deg)",
        },
        children: [
          a.jsxs("div", {
            style: {
              position: "absolute",
              inset: 0,
              backfaceVisibility: "hidden",
              WebkitBackfaceVisibility: "hidden",
              borderRadius: "1rem",
              overflow: "hidden",
            },
            className: "shadow-soft bg-white",
            children: [
              a.jsx("img", {
                src: t.image,
                alt: t.title,
                style: { width: "100%", height: "280px", objectFit: "cover" },
                loading: "lazy",
                decoding: "async",
                width: 600,
                height: 280,
              }),
              a.jsxs("div", {
                style: { padding: "1.5rem" },
                children: [
                  a.jsx("h4", {
                    className: "mbi-heading font-bold text-lg",
                    style: { color: ce },
                    children: t.title,
                  }),
                  a.jsx("p", {
                    className: "mbi-body mt-3 text-sm leading-relaxed",
                    style: { color: `${ce}b3` },
                    children: t.desc,
                  }),
                  a.jsx("p", {
                    className:
                      "mbi-heading mt-5 text-xs font-semibold uppercase tracking-widest",
                    style: { color: ce, opacity: 0.5, textAlign: "left" },
                    children: "Click to read more ↗",
                  }),
                ],
              }),
            ],
          }),
          a.jsxs("div", {
            style: {
              position: "absolute",
              inset: 0,
              backfaceVisibility: "hidden",
              WebkitBackfaceVisibility: "hidden",
              transform: "rotateY(180deg)",
              borderRadius: "1rem",
              overflow: "hidden",
              backgroundColor: ce,
              padding: "2rem",
              display: "flex",
              flexDirection: "column",
              justifyContent: "center",
            },
            className: "shadow-soft",
            children: [
              a.jsx("h4", {
                className: "mbi-heading font-bold text-lg text-white mb-4",
                children: t.title,
              }),
              a.jsx("div", {
                style: { overflowY: "auto", flex: 1 },
                children: t.back.map((s, o) =>
                  a.jsx(
                    "p",
                    {
                      className: "mbi-body text-sm leading-relaxed text-white",
                      style: {
                        marginBottom: o < t.back.length - 1 ? "0.85rem" : 0,
                        opacity: 0.92,
                      },
                      children: s,
                    },
                    o,
                  ),
                ),
              }),
              a.jsx("p", {
                className:
                  "mbi-heading mt-4 text-xs font-semibold uppercase tracking-widest text-white",
                style: { opacity: 0.5, textAlign: "left" },
                children: "Click to go back ↩",
              }),
            ],
          }),
        ],
      }),
    }),
  });
});
function zk() {
  const e = [
    { label: "Venue", sub: "TBC" },
    { label: "Date", sub: "11 December 2026" },
  ];
  return a.jsx("section", {
    style: { backgroundColor: "#ffffff" },
    className: "py-20 sm:py-28",
    children: a.jsxs("div", {
      className: "container-shell",
      children: [
        a.jsx(I, {
          children: a.jsxs("div", {
            className: "flex items-center gap-4 mb-16",
            children: [
              a.jsx("div", {
                className: "h-px w-8",
                style: { backgroundColor: Rr },
              }),
              a.jsx("span", {
                className:
                  "mbi-heading text-xs font-bold uppercase tracking-[0.22em]",
                style: { color: Rr },
                children: "Upcoming Golf Day",
              }),
              a.jsx("div", {
                className: "flex-1 h-px",
                style: { backgroundColor: "rgba(0,0,0,0.10)" },
              }),
            ],
          }),
        }),
        a.jsxs("div", {
          className: "grid gap-16 lg:grid-cols-[1fr_380px] lg:items-center",
          children: [
            a.jsx(I, {
              children: a.jsxs("div", {
                children: [
                  a.jsxs("h2", {
                    className: "mbi-heading font-bold",
                    style: {
                      fontSize: "clamp(1.9rem, 3.5vw, 2.8rem)",
                      lineHeight: 1.15,
                      letterSpacing: "-0.01em",
                      color: ce,
                    },
                    children: [
                      "MBI Annual Golf Day",
                      a.jsx("span", {
                        className: "block mt-1",
                        style: {
                          color: Rr,
                          fontSize: "0.55em",
                          fontWeight: 400,
                          letterSpacing: "0.05em",
                          fontFamily: "'Montserrat', sans-serif",
                        },
                        children: "2026 Edition",
                      }),
                    ],
                  }),
                  a.jsxs("div", {
                    className: "mt-8 space-y-4 max-w-lg",
                    children: [
                      a.jsx("p", {
                        className: "mbi-body text-sm leading-relaxed",
                        style: { color: "rgba(0,0,0,0.75)" },
                        children:
                          "Join us at our upcoming Annual Golf Day — an exclusive experience that brings together business leaders, partners and industry professionals in a premium setting designed for meaningful connection.",
                      }),
                      a.jsx("p", {
                        className: "mbi-body text-sm leading-relaxed",
                        style: { color: "rgba(0,0,0,0.75)" },
                        children:
                          "From the first tee to the prize giving dinner, every detail is curated to foster collaboration, strengthen relationships and open new doors. Further details on the venue, programme and registration will be announced soon.",
                      }),
                    ],
                  }),
                  a.jsx("div", {
                    className: "mt-10",
                    children: a.jsx("a", {
                      href: "https://forms.gle/GNNsbkSkGFrSn5ky6",
                      target: "_blank",
                      rel: "noopener noreferrer",
                      className:
                        "mbi-heading inline-block px-8 py-3.5 text-xs font-bold uppercase tracking-[0.18em] text-white transition-opacity hover:opacity-80 rounded-none",
                      style: { backgroundColor: Rr },
                      children: "RSVP",
                    }),
                  }),
                ],
              }),
            }),
            a.jsx(I, {
              delayMs: 100,
                children: a.jsx("img", {
                  src: "/assets/images/events/mbi-golf-day-poster.jpg",
                  alt: "MBI 6th Annual Golf Day, 10 December 2026, CCJ Woodmead, Johannesburg",
                  className: "w-full h-auto",
                  style: { border: "1px solid rgba(0,0,0,0.10)" },
                }),
            }),
          ],
        }),
      ],
    }),
  });
}
function _k() {
  const [e, t] = j.useState(0),
    [n, r] = j.useState("next"),
    [i, s] = j.useState(!1),
    [o, l] = j.useState(0),
    [u, c] = j.useState(!1),
    d = j.useRef(null),
    f = j.useRef(0),
    h = j.useRef(!1),
    m = Math.ceil(Yf.length / ns),
    v = j.useCallback((b, P = "next") => {
      h.current ||
        (r(P),
        s(!0),
        (h.current = !0),
        c(!1),
        setTimeout(() => {
          (l(b), t(b), (f.current = b), s(!1), (h.current = !1));
        }, 350));
    }, []),
    x = j.useCallback(() => {
      v((f.current + 1) % m, "next");
    }, [v, m]),
    k = j.useCallback(() => {
      const b = f.current === 0 ? m - 1 : f.current - 1;
      v(b, "prev");
    }, [v, m]);
  j.useEffect(() => {
    if (u) {
      d.current && clearInterval(d.current);
      return;
    }
    return (
      (d.current = setInterval(x, Gf)),
      () => {
        d.current && clearInterval(d.current);
      }
    );
  }, [x, u]);
  const g = j.useCallback(() => {
      d.current && clearInterval(d.current);
    }, []),
    p = j.useCallback(() => {
      u || (d.current = setInterval(x, Gf));
    }, [u, x]),
    y = j.useCallback((b) => c(b), []),
    w = Yf.slice(o * ns, o * ns + ns),
    S = {
      transition: "opacity 0.35s ease, transform 0.35s ease",
      opacity: i ? 0 : 1,
      transform: i
        ? `translateX(${n === "next" ? "-40px" : "40px"})`
        : "translateX(0)",
    };
  return a.jsxs("div", {
    style: { backgroundColor: "#ffffff" },
    children: [
      a.jsx("style", { children: Ok }),
      a.jsxs("section", {
        className: "relative min-h-[520px] flex items-center overflow-hidden",
        children: [
          a.jsx("img", {
            src: "/assets/images/events/hero.webp",
            alt: "",
            "aria-hidden": "true",
            fetchPriority: "high",
            loading: "eager",
            decoding: "sync",
            width: 1920,
            height: 520,
            className:
              "absolute inset-0 w-full h-full object-cover object-center",
          }),
          a.jsx("div", {
            className: "absolute inset-0",
            style: { backgroundColor: "rgba(0,0,0,0.50)" },
          }),
          a.jsx("div", {
            className: "relative z-10 w-full container-shell py-20 sm:py-32",
            children: a.jsxs(I, {
              children: [
                a.jsx("h1", {
                  className:
                    "mbi-heading text-5xl font-bold text-white sm:text-6xl lg:text-7xl text-center",
                  children: "Annual Golf Day",
                }),
                a.jsx("div", { className: "mx-auto mt-4 h-0.5 w-16 bg-white" }),
                a.jsx("p", {
                  className:
                    "mbi-body mt-6 text-center text-white text-sm sm:text-base max-w-2xl mx-auto",
                  style: {
                    textAlign: "center",
                    textShadow: "0 1px 6px rgba(0,0,0,0.6)",
                  },
                  children:
                    "A premium business and networking event for leaders, entrepreneurs, and partners.",
                }),
              ],
            }),
          }),
        ],
      }),
      a.jsx(zk, {}),
      a.jsx("section", {
        className: "py-14 sm:py-20",
        style: { backgroundColor: "#ffffff" },
        children: a.jsxs("div", {
          className: "container-shell",
          children: [
            a.jsx(I, {
              children: a.jsx("h2", {
                className:
                  "mbi-heading text-center text-3xl font-bold sm:text-4xl mb-10",
                style: { color: ce },
                children: "Recent Events",
              }),
            }),
            a.jsxs("div", {
              className: "relative",
              onMouseEnter: g,
              onMouseLeave: p,
              children: [
                a.jsx("button", {
                  onClick: k,
                  className:
                    "absolute -left-5 top-1/2 -translate-y-1/2 z-10 flex h-11 w-11 items-center justify-center rounded-full bg-white shadow-md border border-gray-100 transition-colors",
                  style: { color: ce },
                  onMouseEnter: (b) => {
                    ((b.currentTarget.style.backgroundColor = ce),
                      (b.currentTarget.style.color = "white"));
                  },
                  onMouseLeave: (b) => {
                    ((b.currentTarget.style.backgroundColor = "white"),
                      (b.currentTarget.style.color = ce));
                  },
                  "aria-label": "Previous",
                  children: a.jsx("svg", {
                    xmlns: "http://www.w3.org/2000/svg",
                    className: "h-5 w-5",
                    fill: "none",
                    viewBox: "0 0 24 24",
                    stroke: "currentColor",
                    strokeWidth: 2,
                    children: a.jsx("path", {
                      strokeLinecap: "round",
                      strokeLinejoin: "round",
                      d: "M15 19l-7-7 7-7",
                    }),
                  }),
                }),
                a.jsx("div", {
                  className: "grid gap-6 sm:grid-cols-3",
                  style: S,
                  children: w.map((b, P) =>
                    a.jsx(Fk, { card: b, onFlip: y }, `${o}-${P}`),
                  ),
                }),
                a.jsx("button", {
                  onClick: x,
                  className:
                    "absolute -right-5 top-1/2 -translate-y-1/2 z-10 flex h-11 w-11 items-center justify-center rounded-full bg-white shadow-md border border-gray-100 transition-colors",
                  style: { color: ce },
                  onMouseEnter: (b) => {
                    ((b.currentTarget.style.backgroundColor = ce),
                      (b.currentTarget.style.color = "white"));
                  },
                  onMouseLeave: (b) => {
                    ((b.currentTarget.style.backgroundColor = "white"),
                      (b.currentTarget.style.color = ce));
                  },
                  "aria-label": "Next",
                  children: a.jsx("svg", {
                    xmlns: "http://www.w3.org/2000/svg",
                    className: "h-5 w-5",
                    fill: "none",
                    viewBox: "0 0 24 24",
                    stroke: "currentColor",
                    strokeWidth: 2,
                    children: a.jsx("path", {
                      strokeLinecap: "round",
                      strokeLinejoin: "round",
                      d: "M9 5l7 7-7 7",
                    }),
                  }),
                }),
              ],
            }),
            a.jsx("div", {
              className: "mt-8 flex justify-center gap-3",
              children: Array.from({ length: m }).map((b, P) =>
                a.jsx(
                  "button",
                  {
                    onClick: () => v(P, P > f.current ? "next" : "prev"),
                    className:
                      "h-3 w-3 rounded-full transition-all duration-300",
                    style: {
                      backgroundColor: P === e ? ce : "#d1d5db",
                      transform: P === e ? "scale(1.25)" : "scale(1)",
                    },
                    "aria-label": `Page ${P + 1}`,
                  },
                  P,
                ),
              ),
            }),
          ],
        }),
      }),
      a.jsxs("section", {
        className: "relative overflow-hidden py-24 sm:py-32",
        children: [
          a.jsx("img", {
            src: "/assets/images/events/lp.jpeg",
            alt: "",
            "aria-hidden": "true",
            loading: "lazy",
            decoding: "async",
            width: 1920,
            height: 600,
            className:
              "absolute inset-0 w-full h-full object-cover object-center",
          }),
          a.jsx("div", {
            className: "absolute inset-0",
            style: { backgroundColor: "rgba(0,0,0,0.40)" },
          }),
          a.jsxs("div", {
            className:
              "container-shell relative z-10 flex flex-col items-center gap-6 text-center",
            children: [
              a.jsxs(I, {
                children: [
                  a.jsx("h2", {
                    className:
                      "mbi-heading text-4xl font-bold text-white sm:text-5xl lg:text-6xl",
                    children: "Join The Next Golf Day",
                  }),
                  a.jsx("p", {
                    className:
                      "mbi-body mx-auto mt-6 text-white text-sm leading-relaxed sm:text-base max-w-[800px]",
                    style: { textShadow: "0 1px 4px rgba(0,0,0,0.5)" },
                    children:
                      "Be part of our next exclusive golf day and experience a unique blend of business, networking, and leisure in an environment designed to build lasting relationships.",
                  }),
                ],
              }),
              a.jsx(I, {
                delayMs: 100,
                children: a.jsx(ye, {
                  to: "/contact#contact-form",
                  children: a.jsx("button", {
                    className:
                      "mbi-heading mt-2 px-16 py-4 text-sm font-bold uppercase tracking-widest text-white hover:opacity-80 transition-opacity",
                    style: { backgroundColor: ce },
                    children: "VIEW DETAILS",
                  }),
                }),
              }),
            ],
          }),
        ],
      }),
    ],
  });
}
const Ae = "#000000",
  Wk = `
  .mbi-heading { font-family: 'Montserrat', sans-serif; font-weight: 600; }
  .mbi-body    { font-family: 'Montserrat', sans-serif; font-weight: 400; text-align: justify; }
  p            { text-align: justify; }
  .field {
    font-family: 'Montserrat', sans-serif;
    font-weight: 400;
    width: 100%;
    height: 44px;
    padding: 0 1rem;
    outline: none;
    border: 2px solid #0000004d;
    border-radius: 0;
    transition: border-color 0.2s;
    background: white;
  }
  .field:focus { border-color: #000000; }
  textarea.field { height: auto; padding: 0.75rem 1rem; min-height: 130px; }
`;
function Uk() {
  const e = j.useRef(null),
    [t, n] = j.useState(!1);
  return (
    j.useEffect(() => {
      const r = e.current;
      if (!r) return;
      const i = new IntersectionObserver(
        ([s]) => {
          s.isIntersecting && (n(!0), i.disconnect());
        },
        { rootMargin: "200px" },
      );
      return (i.observe(r), () => i.disconnect());
    }, []),
    a.jsxs("div", {
      ref: e,
      className: "flex flex-col h-full",
      children: [
        a.jsxs("div", {
          className: "flex items-center gap-3 px-4 py-3",
          style: {
            backgroundColor: "#ffffff10",
            borderBottom: "1px solid #ffffff20",
          },
          children: [
            a.jsx("svg", {
              width: "16",
              height: "16",
              viewBox: "0 0 16 16",
              fill: "none",
              children: a.jsx("path", {
                d: "M8 1.5C5.515 1.5 3.5 3.515 3.5 6c0 3.75 4.5 8.5 4.5 8.5S12.5 9.75 12.5 6c0-2.485-2.015-4.5-4.5-4.5Zm0 6a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3Z",
                fill: "#ffffff99",
              }),
            }),
            a.jsx("span", {
              className: "mbi-heading text-xs uppercase tracking-widest",
              style: { color: "#ffffff80" },
              children: "Waterfall House, Sandton",
            }),
          ],
        }),
        a.jsx("div", {
          className: "relative overflow-hidden flex-1",
          style: { minHeight: "340px" },
          children: t
            ? a.jsx("iframe", {
                title: "Matseke Business Investment — Waterfall House",
                src: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3584.7092338011726!2d28.09695197540979!3d-26.043068127176205!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1e9573459bb8e449%3A0x310905630e5aaf44!2sWaterfall%20House!5e0!3m2!1sen!2sza!4v1776834661124!5m2!1sen!2sza",
                width: "100%",
                height: "100%",
                style: {
                  border: 0,
                  display: "block",
                  position: "absolute",
                  inset: 0,
                },
                allowFullScreen: !0,
                loading: "lazy",
                referrerPolicy: "no-referrer-when-downgrade",
              })
            : a.jsxs("div", {
                className:
                  "absolute inset-0 flex flex-col items-center justify-center gap-3",
                style: { backgroundColor: "#ffffff08" },
                children: [
                  a.jsx("svg", {
                    width: "32",
                    height: "32",
                    viewBox: "0 0 32 32",
                    fill: "none",
                    children: a.jsx("path", {
                      d: "M16 3C11.03 3 7 7.03 7 12c0 7.5 9 17 9 17s9-9.5 9-17c0-4.97-4.03-9-9-9Zm0 12a3 3 0 1 1 0-6 3 3 0 0 1 0 6Z",
                      fill: "#ffffff30",
                    }),
                  }),
                  a.jsx("span", {
                    className: "mbi-body text-xs",
                    style: { color: "#ffffff40" },
                    children: "Loading map…",
                  }),
                ],
              }),
        }),
        a.jsxs("a", {
          href: "https://maps.google.com/?q=Waterfall+House,+Sandton",
          target: "_blank",
          rel: "noopener noreferrer",
          className:
            "mbi-heading flex items-center justify-between px-4 py-3 text-xs uppercase tracking-widest transition-opacity hover:opacity-70",
          style: {
            backgroundColor: "#ffffff10",
            borderTop: "1px solid #ffffff20",
            color: "#ffffff80",
          },
          children: [
            a.jsx("span", { children: "Open in Google Maps" }),
            a.jsx("svg", {
              width: "12",
              height: "12",
              viewBox: "0 0 12 12",
              fill: "none",
              children: a.jsx("path", {
                d: "M2 10L10 2M10 2H4M10 2V8",
                stroke: "currentColor",
                strokeWidth: "1.8",
                strokeLinecap: "round",
                strokeLinejoin: "round",
              }),
            }),
          ],
        }),
      ],
    })
  );
}
function Hk() {
  const [e, t] = j.useState("idle");
  async function n(r) {
    (r.preventDefault(), t("submitting"));
    const i = new FormData(r.currentTarget),
      s = Object.fromEntries(i);
    try {
      const l = await (
        await fetch("https://api.web3forms.com/submit", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
          },
          body: JSON.stringify(s),
        })
      ).json();
      t(l.success ? "success" : "error");
    } catch {
      t("error");
    }
  }
  return a.jsxs("div", {
    children: [
      a.jsx("style", { children: Wk }),
      a.jsxs("section", {
        className:
          "relative flex items-center justify-center text-center text-white overflow-hidden",
        style: { minHeight: "560px" },
        children: [
          a.jsx("img", {
            src: "/assets/images/contact us/Contact.jpeg",
            alt: "",
            "aria-hidden": "true",
            fetchPriority: "high",
            loading: "eager",
            decoding: "sync",
            width: 1920,
            height: 560,
            className:
              "absolute inset-0 w-full h-full object-cover object-center",
          }),
          a.jsx("div", { className: "absolute inset-0 bg-black/50" }),
          a.jsxs("div", {
            className: "relative z-10 px-6 py-24",
            children: [
              a.jsx("h1", {
                className:
                  "mbi-heading text-5xl sm:text-6xl font-semibold tracking-tight",
                children: "Contact Us",
              }),
              a.jsx("div", { className: "mx-auto mt-4 h-px w-16 bg-white/60" }),
              a.jsx("p", {
                className:
                  "mbi-body mt-6 max-w-2xl mx-auto text-base sm:text-lg leading-relaxed text-white",
                style: {
                  textAlign: "center",
                  textShadow: "0 1px 6px rgba(0,0,0,0.6)",
                },
                children:
                  "We are a trusted investment and financial advisory firm providing tailored solutions to individuals, entrepreneurs, and corporates.",
              }),
            ],
          }),
        ],
      }),
      a.jsx("section", {
        id: "contact-form",
        className: "bg-white",
        children: a.jsx("div", {
          className: "container-shell py-14 sm:py-16",
          children: a.jsxs("div", {
            className: "grid gap-10 lg:grid-cols-2",
            children: [
              a.jsx(I, {
                children: a.jsxs("div", {
                  className: "card p-8",
                  children: [
                    a.jsx("h2", {
                      className: "mbi-heading text-3xl font-bold",
                      style: { color: Ae },
                      children: "Send us a message",
                    }),
                    a.jsxs("form", {
                      className: "mt-6 grid gap-4",
                      onSubmit: n,
                      children: [
                        a.jsx("input", {
                          type: "hidden",
                          name: "access_key",
                          value: "d98e7852-5f27-4379-b698-2ce9d4b90834",
                        }),
                        a.jsxs("div", {
                          className: "grid gap-4 sm:grid-cols-2",
                          children: [
                            a.jsxs("label", {
                              className: "grid gap-2",
                              children: [
                                a.jsx("span", {
                                  className:
                                    "mbi-heading text-sm font-semibold",
                                  style: { color: Ae },
                                  children: "Name",
                                }),
                                a.jsx("input", {
                                  name: "name",
                                  required: !0,
                                  className: "field",
                                  placeholder: "Name",
                                }),
                              ],
                            }),
                            a.jsxs("label", {
                              className: "grid gap-2",
                              children: [
                                a.jsx("span", {
                                  className:
                                    "mbi-heading text-sm font-semibold",
                                  style: { color: Ae },
                                  children: "Company",
                                }),
                                a.jsx("input", {
                                  name: "company",
                                  className: "field",
                                  placeholder: "Company",
                                }),
                              ],
                            }),
                          ],
                        }),
                        a.jsxs("div", {
                          className: "grid gap-4 sm:grid-cols-2",
                          children: [
                            a.jsxs("label", {
                              className: "grid gap-2",
                              children: [
                                a.jsx("span", {
                                  className:
                                    "mbi-heading text-sm font-semibold",
                                  style: { color: Ae },
                                  children: "Phone",
                                }),
                                a.jsx("input", {
                                  name: "phone",
                                  className: "field",
                                  placeholder: "Phone",
                                }),
                              ],
                            }),
                            a.jsxs("label", {
                              className: "grid gap-2",
                              children: [
                                a.jsx("span", {
                                  className:
                                    "mbi-heading text-sm font-semibold",
                                  style: { color: Ae },
                                  children: "Email",
                                }),
                                a.jsx("input", {
                                  name: "email",
                                  type: "email",
                                  required: !0,
                                  className: "field",
                                  placeholder: "Email",
                                }),
                              ],
                            }),
                          ],
                        }),
                        a.jsxs("label", {
                          className: "grid gap-2",
                          children: [
                            a.jsx("span", {
                              className: "mbi-heading text-sm font-semibold",
                              style: { color: Ae },
                              children: "Subject",
                            }),
                            a.jsx("input", {
                              name: "subject",
                              className: "field",
                              placeholder: "Subject",
                            }),
                          ],
                        }),
                        a.jsxs("label", {
                          className: "grid gap-2",
                          children: [
                            a.jsx("span", {
                              className: "mbi-heading text-sm font-semibold",
                              style: { color: Ae },
                              children: "Message",
                            }),
                            a.jsx("textarea", {
                              name: "message",
                              required: !0,
                              className: "field",
                              placeholder: "Message",
                            }),
                          ],
                        }),
                        e === "success" &&
                          a.jsx("p", {
                            className: "mbi-body text-sm text-green-600",
                            style: { textAlign: "left" },
                            children:
                              "✓ Message sent! We'll be in touch shortly.",
                          }),
                        e === "error" &&
                          a.jsx("p", {
                            className: "mbi-body text-sm text-red-600",
                            style: { textAlign: "left" },
                            children:
                              "Something went wrong. Please try again or email us directly.",
                          }),
                        a.jsx("button", {
                          type: "submit",
                          disabled: e === "submitting" || e === "success",
                          className:
                            "mbi-heading mt-2 w-full sm:w-fit rounded-none px-8 py-3 text-sm font-bold uppercase tracking-wide text-white hover:opacity-80 transition-opacity disabled:opacity-50",
                          style: { backgroundColor: Ae },
                          children: e === "submitting" ? "Sending…" : "Send",
                        }),
                      ],
                    }),
                  ],
                }),
              }),
              a.jsx(I, {
                delayMs: 120,
                children: a.jsxs("div", {
                  className: "card p-8",
                  children: [
                    a.jsx("h2", {
                      className: "mbi-heading text-3xl font-bold",
                      style: { color: Ae },
                      children: "Get in touch",
                    }),
                    a.jsx("p", {
                      className:
                        "mbi-body mt-4 max-w-xl text-sm leading-relaxed text-black/70 sm:text-base",
                      children:
                        "Helping you navigate financial opportunities with insight and expertise.",
                    }),
                    a.jsxs("div", {
                      className: "mt-8 grid gap-6",
                      children: [
                        a.jsxs("div", {
                          children: [
                            a.jsx("div", {
                              className: "mbi-heading text-sm font-semibold",
                              style: { color: Ae },
                              children: "Head Office",
                            }),
                            a.jsx("div", {
                              className: "mbi-body mt-2 text-sm text-black/70",
                              style: { textAlign: "left" },
                              children:
                                "54 Maxwell drive, Woodmead Office Park, Building B, Waterfall",
                            }),
                          ],
                        }),
                        a.jsxs("div", {
                          className: "grid gap-4 sm:grid-cols-2",
                          children: [
                            a.jsxs("div", {
                              children: [
                                a.jsx("div", {
                                  className:
                                    "mbi-heading text-sm font-semibold",
                                  style: { color: Ae },
                                  children: "Email Us",
                                }),
                                a.jsx("div", {
                                  className:
                                    "mbi-body mt-2 text-sm text-black/70",
                                  style: { textAlign: "left" },
                                  children: "info@matsekeinvestment.co.za",
                                }),
                              ],
                            }),
                            a.jsxs("div", {
                              children: [
                                a.jsx("div", {
                                  className:
                                    "mbi-heading text-sm font-semibold",
                                  style: { color: Ae },
                                  children: "Call Us",
                                }),
                                a.jsx("div", {
                                  className:
                                    "mbi-body mt-2 text-sm text-black/70",
                                  style: { textAlign: "left" },
                                  children: "(010) 005 5942",
                                }),
                              ],
                            }),
                          ],
                        }),
                      ],
                    }),
                  ],
                }),
              }),
            ],
          }),
        }),
      }),
      a.jsx("section", {
        className: "py-14 sm:py-16",
        style: { backgroundColor: Ae },
        children: a.jsx("div", {
          className: "container-shell",
          children: a.jsxs("div", {
            className: "grid gap-8 lg:grid-cols-2 lg:items-stretch",
            children: [
              a.jsx(I, {
                children: a.jsx("div", {
                  className: "overflow-hidden flex flex-col h-full",
                  style: { minHeight: "400px", border: "1px solid #ffffff15" },
                  children: a.jsx(Uk, {}),
                }),
              }),
              a.jsx(I, {
                delayMs: 120,
                children: a.jsxs("div", {
                  className: "flex flex-col justify-center h-full py-4",
                  children: [
                    a.jsx("p", {
                      className:
                        "mbi-heading text-xs uppercase tracking-widest mb-4",
                      style: { color: "#ffffff50" },
                      children: "Our Location",
                    }),
                    a.jsx("p", {
                      className:
                        "mbi-body text-sm leading-loose text-white/90 sm:text-base",
                      children:
                        "At Matseke Business Investment, we provide professional, regulated, and client-focused financial advisory services. We partner with individuals, entrepreneurs, and businesses to build, protect, and grow wealth through trusted guidance and long-term relationships.",
                    }),
                    a.jsx("div", {
                      className: "mt-8 flex flex-col sm:flex-row gap-3",
                      children: a.jsx("a", {
                        href: "mailto:info@matsekeinvestment.co.za",
                        className:
                          "mbi-heading inline-flex items-center justify-center gap-2 rounded-none px-8 py-3 text-sm font-bold uppercase tracking-wide hover:opacity-80 transition-opacity",
                        style: { color: Ae, backgroundColor: "white" },
                        children: "Email Us",
                      }),
                    }),
                  ],
                }),
              }),
            ],
          }),
        }),
      }),
    ],
  });
}
const Xf = "#000000",
  Fe = "#e26991",
  $k = `
  @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Playfair+Display:wght@400;700&display=swap');
  .mbi-heading { font-family: 'Montserrat', sans-serif; font-weight: 600; }
  .mbi-body    { font-family: 'Montserrat', sans-serif; font-weight: 400; }
  .mbi-serif   { font-family: 'Playfair Display', serif; font-weight: 700; }
`;
function gt({ title: e, children: t }) {
  return a.jsxs("div", {
    className: "mb-10",
    style: { borderBottom: "1px solid #f3f4f6", paddingBottom: "2.5rem" },
    children: [
      a.jsx("h2", {
        className: "mbi-heading mb-3 text-lg font-bold uppercase tracking-wide",
        style: { color: Fe },
        children: e,
      }),
      a.jsx("div", {
        className: "mbi-body text-sm leading-relaxed",
        style: { color: "#374151" },
        children: t,
      }),
    ],
  });
}
function Bt({ items: e }) {
  return a.jsx("ul", {
    className: "mt-2 space-y-1.5 pl-1",
    children: e.map((t, n) =>
      a.jsxs(
        "li",
        {
          className: "flex items-start gap-3",
          children: [
            a.jsx("span", {
              style: {
                color: Fe,
                fontSize: "10px",
                marginTop: "5px",
                flexShrink: 0,
              },
              children: "■",
            }),
            a.jsx("span", { className: "mbi-body", children: t }),
          ],
        },
        n,
      ),
    ),
  });
}
function Kk() {
  return (
    j.useEffect(() => {
      window.scrollTo(0, 0);
    }, []),
    a.jsxs("div", {
      className: "mbi-body",
      style: { backgroundColor: "#ffffff", minHeight: "100vh" },
      children: [
        a.jsx("style", { children: $k }),
        a.jsx("div", {
          style: {
            backgroundColor: Xf,
            paddingTop: "2rem",
            paddingBottom: "2rem",
          },
          children: a.jsxs("div", {
            className: "container-shell",
            children: [
              a.jsxs(ye, {
                to: "/",
                className:
                  "mbi-heading inline-flex items-center gap-2 mb-6 text-xs uppercase tracking-widest transition-opacity hover:opacity-60",
                style: { color: "#ffffff99" },
                children: [
                  a.jsx("svg", {
                    width: "14",
                    height: "14",
                    viewBox: "0 0 14 14",
                    fill: "none",
                    children: a.jsx("path", {
                      d: "M9 1L3 7L9 13",
                      stroke: "currentColor",
                      strokeWidth: "1.8",
                      strokeLinecap: "round",
                      strokeLinejoin: "round",
                    }),
                  }),
                  "Back to Home",
                ],
              }),
              a.jsx("h1", {
                className:
                  "mbi-heading text-4xl font-bold text-white sm:text-5xl",
                children: "Privacy Policy",
              }),
              a.jsx("div", {
                className: "mt-4 h-0.5 w-12",
                style: { backgroundColor: Fe },
              }),
              a.jsx("p", {
                className: "mbi-body mt-3 text-sm",
                style: { color: "#ffffff80" },
                children:
                  "In compliance with POPIA — Protection of Personal Information Act, 2013",
              }),
            ],
          }),
        }),
        a.jsx("div", {
          className: "container-shell py-16 sm:py-20",
          children: a.jsxs("div", {
            className: "max-w-3xl",
            children: [
              a.jsx("p", {
                className: "mbi-body mb-10 text-sm leading-relaxed",
                style: { color: "#374151" },
                children:
                  'Matseke Business Investment ("MBI", "we", "us", "our") is committed to protecting your privacy and ensuring that your personal information is collected and used properly, lawfully, and transparently. This Privacy Policy complies with the Protection of Personal Information Act, 2013 ("POPIA").',
              }),
              a.jsxs(gt, {
                title: "Information We Collect",
                children: [
                  a.jsx("p", {
                    children:
                      "We may collect and process the following personal information:",
                  }),
                  a.jsx(Bt, {
                    items: [
                      "Full name and surname",
                      "Identity number",
                      "Contact details (email, phone number)",
                      "Financial information (income, assets, liabilities)",
                      "Employment details",
                      "Any other information required to provide financial services",
                    ],
                  }),
                ],
              }),
              a.jsxs(gt, {
                title: "How We Collect Information",
                children: [
                  a.jsx("p", { children: "We collect personal information:" }),
                  a.jsx(Bt, {
                    items: [
                      "Directly from you when you complete forms or engage our services",
                      "Through our website (e.g., contact forms, cookies)",
                      "From third parties where legally permitted",
                    ],
                  }),
                ],
              }),
              a.jsxs(gt, {
                title: "Purpose of Processing",
                children: [
                  a.jsx("p", {
                    children: "Your personal information is used to:",
                  }),
                  a.jsx(Bt, {
                    items: [
                      "Provide financial advice and intermediary services",
                      "Assess your financial needs and risk profile",
                      "Comply with legal and regulatory requirements",
                      "Communicate with you regarding services",
                      "Improve our service offering",
                    ],
                  }),
                ],
              }),
              a.jsxs(gt, {
                title: "Legal Basis for Processing",
                children: [
                  a.jsx("p", { children: "We process your information:" }),
                  a.jsx(Bt, {
                    items: [
                      "With your consent",
                      "To fulfil contractual obligations",
                      "To comply with legal obligations",
                      "Where it is in your legitimate interest",
                    ],
                  }),
                ],
              }),
              a.jsxs(gt, {
                title: "Sharing of Information",
                children: [
                  a.jsx("p", {
                    children: "We may share your information with:",
                  }),
                  a.jsx(Bt, {
                    items: [
                      "Product providers (e.g., insurers, investment platforms)",
                      "Regulatory bodies such as the Financial Sector Conduct Authority",
                      "Third-party service providers assisting in operations",
                    ],
                  }),
                  a.jsx("p", {
                    className: "mt-3",
                    children:
                      "All third parties are required to safeguard your information.",
                  }),
                ],
              }),
              a.jsxs(gt, {
                title: "Data Security",
                children: [
                  a.jsx("p", {
                    children:
                      "We implement appropriate technical and organisational measures to protect your personal information against:",
                  }),
                  a.jsx(Bt, {
                    items: ["Loss", "Unauthorised access", "Misuse"],
                  }),
                ],
              }),
              a.jsxs(gt, {
                title: "Data Retention",
                children: [
                  a.jsx("p", {
                    children:
                      "Your personal information will be retained only for as long as necessary to:",
                  }),
                  a.jsx(Bt, {
                    items: [
                      "Fulfil the purpose for which it was collected",
                      "Comply with legal and regulatory obligations",
                    ],
                  }),
                ],
              }),
              a.jsxs(gt, {
                title: "Your Rights",
                children: [
                  a.jsx("p", { children: "You have the right to:" }),
                  a.jsx(Bt, {
                    items: [
                      "Access your personal information",
                      "Request correction or deletion",
                      "Object to processing",
                      "Withdraw consent",
                    ],
                  }),
                  a.jsx("p", {
                    className: "mt-3",
                    children:
                      "Requests can be submitted using the contact details below.",
                  }),
                ],
              }),
              a.jsx(gt, {
                title: "Cookies",
                children: a.jsx("p", {
                  children:
                    "Our website uses cookies to enhance user experience and analyse traffic. You may disable cookies in your browser settings.",
                }),
              }),
              a.jsxs("div", {
                className: "mb-10",
                style: {
                  borderBottom: "1px solid #f3f4f6",
                  paddingBottom: "2.5rem",
                },
                children: [
                  a.jsx("h2", {
                    className:
                      "mbi-heading mb-3 text-lg font-bold uppercase tracking-wide",
                    style: { color: Fe },
                    children: "FAIS Disclosure Notice",
                  }),
                  a.jsx("p", {
                    className: "mbi-body mb-6 text-xs",
                    style: { color: "#374151" },
                    children:
                      "In terms of the Financial Advisory and Intermediary Services Act (FAIS)",
                  }),
                  a.jsxs("div", {
                    className: "space-y-6 text-sm",
                    style: { color: "#374151" },
                    children: [
                      a.jsxs("div", {
                        children: [
                          a.jsx("p", {
                            className: "mbi-heading mb-1 font-bold",
                            style: { color: Fe },
                            children: "Authorisation",
                          }),
                          a.jsxs("p", {
                            className: "mbi-body",
                            children: [
                              "Financial Services Provider in terms of Section 8 of the Financial Advisory and Intermediary Services Act, 2002 (FAIS Act 37 of 2002), regulated by the Financial Sector Conduct Authority (FSCA) under ",
                              a.jsx("span", {
                                className: "mbi-heading",
                                children: "FSP No. 48618",
                              }),
                              ".",
                            ],
                          }),
                        ],
                      }),
                      a.jsxs("div", {
                        children: [
                          a.jsx("p", {
                            className: "mbi-heading mb-1 font-bold",
                            style: { color: Fe },
                            children: "Nature of Services",
                          }),
                          a.jsx("p", {
                            className: "mbi-body",
                            children: "MBI provides:",
                          }),
                          a.jsx("ul", {
                            className: "mt-2 space-y-1.5 pl-1",
                            children: [
                              "Financial advice",
                              "Intermediary services",
                              "Risk and investment planning",
                              "Wealth management solutions",
                            ].map((e, t) =>
                              a.jsxs(
                                "li",
                                {
                                  className: "flex items-start gap-3",
                                  children: [
                                    a.jsx("span", {
                                      style: {
                                        color: Fe,
                                        fontSize: "10px",
                                        marginTop: "5px",
                                        flexShrink: 0,
                                      },
                                      children: "■",
                                    }),
                                    a.jsx("span", {
                                      className: "mbi-body",
                                      children: e,
                                    }),
                                  ],
                                },
                                t,
                              ),
                            ),
                          }),
                        ],
                      }),
                      a.jsxs("div", {
                        children: [
                          a.jsx("p", {
                            className: "mbi-heading mb-1 font-bold",
                            style: { color: Fe },
                            children: "Representatives",
                          }),
                          a.jsx("p", {
                            className: "mbi-body",
                            children:
                              "All representatives of MBI are duly authorised, act within the scope of their mandate, and are supervised where applicable.",
                          }),
                        ],
                      }),
                      a.jsxs("div", {
                        children: [
                          a.jsx("p", {
                            className: "mbi-heading mb-1 font-bold",
                            style: { color: Fe },
                            children: "Remuneration",
                          }),
                          a.jsx("p", {
                            className: "mbi-body",
                            children:
                              "MBI may receive commission from product suppliers and fees agreed upon with clients. Full disclosure of all fees and commissions will be provided before any transaction is concluded.",
                          }),
                        ],
                      }),
                      a.jsxs("div", {
                        children: [
                          a.jsx("p", {
                            className: "mbi-heading mb-1 font-bold",
                            style: { color: Fe },
                            children: "Conflict of Interest",
                          }),
                          a.jsx("p", {
                            className: "mbi-body",
                            children:
                              "MBI maintains a Conflict of Interest Management Policy to ensure that clients' interests are prioritised and any potential conflicts are disclosed.",
                          }),
                        ],
                      }),
                      a.jsxs("div", {
                        children: [
                          a.jsx("p", {
                            className: "mbi-heading mb-1 font-bold",
                            style: { color: Fe },
                            children: "Complaints Procedure",
                          }),
                          a.jsxs("p", {
                            className: "mbi-body",
                            children: [
                              "If dissatisfied with our services, lodge a complaint with our Internal Complaints Contact: ",
                              a.jsx("span", {
                                className: "mbi-heading",
                                children: "compliance@matsekeinvestment.co.za",
                              }),
                            ],
                          }),
                          a.jsx("p", {
                            className: "mbi-body mt-2",
                            children:
                              "If unresolved, complaints may be escalated to the FAIS Ombud — Office of the Ombud for Financial Services Providers.",
                          }),
                        ],
                      }),
                      a.jsxs("div", {
                        children: [
                          a.jsx("p", {
                            className: "mbi-heading mb-1 font-bold",
                            style: { color: Fe },
                            children: "Record Keeping",
                          }),
                          a.jsx("p", {
                            className: "mbi-body",
                            children:
                              "All advice and transactions are recorded in accordance with FAIS requirements and may be made available upon request.",
                          }),
                        ],
                      }),
                    ],
                  }),
                ],
              }),
              a.jsx("div", {
                className: "mb-10 p-6",
                style: {
                  backgroundColor: "#f9f9f9",
                  borderLeft: `3px solid ${Fe}`,
                },
                children: a.jsx("p", {
                  className: "mbi-body text-xs leading-relaxed",
                  style: { color: "#374151" },
                  children:
                    "All information provided by Matseke Business Investment is for informational purposes only and does not constitute financial, investment, legal, or tax advice. Financial decisions should be made in consultation with a qualified financial advisor, taking into account your individual financial circumstances. Past performance is not indicative of future results.",
                }),
              }),
              a.jsxs(gt, {
                title: "Contact Information",
                children: [
                  a.jsx("p", {
                    className: "mbi-heading font-bold",
                    children: "Matseke Business Investment",
                  }),
                  a.jsxs("p", {
                    className: "mbi-body mt-1",
                    children: [
                      "Email: ",
                      a.jsx("a", {
                        href: "mailto:info@matsekeinvestment.co.za",
                        children: "info@matsekeinvestment.co.za",
                      }),
                    ],
                  }),
                  a.jsxs("p", {
                    className: "mbi-body",
                    children: [
                      "Phone: ",
                      a.jsx("a", {
                        href: "tel:0100055942",
                        children: "010 005 5942",
                      }),
                    ],
                  }),
                ],
              }),
              a.jsx("div", {
                className: "mt-8",
                children: a.jsxs(ye, {
                  to: "/",
                  className:
                    "mbi-heading inline-flex items-center gap-2 text-xs uppercase tracking-widest text-white transition-opacity hover:opacity-80",
                  style: { backgroundColor: Xf, padding: "12px 28px" },
                  children: [
                    a.jsx("svg", {
                      width: "14",
                      height: "14",
                      viewBox: "0 0 14 14",
                      fill: "none",
                      children: a.jsx("path", {
                        d: "M9 1L3 7L9 13",
                        stroke: "currentColor",
                        strokeWidth: "1.8",
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                      }),
                    }),
                    "Back to Home",
                  ],
                }),
              }),
            ],
          }),
        }),
      ],
    })
  );
}
const Qf = "#000000",
  so = "#e26991",
  Gk = `
  @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Playfair+Display:wght@400;700&display=swap');
  .mbi-heading { font-family: 'Montserrat', sans-serif; font-weight: 600; }
  .mbi-body    { font-family: 'Montserrat', sans-serif; font-weight: 400; }
  .mbi-serif   { font-family: 'Playfair Display', serif; font-weight: 700; }
`;
function Ye({ title: e, children: t }) {
  return a.jsxs("div", {
    className: "mb-10",
    style: { borderBottom: "1px solid #f3f4f6", paddingBottom: "2.5rem" },
    children: [
      a.jsx("h2", {
        className: "mbi-heading mb-3 text-lg font-bold uppercase tracking-wide",
        style: { color: so },
        children: e,
      }),
      a.jsx("div", {
        className: "mbi-body text-sm leading-relaxed",
        style: { color: "#374151" },
        children: t,
      }),
    ],
  });
}
function Zf({ items: e }) {
  return a.jsx("ul", {
    className: "mt-2 space-y-1.5 pl-1",
    children: e.map((t, n) =>
      a.jsxs(
        "li",
        {
          className: "flex items-start gap-3",
          children: [
            a.jsx("span", {
              style: {
                color: so,
                fontSize: "10px",
                marginTop: "5px",
                flexShrink: 0,
              },
              children: "■",
            }),
            a.jsx("span", { className: "mbi-body", children: t }),
          ],
        },
        n,
      ),
    ),
  });
}
function Yk() {
  return (
    j.useEffect(() => {
      window.scrollTo(0, 0);
    }, []),
    a.jsxs("div", {
      className: "mbi-body",
      style: { backgroundColor: "#ffffff", minHeight: "100vh" },
      children: [
        a.jsx("style", { children: Gk }),
        a.jsx("div", {
          style: {
            backgroundColor: Qf,
            paddingTop: "2rem",
            paddingBottom: "2rem",
          },
          children: a.jsxs("div", {
            className: "container-shell",
            children: [
              a.jsxs(ye, {
                to: "/",
                className:
                  "mbi-heading inline-flex items-center gap-2 mb-6 text-xs uppercase tracking-widest transition-opacity hover:opacity-60",
                style: { color: "#ffffff99" },
                children: [
                  a.jsx("svg", {
                    width: "14",
                    height: "14",
                    viewBox: "0 0 14 14",
                    fill: "none",
                    children: a.jsx("path", {
                      d: "M9 1L3 7L9 13",
                      stroke: "currentColor",
                      strokeWidth: "1.8",
                      strokeLinecap: "round",
                      strokeLinejoin: "round",
                    }),
                  }),
                  "Back to Home",
                ],
              }),
              a.jsx("h1", {
                className:
                  "mbi-heading text-4xl font-bold text-white sm:text-5xl",
                children: "Terms & Conditions",
              }),
              a.jsx("div", {
                className: "mt-4 h-0.5 w-12",
                style: { backgroundColor: so },
              }),
              a.jsx("p", {
                className: "mbi-body mt-3 text-sm",
                style: { color: "#ffffff80" },
                children:
                  "Governed by the laws of the Republic of South Africa",
              }),
            ],
          }),
        }),
        a.jsx("div", {
          className: "container-shell py-16 sm:py-20",
          children: a.jsxs("div", {
            className: "max-w-3xl",
            children: [
              a.jsx("p", {
                className: "mbi-body mb-10 text-sm leading-relaxed",
                style: { color: "#374151" },
                children:
                  'Welcome to the website of Matseke Business Investment ("MBI", "we", "us", "our"). By accessing and using this website, you agree to comply with and be bound by these Terms and Conditions. If you do not agree, please refrain from using this website.',
              }),
              a.jsx(Ye, {
                title: "Regulatory Status",
                children: a.jsx("p", {
                  children:
                    "MBI is an authorised financial services provider regulated in accordance with the laws of the Republic of South Africa and operates under the oversight of the Financial Sector Conduct Authority (FSCA). All financial advice and intermediary services are rendered in compliance with applicable legislation.",
                }),
              }),
              a.jsx(Ye, {
                title: "Purpose of the Website",
                children: a.jsx("p", {
                  children:
                    "The information provided on this website is for general informational purposes only and does not constitute financial advice, recommendation, or endorsement of any financial product or service. Users are encouraged to seek personalised financial advice before making any financial decisions.",
                }),
              }),
              a.jsxs(Ye, {
                title: "Use of the Website",
                children: [
                  a.jsx("p", {
                    children: "By using this website, you agree that you will:",
                  }),
                  a.jsx(Zf, {
                    items: [
                      "Use the website for lawful purposes only",
                      "Not engage in any activity that may compromise the security or functionality of the website",
                      "Not attempt to gain unauthorised access to any part of the website",
                    ],
                  }),
                  a.jsx("p", {
                    className: "mt-3",
                    children:
                      "MBI reserves the right to restrict or terminate access for users who violate these terms.",
                  }),
                ],
              }),
              a.jsxs(Ye, {
                title: "Intellectual Property",
                children: [
                  a.jsx("p", {
                    children:
                      "All content on this website, including but not limited to text, graphics, logos, images and design elements, is the property of MBI or its licensors and is protected by applicable intellectual property laws.",
                  }),
                  a.jsx("p", {
                    className: "mt-2",
                    children:
                      "No content may be reproduced, distributed, or used without prior written consent from MBI.",
                  }),
                ],
              }),
              a.jsxs(Ye, {
                title: "Limitation of Liability",
                children: [
                  a.jsx("p", {
                    children:
                      "While MBI takes reasonable steps to ensure the accuracy of information on this website:",
                  }),
                  a.jsx(Zf, {
                    items: [
                      "We do not guarantee that the content is complete, accurate, or up to date",
                      "We are not liable for any loss or damage arising from reliance on the information provided",
                    ],
                  }),
                  a.jsx("p", {
                    className: "mt-3",
                    children: "Use of this website is at your own risk.",
                  }),
                ],
              }),
              a.jsx(Ye, {
                title: "Third-Party Links",
                children: a.jsx("p", {
                  children:
                    "This website may contain links to third-party websites for convenience. MBI does not control these websites, is not responsible for their content or privacy practices, and does not endorse any third-party services or products.",
                }),
              }),
              a.jsx(Ye, {
                title: "Privacy and Data Protection",
                children: a.jsxs("p", {
                  children: [
                    "MBI is committed to protecting your personal information in accordance with the Protection of Personal Information Act (POPIA). By using this website, you consent to the collection and processing of your personal information as outlined in our",
                    " ",
                    a.jsx(ye, {
                      to: "/privacy-policy",
                      className: "mbi-heading",
                      style: { textDecoration: "underline" },
                      children: "Privacy Policy",
                    }),
                    ".",
                  ],
                }),
              }),
              a.jsx(Ye, {
                title: "Cookies",
                children: a.jsx("p", {
                  children:
                    "This website may use cookies to enhance user experience and analyse website traffic. By continuing to use the website, you consent to the use of cookies.",
                }),
              }),
              a.jsxs("div", {
                className: "mb-10",
                style: {
                  borderBottom: "1px solid #f3f4f6",
                  paddingBottom: "2.5rem",
                },
                children: [
                  a.jsx("h2", {
                    className:
                      "mbi-heading mb-3 text-lg font-bold uppercase tracking-wide",
                    style: { color: so },
                    children: "Financial Advice Disclaimer",
                  }),
                  a.jsx("div", {
                    className: "mbi-body text-sm leading-relaxed",
                    style: { color: "#374151" },
                    children: a.jsx("p", {
                      children:
                        "Nothing on this website constitutes financial advice, investment advice, or tax or legal advice. All financial decisions should be made in consultation with a qualified financial advisor.",
                    }),
                  }),
                ],
              }),
              a.jsx(Ye, {
                title: "Indemnity",
                children: a.jsx("p", {
                  children:
                    "You agree to indemnify and hold MBI harmless against any claims, damages, losses, or liabilities arising from your use of the website or your breach of these Terms and Conditions.",
                }),
              }),
              a.jsx(Ye, {
                title: "Changes to Terms",
                children: a.jsx("p", {
                  children:
                    "MBI reserves the right to amend these Terms and Conditions at any time without prior notice. Users are encouraged to review this page regularly.",
                }),
              }),
              a.jsx(Ye, {
                title: "Governing Law",
                children: a.jsx("p", {
                  children:
                    "These Terms and Conditions are governed by the laws of the Republic of South Africa. Any disputes arising shall be subject to the jurisdiction of South African courts.",
                }),
              }),
              a.jsxs(Ye, {
                title: "Contact Information",
                children: [
                  a.jsx("p", {
                    className: "mbi-heading font-bold",
                    children: "Matseke Business Investment",
                  }),
                  a.jsxs("p", {
                    className: "mbi-body mt-1",
                    children: [
                      "Email: ",
                      a.jsx("a", {
                        href: "mailto:info@matsekeinvestment.co.za",
                        children: "info@matsekeinvestment.co.za",
                      }),
                    ],
                  }),
                  a.jsxs("p", {
                    className: "mbi-body",
                    children: [
                      "Phone: ",
                      a.jsx("a", {
                        href: "tel:0100055942",
                        children: "010 005 5942",
                      }),
                    ],
                  }),
                  a.jsxs("p", {
                    className: "mbi-body",
                    children: [
                      "Website: ",
                      a.jsx("a", {
                        href: "https://www.matsekeinvestment.co.za",
                        target: "_blank",
                        rel: "noopener noreferrer",
                        children: "www.matsekeinvestment.co.za",
                      }),
                    ],
                  }),
                ],
              }),
              a.jsx("div", {
                className: "mt-8",
                children: a.jsxs(ye, {
                  to: "/",
                  className:
                    "mbi-heading inline-flex items-center gap-2 text-xs uppercase tracking-widest text-white transition-opacity hover:opacity-80",
                  style: { backgroundColor: Qf, padding: "12px 28px" },
                  children: [
                    a.jsx("svg", {
                      width: "14",
                      height: "14",
                      viewBox: "0 0 14 14",
                      fill: "none",
                      children: a.jsx("path", {
                        d: "M9 1L3 7L9 13",
                        stroke: "currentColor",
                        strokeWidth: "1.8",
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                      }),
                    }),
                    "Back to Home",
                  ],
                }),
              }),
            ],
          }),
        }),
      ],
    })
  );
}
function Xk() {
  const { pathname: e } = Bn();
  return (
    j.useEffect(() => {
      window.scrollTo({ top: 0, behavior: "smooth" });
    }, [e]),
    null
  );
}
function Qk() {
  return a.jsxs("div", {
    className: "min-h-dvh bg-cream text-ink",
    children: [
      a.jsx(Xk, {}),
      a.jsx(G1, {}),
      a.jsx("main", {
        className: "pt-20",
        children: a.jsxs(A1, {
          children: [
            a.jsx(Ot, { path: "/", element: a.jsx(xk, {}) }),
            a.jsx(Ot, { path: "/about", element: a.jsx(Rk, {}) }),
            a.jsx(Ot, { path: "/services", element: a.jsx(Bk, {}) }),
            a.jsx(Ot, { path: "/events", element: a.jsx(_k, {}) }),
            a.jsx(Ot, { path: "/contact", element: a.jsx(Hk, {}) }),
            a.jsx(Ot, { path: "/privacy-policy", element: a.jsx(Kk, {}) }),
            a.jsx(Ot, {
              path: "/terms-and-conditions",
              element: a.jsx(Yk, {}),
            }),
          ],
        }),
      }),
      a.jsx(sx, {}),
    ],
  });
}
wa.createRoot(document.getElementById("root")).render(
  a.jsx(Et.StrictMode, { children: a.jsx(F1, { children: a.jsx(Qk, {}) }) }),
);
